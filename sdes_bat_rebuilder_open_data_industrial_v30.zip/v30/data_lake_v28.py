from __future__ import annotations
import io, json, math, re, sqlite3, hashlib
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
from rapidfuzz.fuzz import token_set_ratio
from source_policy import policy

ROOT=Path(__file__).resolve().parent
DB=ROOT/'data_lake/transport_v28.sqlite'
DB.parent.mkdir(exist_ok=True)
MONTHS={'janvier':1,'jan':1,'fevrier':2,'fev':2,'mars':3,'avril':4,'avr':4,'mai':5,'juin':6,'juillet':7,'juil':7,'aout':8,'septembre':9,'sept':9,'octobre':10,'oct':10,'novembre':11,'nov':11,'decembre':12,'dec':12}

def norm(s):
    s=str(s or '').lower()
    for a,b in {'é':'e','è':'e','ê':'e','ë':'e','à':'a','â':'a','ä':'a','î':'i','ï':'i','ô':'o','ö':'o','ù':'u','û':'u','ü':'u','ç':'c','œ':'oe','æ':'ae'}.items(): s=s.replace(a,b)
    return re.sub(r'\s+',' ',re.sub(r'[^a-z0-9%+.-]+',' ',s)).strip()

def num(x):
    if x is None or (isinstance(x,float) and np.isnan(x)): return np.nan
    if isinstance(x,(int,float,np.number)): return float(x)
    s=str(x).replace('\u202f','').replace(' ','').replace('%','').replace(',','.')
    try:return float(s)
    except:return np.nan

def period(x):
    s=norm(x); y=None;q=None;m=None
    a=re.search(r'(?<!\d)(20\d{2})(?!\d)',s)
    if a: y=int(a.group(1))
    b=re.search(r'(?:t|q|trim|trimestre)\s*([1-4])',s)
    if b:q=int(b.group(1))
    for k,v in MONTHS.items():
        if re.search(rf'\b{k}\b',s):m=v;break
    if y is None:return None
    return {'year':y,'quarter':q,'month':m}

def detect_period_cols(df):
    out={}
    for j in range(df.shape[1]):
        for i in range(min(len(df),80)):
            p=period(df.iat[i,j])
            if p:out[j]=p;break
    return out

def parse_book(path, provider):
    rows=[]
    if path.suffix.lower()=='.csv': books=[('CSV',pd.read_csv(path,header=None,dtype=object))]
    else:
        xf=pd.ExcelFile(path); books=[]
        for sh in xf.sheet_names:
            try: books.append((sh,pd.read_excel(path,sheet_name=sh,header=None,dtype=object)))
            except: pass
    for sh,df in books:
        if df.empty: continue
        df=df.iloc[:50000,:250]
        pcols=detect_period_cols(df)
        if len(pcols)<2: continue
        for i in range(len(df)):
            vals=[str(x) for x in df.iloc[i].tolist() if pd.notna(x)]
            if not vals: continue
            label=' | '.join(vals[:10])
            obs=[]
            for j,p in pcols.items():
                v=num(df.iat[i,j]);
                if np.isfinite(v): obs.append({**p,'value':float(v)})
            if len(obs)>=2:
                # infer adjacent metadata from left cells and nearby rows
                unit=''; scope=''
                context=' '.join(vals[:12])
                for rr in range(max(0,i-3),min(len(df),i+4)):
                    c=' '.join(str(x) for x in df.iloc[rr,:min(12,df.shape[1])].tolist() if pd.notna(x))
                    m=re.search(r'(milliards?|millions?|\bTWh\b|\bMtep\b|%|g.?km|km|voyageurs.?km|tonnes.?km)',c,re.I)
                    if m and not unit: unit=m.group(1)
                    if any(w in c.lower() for w in ['champ :','champ=','france métropolitaine','france hors drom','france entière']): scope=c
                rows.append({'provider':provider,'source':path.name,'url':'','sheet':sh,'row':i+1,'label':label[:800],'norm_label':norm(label),'unit':unit,'scope':scope,'obs':obs})
    return rows

class DataLake:
    def __init__(self, live_dir=None, reference_dir=None):
        self.live_dir=Path(live_dir or ROOT/'acquired/live')
        self.reference_dir=Path(reference_dir or ROOT/'reference')
        self.live=[]; self.reference=[]; self.facts=[]; self.errors=[]; self.manifest={}
        self.load_manifest()
        self.load_facts(); self.scan_live(); self.scan_reference()

    def load_manifest(self):
        p=ROOT/'data_lake/HARVEST_MANIFEST.json'
        if not p.exists(): return
        try:
            m=json.loads(p.read_text(encoding='utf8'))
            for x in m.get('live',[]):
                fn=Path(x.get('local_file') or x.get('url') or '').name
                if fn: self.manifest[fn]=x
        except Exception as e:
            self.errors.append({'stage':'manifest','error':repr(e)})

    def load_facts(self):
        p=ROOT/'config/public_facts_v28.json'
        if p.exists(): self.facts=json.loads(p.read_text(encoding='utf-8')).get('facts',[])
    def scan_live(self):
        if not self.live_dir.exists(): return
        for p in list(self.live_dir.rglob('*.xlsx'))+list(self.live_dir.rglob('*.xls'))+list(self.live_dir.rglob('*.csv')):
            provider=self.provider_for(p)
            try:
                rows=parse_book(p,provider)
                for r in rows:
                    r['source_file']=str(p); r['source_tier']='primary_open'; meta=self.manifest.get(p.name,{}); r['url']=meta.get('url') or meta.get('final_url',''); r['publication_date']=meta.get('publication_date'); self.live.append(r)
            except Exception as e:self.errors.append({'file':str(p),'error':repr(e)})
    def scan_reference(self):
        if not self.reference_dir.exists(): return
        for p in list(self.reference_dir.rglob('*.xlsx'))+list(self.reference_dir.rglob('*.xls'))+list(self.reference_dir.rglob('*.csv')):
            if str(p).find('calibration') < 0: continue
            provider='sdes_bat_2024' if 'sdes' in p.name.lower() or 'bilan' in p.name.lower() else 'sdes_ck_2026'
            try:
                rows=parse_book(p,provider)
                for r in rows:
                    r['source_file']=str(p); r['source_tier']='reference_calibration'; self.reference.append(r)
            except Exception as e:self.errors.append({'file':str(p),'error':repr(e),'role':'reference_calibration'})

    def provider_for(self,p):
        s=p.name.lower()
        if 'immatric' in s or 'parc' in s:return 'sdes_specific'
        if 'emploi' in s:return 'sdes_specific'
        if 'fret' in s:return 'sdes_specific'
        return 'sdes_specific'
    def save_sqlite(self):
        if DB.exists(): DB.unlink()
        con=sqlite3.connect(DB)
        cur=con.cursor(); cur.execute('create table series(provider text,source_file text,sheet text,row integer,label text,unit text,scope text,obs_json text)')
        cur.execute('create table facts(fiche text,concept text,value real,unit text,status text,provider text,date_published text,url text)')
        cur.execute('create table reference_series(provider text,source_file text,sheet text,row integer,label text,unit text,scope text,obs_json text)')
        for s in self.live: cur.execute('insert into series values(?,?,?,?,?,?,?,?)',(s['provider'],s['source_file'],s['sheet'],s['row'],s['label'],s['unit'],s['scope'],json.dumps(s['obs'],ensure_ascii=False)))
        for s in self.reference: cur.execute('insert into reference_series values(?,?,?,?,?,?,?,?)',(s['provider'],s['source_file'],s['sheet'],s['row'],s['label'],s['unit'],s['scope'],json.dumps(s['obs'],ensure_ascii=False)))
        for f in self.facts: cur.execute('insert into facts values(?,?,?,?,?,?,?,?)',(f.get('fiche'),f.get('concept'),f.get('value'),f.get('unit'),f.get('status'),f.get('provider'),f.get('date_published'),f.get('url')))
        con.commit(); con.close()
        (ROOT/'data_lake/INDEX_STATUS.json').write_text(json.dumps({'live_series':len(self.live),'reference_series':len(self.reference),'facts':len(self.facts),'errors':self.errors,'db':str(DB)},ensure_ascii=False,indent=2),encoding='utf-8')
    def all_reference_candidates(self, aliases, providers=None):
        aliases=[norm(x) for x in aliases if x]
        out=[]
        for s in self.reference:
            if providers and s['provider'] not in providers: continue
            sem=max([token_set_ratio(a,s['norm_label']) for a in aliases] or [0])
            if sem<50: continue
            out.append((sem,s))
        return [s for _,s in sorted(out,key=lambda z:-z[0])]

    def all_candidates(self, aliases, providers=None):
        aliases=[norm(x) for x in aliases if x]
        out=[]
        for s in self.live:
            if providers and s['provider'] not in providers: continue
            sem=max([token_set_ratio(a,s['norm_label']) for a in aliases] or [0])
            if sem<45: continue
            out.append((sem,s))
        return [s for _,s in sorted(out,key=lambda z:-z[0])]
    def fact_candidates(self, fiche, aliases):
        aa=[norm(x) for x in aliases]
        out=[]
        for f in self.facts:
            if f.get('fiche') not in {fiche,None}: continue
            sem=max([token_set_ratio(norm(f.get('concept','')),a) for a in aa] or [0])
            if sem>=55: out.append((sem,f))
        return [f for _,f in sorted(out,key=lambda z:-z[0])]
