from __future__ import annotations
import argparse, json, shutil
from pathlib import Path
from engine_v28 import Engine
from render_v29 import export_report

ROOT=Path(__file__).resolve().parent

def build_all(target=2025,asof='2026-08-29', fiches=None):
    e=Engine(); codes=fiches or list(e.registry); out=[]
    for c in codes:
        try:
            r=e.build(c,'annual',target,asof); rdir,pdf=export_report(r); out.append(r)
        except Exception as ex: out.append({'fiche':c,'fatal':repr(ex)})
    return out

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--year',type=int,default=2025); ap.add_argument('--as-of',default='2026-08-29'); ap.add_argument('--fiches',nargs='*'); args=ap.parse_args();
    out=build_all(args.year,args.as_of,args.fiches); summary=[]
    for r in out:
        if 'fatal' in r: summary.append({'fiche':r['fiche'],'status':'FATAL','error':r['fatal']}); continue
        summary.append({'fiche':r['fiche'],'family':r['family'],'records':len(r['records']),'derived':len(r['derived']),'unresolved':len(r['unresolved']),'nowcast':sum(x['status']=='NOWCAST' for x in r['records'])})
    (ROOT/'output/BENCHMARK_SUMMARY.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'fiches':len(out),'summary':summary},ensure_ascii=False))
