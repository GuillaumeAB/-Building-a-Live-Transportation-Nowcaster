# Reconstructeur BAT SDES — V29

V29 est une chaîne open-data de reconstruction du BAT 2025 / Chiffres clés 2026.

Règle absolue : BAT 2024 et Chiffres clés 2026 sont utilisés comme gabarit documentaire, dictionnaire structurel, inventaire figures/tableaux et calibration historique uniquement. Une valeur cible ne peut être fournie que par une source publique hors gabarit, une dérivation de telles sources, ou un nowcast de dernier recours validé hors échantillon.

## Démarrage Windows
Double-cliquer `run_windows.bat`. Le bootstrap détecte Python 3.11–3.14, crée `.venv`, vérifie les dépendances, choisit un port libre et ouvre l’application.

## Production
`python build_all.py --year 2025 --as-of 2026-08-29 --out delivery_v29`

## Indexage
`Indexer` construit le data lake des fichiers acquis : métadonnées, séries, périodes, unités, provenance et index SQLite. Les fichiers de référence BAT/CK restent dans le store de calibration et ne sont jamais autorisés comme preuve cible.
