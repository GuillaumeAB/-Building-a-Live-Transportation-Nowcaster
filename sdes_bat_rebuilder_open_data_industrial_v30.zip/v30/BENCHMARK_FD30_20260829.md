# V30 — lancement de validation F4 + D2.1

Exécution conjointe le 29/08/2026, en parallèle (ThreadPoolExecutor, 2 workers) :

- F4 — Transport aérien de voyageurs — millésime 2025
- D2.1 — Émissions de GES des transports — T1 2026

## Résultats

- 2/2 fiches terminées sans erreur
- 7 preuves/éléments structurés F4
- 6 preuves/éléments structurés D2.1
- 3 figures produites par fiche
- 2 pages PDF par fiche
- 3 paragraphes analytiques par fiche
- tableau de synthèse et provenance inclus
- aucun chiffre cible issu du BAT/Chiffres clés de référence

## Sources cibles

F4 : DGAC / ministère chargé des transports.
D2.1 : Citepa.

Le BAT 2024 et les Chiffres clés 2026 restent dans l'application comme spécification de structure/calibration uniquement.
