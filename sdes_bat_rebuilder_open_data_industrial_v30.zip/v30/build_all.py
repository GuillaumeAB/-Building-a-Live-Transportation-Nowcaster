from __future__ import annotations
import argparse,json,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path
from engine_v28 import Engine
from render_v29 import export_report
ROOT=Path(__file__).resolve().parent

def build_all(target=2025,asof='2026-08-29',fiches=None):
    e=Engine(); codes=fiches or list(e.registry); results=[]; t=time.perf_counter()
    # Shared Engine/context is intentionally prepared once; per-fiche work is parallelized only after preparation.
    def one(c):
        try:
            r=e.build(c,'annual',target,asof); export_report(r); return r
        except Exception as ex: return {'fiche':c,'fatal':repr(ex)}
    with ThreadPoolExecutor(max_workers=min(8,max(1,len(codes)))) as ex:
        fs={ex.submit(one,c):c for c in codes}
        for f in as_completed(fs): results.append(f.result())
    elapsed=time.perf_counter()-t
    results=sorted(results,key=lambda r:r.get('fiche',''))
    summary=[]
    for r in results:
        if 'fatal' in r: summary.append({'fiche':r['fiche'],'status':'FATAL','error':r['fatal']})
        else: summary.append({'fiche':r['fiche'],'family':r['family'],'records':len(r.get('records',[])),'derived':len(r.get('derived',[])),'unresolved':len(r.get('unresolved',[])),'nowcasts':sum(x.get('status')=='NOWCAST' for x in r.get('records',[]))})
    (ROOT/'output/BENCHMARK_SUMMARY.json').write_text(json.dumps({'elapsed_s':round(elapsed,3),'summary':summary},ensure_ascii=False,indent=2),encoding='utf8')
    return results

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--year',type=int,default=2025); ap.add_argument('--as-of',default='2026-08-29'); ap.add_argument('--fiches',nargs='*'); a=ap.parse_args()
    r=build_all(a.year,a.as_of,a.fiches); print(json.dumps({'fiches':len(r),'elapsed_s':json.load(open(ROOT/'output/BENCHMARK_SUMMARY.json'))['elapsed_s']},ensure_ascii=False,indent=2))
