from __future__ import annotations
import json, subprocess, sys, datetime as dt, tempfile, shutil
from pathlib import Path
import pandas as pd
import streamlit as st
from engine_v28 import Engine
from render_v29 import export_report

ROOT=Path(__file__).resolve().parent
REG=Engine().registry
SR=json.loads((ROOT/'config/source_registry_v28.json').read_text(encoding='utf-8'))
st.set_page_config(page_title='Reconstructeur BAT SDES V29',layout='wide')
st.title('Reconstructeur BAT SDES - V29')
st.caption('BAT 2025 open data : gabarit séparé des preuves cibles, index statistique, sources multi-producteurs, calculs, nowcast de dernier recours et rendu éditorial.')

with st.sidebar:
    st.header('Projet')
    asof=st.date_input('Date de connaissance',value=dt.date.today())
    year=int(st.number_input('Millésime cible',2010,2035,2025))
    fams=['Toutes']+sorted({v['family'] for v in REG.values()})
    fam=st.selectbox('Partie',fams)
    codes=[k for k,v in REG.items() if fam=='Toutes' or v['family']==fam]
    fiche=st.selectbox('Fiche',codes)
    horizon=st.radio('Horizon',['Année','Trimestre'])
    if horizon=='Trimestre':
        q=int(st.selectbox('Trimestre',[1,2,3,4])); target=(year,q); target_kind='quarterly'
    else: target=year; target_kind='annual'
    st.markdown('**Politique de sourcing**')
    st.warning('BAT 2024 et Chiffres clés 2026 : référence uniquement. Aucune valeur cible ne peut en provenir.')
    c1=st.button('🌐 Acquérir / actualiser les sources',use_container_width=True)
    c2=st.button('🧠 Indexer tout le corpus',use_container_width=True)
    c3=st.button('🚀 Construire la fiche',type='primary',use_container_width=True)
    c4=st.button('🏭 Construire tout le BAT',use_container_width=True)

if c1:
    with st.spinner('Acquisition live des sources publiques et documents de référence...'):
        p=subprocess.run([sys.executable,str(ROOT/'harvest_v28.py')],capture_output=True,text=True)
    st.code(p.stdout[-4000:] if p.stdout else p.stderr[-4000:])
    if p.returncode==0: st.success('Acquisition terminée.')
    else: st.error('Acquisition partiellement ou totalement échouée. Voir le journal ci-dessus.')

if c2:
    with st.spinner('Lecture des classeurs, index des séries et extraction des objets de référence...'):
        e=Engine(); e.lake.save_sqlite(); subprocess.run([sys.executable,str(ROOT/'reference_extract_v28.py')],check=False)
    st.success(f"Index prêt : {len(e.lake.live)} séries live, {len(e.lake.reference)} séries historiques de calibration, {len(e.lake.facts)} faits publics structurés.")

if c3:
    with st.spinner('Résolution conceptuelle + calculs + nowcast conditionnel + QA + rendu 2 pages...'):
        e=Engine(); r=e.build(fiche,target_kind,target,str(asof)); rdir,pdf=export_report(r); st.session_state.report=r; st.session_state.pdf=str(pdf)

if c4:
    with st.spinner('Construction batch des 53 fiches...'):
        e=Engine(); rows=[]; root=ROOT/'output/batch'; root.mkdir(parents=True,exist_ok=True)
        for code in e.registry:
            try:
                r=e.build(code,'annual',year,str(asof)); export_report(r); rows.append({'fiche':code,'famille':r['family'],'cellules':len(r['cells']),'resolues':len(r['records']),'derivees':len(r['derived']),'non_resolues':len(r['unresolved']),'nowcasts':sum(x['status']=='NOWCAST' for x in r['records'])})
            except Exception as ex: rows.append({'fiche':code,'famille':e.registry[code]['family'],'fatal':repr(ex)})
        pd.DataFrame(rows).to_csv(ROOT/'output/batch/BATCH_SUMMARY.csv',index=False)
        st.session_state.batch=pd.DataFrame(rows)

r=st.session_state.get('report')
if r:
    rec=pd.DataFrame(r['records']); der=pd.DataFrame(r['derived']); un=pd.DataFrame(r['unresolved'])
    a,b,c,d,e,f=st.columns(6)
    a.metric('Cellules contrat',len(r['cells'])); b.metric('Résolues',len(rec)); c.metric('Dérivées',len(der)); d.metric('Non résolues',len(un)); e.metric('Nowcasts',sum(rec.status.eq('NOWCAST')) if not rec.empty else 0); f.metric('Séries live',r['series_index_stats']['live_series'])
    tabs=st.tabs(['📰 Pré-fiche','📊 Données','🔗 Provenance','📐 QA','🧠 Contrat métier','📚 Gabarit / figures'])
    with tabs[0]:
        html_path=ROOT/'output'/r['fiche']/f'{r["fiche"]}_{r["target"]}.pdf'; st.write(r['narrative'] if 'narrative' in r else 'Texte généré dans le PDF.');
        if Path(st.session_state.get('pdf','')).exists(): st.download_button('Télécharger le PDF',Path(st.session_state['pdf']).read_bytes(),file_name=Path(st.session_state['pdf']).name,mime='application/pdf')
    with tabs[1]: st.dataframe(rec,use_container_width=True,hide_index=True); st.dataframe(der,use_container_width=True,hide_index=True)
    with tabs[2]: st.dataframe(rec[[c for c in ['cell_id','label','value','status','method','provider','url','source_tier','confidence','semantic_score','lower','upper'] if c in rec]],use_container_width=True,hide_index=True)
    with tabs[3]: st.dataframe(pd.DataFrame(r['qa']),use_container_width=True,hide_index=True)
    with tabs[4]: st.json(r['reference_contract'],expanded=False)
    with tabs[5]:
        ref=st.session_state.get('reference_objects')
        st.info('Le BAT/CK sont visualisés ici comme gabarits et contrôles éditoriaux, jamais comme preuves cible.')
        if (ROOT/'data_lake/REFERENCE_OBJECTS.json').exists():
            objs=json.loads((ROOT/'data_lake/REFERENCE_OBJECTS.json').read_text(encoding='utf8')).get(r['fiche'],{}); st.json({'figures':objs.get('figures',[]),'tables':objs.get('tables',[]),'pages':[p.get('page') for p in objs.get('pages',[])]},expanded=False)

b=st.session_state.get('batch')
if b is not None:
    st.header('Benchmark BAT 2025 - toutes les fiches')
    st.dataframe(b,use_container_width=True,hide_index=True)
    st.download_button('Télécharger le résumé batch',b.to_csv(index=False).encode('utf-8-sig'),'BATCH_SUMMARY.csv','text/csv')

st.divider(); st.caption('V29 - source firewall actif. Le gabarit BAT 2024 / CK 2026 ne peut pas alimenter les valeurs cibles 2025/2026.')
