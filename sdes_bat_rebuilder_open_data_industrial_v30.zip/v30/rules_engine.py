from __future__ import annotations
import re, math
import numpy as np

FLOW_WORDS=('trafic','transport','voyageurs','voyageur-km','tonnes','tonnes-km','recettes','dépenses','production','investissement','consommation','émissions','créations','défaillances','immatriculations','accidents')
STOCK_WORDS=('parc','effectifs','entreprises','infrastructure','réseau','prix','indice','stock','salaire','qualité')


def normalize_unit(u):
    x=str(u or '').lower().replace('²','2').replace('€','eur')
    x=re.sub(r'\s+',' ',x)
    aliases={
      'milliards de voyageurs km':'milliards de voyageurs-km','milliards de voyageurs-km':'milliards de voyageurs-km',
      'milliards de tonnes km':'milliards de tonnes-km','milliards de tonnes-km':'milliards de tonnes-km',
      'milliards de vehicules km':'milliards de véhicules-km','milliards de véhicules-km':'milliards de véhicules-km',
    }
    return aliases.get(x,x)


def aggregation_policy(variable_type, measure_family=None, unit=''):
    v=str(variable_type or 'flow').lower()
    if v=='flow': return 'sum'
    if v in {'share','rate'}: return 'weighted_or_recompute'
    if v=='index': return 'mean'
    return 'last_or_mean'


def aggregate_periods(obs, target_year, target_kind='annual', target=None, variable_type='flow'):
    # obs = [{year, quarter, month, value, ...}]
    if target_kind=='annual':
        y=int(target_year if target is None else target)
        rows=[o for o in obs if int(o.get('year',-1))==y and o.get('value') is not None]
        if not rows:return None
        vals=[float(o['value']) for o in rows]
        n_month=sum(o.get('month') is not None for o in rows); n_q=sum(o.get('quarter') is not None for o in rows)
        if n_month>=2 or n_q>=2:
            p=aggregation_policy(variable_type)
            if p=='sum': return sum(vals), f'agrégation {len(vals)} observations -> annuel par somme'
            return float(np.mean(vals)), f'agrégation {len(vals)} observations -> annuel par moyenne'
        return vals[-1], 'observation annuelle/fin de période'
    y,q=target
    rows=[o for o in obs if int(o.get('year',-1))==int(y) and int(o.get('quarter',-1) or -1)==int(q) and o.get('value') is not None]
    if rows:return float(rows[-1]['value']), 'observation trimestrielle'
    months={1:[1,2,3],2:[4,5,6],3:[7,8,9],4:[10,11,12]}.get(int(q),[])
    rows=[o for o in obs if int(o.get('year',-1))==int(y) and int(o.get('month',-1) or -1) in months and o.get('value') is not None]
    if rows:
        vals=[float(o['value']) for o in rows]
        p=aggregation_policy(variable_type)
        return (sum(vals) if p=='sum' else float(np.mean(vals))), f'agrégation mensuelle {len(vals)} mois -> T{q}'
    return None


def formula_total(records, labels, total_label, unit=''):
    by={str(r.get('label','')).strip().lower():r for r in records}
    comps=[by.get(str(l).strip().lower()) for l in labels]
    if not all(comps): return None
    value=float(sum(c['value'] for c in comps))
    lower=float(sum(c.get('lower',c['value']) for c in comps)); upper=float(sum(c.get('upper',c['value']) for c in comps))
    conf=min(float(c.get('confidence',0.5)) for c in comps)
    return {'cell_id':'DERIVED:TOTAL','label':total_label,'value':value,'lower':lower,'upper':upper,'unit':unit,'status':'CALCULE','method':'somme cohérente des composantes','confidence':conf,'inputs':[c['cell_id'] for c in comps]}


def share(numerator, denominator, label):
    if numerator is None or denominator is None or denominator.get('value') in (None,0): return None
    v=100*float(numerator['value'])/float(denominator['value'])
    conf=min(float(numerator.get('confidence',.5)),float(denominator.get('confidence',.5)))
    return {'label':label,'value':v,'lower':v,'upper':v,'unit':'%','status':'CALCULE','method':'ratio sur même périmètre','confidence':conf,'inputs':[numerator['cell_id'],denominator['cell_id']]}


def reconcile_shares(shares, tol=1.5):
    vals=[float(s['value']) for s in shares if s.get('value') is not None]
    if not vals:return {'status':'NON_TESTE','sum':None,'detail':'aucune part disponible'}
    total=sum(vals); return {'status':'OK' if abs(total-100)<=tol else 'ALERTE','sum':total,'detail':f'somme des parts = {total:.2f}% (tolérance {tol:.2f} points)'}
