from __future__ import annotations
import json,re
from pathlib import Path
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parent
FICHES=json.loads((ROOT/'config/fiches_2024.json').read_text(encoding='utf-8'))

def extract(pdf):
    r=PdfReader(str(pdf)); pages=[]
    for i,p in enumerate(r.pages,1):
        t=p.extract_text() or ''
        lines=[re.sub(r'\s+',' ',x).strip() for x in t.splitlines() if x.strip()]
        figs=[]; tabs=[]; src=[]
        joined=' '.join(lines)
        for m in re.finditer(r'(?:Figure|Fig\.)\s+[A-Z]?[0-9]+(?:\.\d+)?[^.]{0,220}',joined,re.I): figs.append(m.group(0).strip())
        for m in re.finditer(r'Tableau\s+[A-Z]?[0-9]+(?:\.\d+)?[^.]{0,220}',joined,re.I): tabs.append(m.group(0).strip())
        for m in re.finditer(r'Sources?\s*:[^\n]{0,350}',joined,re.I): src.append(m.group(0).strip())
        pages.append({'page':i,'text':t,'figures':list(dict.fromkeys(figs)),'tables':list(dict.fromkeys(tabs)),'sources':list(dict.fromkeys(src))})
    return pages

def make_manifest():
    pdfs=list(ROOT.joinpath('reference').glob('*.pdf'))
    bat=None
    for p in pdfs:
        if 'BAT_2024' in p.name or 'bilan' in p.name.lower(): bat=p; break
    if not bat: return {}
    pages=extract(bat)
    starts=sorted([(k,int(v[1])) for k,v in FICHES.items()],key=lambda x:x[1])
    out={}
    for i,(code,start) in enumerate(starts):
        end=starts[i+1][1]-1 if i+1<len(starts) else start+5
        pp=[p for p in pages if start<=p['page']<=end]
        out[code]={'title':FICHES[code][0],'page_start':start,'page_end':end,'pages':pp,'figures':list(dict.fromkeys([f for p in pp for f in p['figures']])), 'tables':list(dict.fromkeys([t for p in pp for t in p['tables']])), 'sources':list(dict.fromkeys([s for p in pp for s in p['sources']]))}
    (ROOT/'data_lake/REFERENCE_OBJECTS.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8'); return out
if __name__=='__main__': print(len(make_manifest()))
