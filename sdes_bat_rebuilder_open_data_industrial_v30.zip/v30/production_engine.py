from __future__ import annotations
import json, math
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

from concept_engine import build_concept_registry, validate_registry
from source_router import rank_candidates, choose
from rules_engine import aggregate_periods, formula_total, share, reconcile_shares
from series import project, backtest, target_value
from series_diagnostics import quality
from review import review_queue

ROOT=Path(__file__).resolve().parent
RULES=json.loads((ROOT/'config/indicator_rules.json').read_text(encoding='utf-8'))

STATUS_RANK={'OFFICIEL':5,'RECONSTRUIT':4,'CALCULE':4,'ESTIME':3,'PROXY':2}


def _last_obs(s):
    obs=s.get('obs') or []
    if not obs:return None
    return max(obs,key=lambda x:(int(x.get('year',0) or 0),int(x.get('quarter',0) or 0),int(x.get('month',0) or 0)))


def resolve_cell(cell, series_idx, target_kind, target):
    candidates=rank_candidates(cell,series_idx,target)
    evaluated=[]
    for c in candidates[:20]:
        s=c.payload
        tv=target_value(s.get('obs',[]),target_kind,target,cell.get('variable_type','flow'))
        if tv:
            value,kind=tv; status='OFFICIEL' if kind=='direct' else 'RECONSTRUIT'; method=kind; uncertainty=0.0
        else:
            ag=aggregate_periods(s.get('obs',[]),target if target_kind=='annual' else target[0],target_kind,target,cell.get('variable_type','flow'))
            if ag:
                value,method=ag; status='RECONSTRUIT'; uncertainty=0.0
            else:
                pr=project(s.get('obs',[]),target_kind,target,cell.get('variable_type','flow'))
                if not pr: continue
                value=float(pr['value']); method=pr.get('method','projection'); status='ESTIME'; uncertainty=float(pr.get('uncertainty',.08))
        bt=backtest(s.get('obs',[]),cell.get('variable_type','flow'))
        diag=quality(s.get('obs',[]))
        last=_last_obs(s)
        conf=.40+.0035*c.semantic+.0015*c.source_priority+.08*c.freshness+.07*c.unit_fit+.06*c.scope_fit-.14*float(uncertainty)-.08*float(diag.get('break',{}).get('score',0))
        conf=max(.02,min(.995,conf))
        lo=float(value)*(1-uncertainty) if value>=0 else float(value)*(1+uncertainty)
        hi=float(value)*(1+uncertainty) if value>=0 else float(value)*(1-uncertainty)
        evaluated.append({'value':float(value),'lower':lo,'upper':hi,'status':status,'method':method,'confidence':round(conf,3),'uncertainty':uncertainty,
          'backtest_mae_pct':bt,'frequency':s.get('frequency'),'source':s.get('source'),'url':s.get('url'),'provider':s.get('provider'),'sheet':s.get('sheet'),'row':s.get('row'),
          'matched_label':s.get('label'),'semantic_score':round(c.semantic,1),'unit':cell.get('expected_units',[s.get('unit','')])[0] if cell.get('expected_units') else s.get('unit',''),
          'source_unit':s.get('unit',''),'last_observation':last,'freshness':round(c.freshness,3),'unit_fit':round(c.unit_fit,3),'scope_fit':round(c.scope_fit,3),
          'break_detected':bool(diag.get('break',{}).get('detected')),'break_score':float(diag.get('break',{}).get('score',0)),
          'n_obs':diag.get('n_numeric',0),'span_years':diag.get('span_years',0), 'source_priority':c.source_priority})
    if not evaluated:return None
    evaluated.sort(key=lambda x:(STATUS_RANK[x['status']],x['confidence'],x['semantic_score']),reverse=True)
    best=evaluated[0]; best['alternatives']=evaluated[1:6]
    return best


def derive_for_rule(fiche, rec):
    rule=RULES.get(fiche,{})
    out=[]
    comps=rule.get('components',{})
    if rule.get('total') and all(any(str(r.get('label','')).lower()==str(k).lower() for r in rec) for k in comps):
        labels=list(comps.keys())
        d=formula_total(rec,labels,rule['total']['label'],rule['total'].get('unit',''))
        if d: out.append(d)
        total=d
        if total:
            for r in rec:
                if str(r.get('label','')).lower() in {str(k).lower() for k in labels}:
                    sh=share(r,total,f"Part de {r['label']}")
                    if sh:
                        sh['cell_id']=r['cell_id']+':SHARE'; sh['role']='derived_share'; out.append(sh)
            shares=[x for x in out if x.get('role')=='derived_share']
            chk=reconcile_shares(shares)
            out.append({'cell_id':f'{fiche}:SHARE_CHECK','label':'Contrôle somme des parts','value':chk.get('sum'),'status':chk['status'],'method':chk['detail'],'unit':'%','confidence':1.0})
    return out


def build_production(fiche, ctx, target_kind='annual', target=2025):
    registry=ctx['registry']; meta=registry[fiche]
    rec=[]; unresolved=[]
    for cell in meta['cells']:
        # Only cells representing measurable concepts should be sent to the source resolver.
        if cell.get('role') not in {'component','total','main','editorial_candidate'}:
            unresolved.append({**cell,'reason':'role non résolu'}); continue
        rr=resolve_cell(cell,ctx['series_idx'],target_kind,target)
        if rr:
            rr.update({'cell_id':cell['cell_id'],'label':cell['label'],'role':cell['role'],'mandatory':cell['mandatory'],'measure_family':cell['measure_family'],'expected_units':cell['expected_units']})
            # Unit mismatch is a hard-ish warning, not an automatic rejection.
            if rr.get('unit_fit',0)<.35:
                rr['review_reason']='unité potentiellement incompatible'
            rec.append(rr)
        else:
            unresolved.append({**cell,'reason':'aucune série suffisamment compatible'})
    derived=derive_for_rule(fiche,rec)
    checks=[]
    mandatory=sum(1 for c in meta['cells'] if c.get('mandatory'))
    resolved=sum(r.get('value') is not None for r in rec)
    checks.append({'test':'Couverture des cellules','status':'OK' if resolved==len(meta['cells']) else ('ALERTE' if resolved else 'ECHEC'),'detail':f'{resolved}/{len(meta["cells"])}'})
    checks.append({'test':'Couverture obligatoire','status':'OK' if resolved>=mandatory else 'ALERTE','detail':f'{resolved}/{mandatory}'})
    negatives=[r for r in rec if r.get('unit')!='%' and float(r.get('value',0))<0]
    checks.append({'test':'Valeurs négatives','status':'ALERTE' if negatives else 'OK','detail':len(negatives)})
    low=[r for r in rec if float(r.get('semantic_score',0))<55]
    checks.append({'test':'Matching sémantique faible','status':'ALERTE' if low else 'OK','detail':len(low)})
    stale=[r for r in rec if float(r.get('freshness',0))<.35]
    checks.append({'test':'Sources anciennes','status':'ALERTE' if stale else 'OK','detail':len(stale)})
    breaks=[r for r in rec if r.get('break_detected')]
    checks.append({'test':'Alertes de rupture','status':'ALERTE' if breaks else 'OK','detail':len(breaks)})
    quality_score=max(0,min(100,100-15*len(unresolved)-5*len(low)-5*len(stale)-5*len(breaks)))
    ck_pages=[]
    # Preserve full CK page objects matched to this fiche, not just page numbers.
    try:
        for p in ctx.get('ck',[]):
            if fiche in set(p.get('bat_refs',[])):
                ck_pages.append(p)
    except Exception:
        ck_pages=[]
    return {'version':'9.0.0','fiche':fiche,'title':meta['title'],'family':meta['family'],'target_kind':target_kind,'target':target,
      'created_at':datetime.now(timezone.utc).isoformat(),'open_data_only':True,
      'reference':{'bat':{'title':meta['title'],'page_start':meta['page_start'],'page_end':meta['pages'][-1]['page'] if meta.get('pages') else meta['page_start'],'pages':meta['pages'],'figures':[x.get('caption','') for x in meta['figures']],'tables':[x.get('caption','') for x in meta['tables']],'sources':meta['sources']},'ck':ck_pages},
      'cells':meta['cells'],'records':rec,'derived':derived,'unresolved':unresolved,
      'editorial':{'pages':meta['pages'],'figures':meta['figures'],'tables':meta['tables'],'sources':meta['sources'],'ck_pages':meta['ck_pages']},
      'taxonomy':meta['taxonomy'],'claims':meta['claims'],'checks':checks,'quality_score':quality_score,
      'series_index_stats':{'series_considered':len(ctx['series_idx']),'errors':ctx.get('series_errors',[])},
      'review_queue':review_queue(rec,unresolved),
      'engine':{'registry_version':'9','resolution':'conceptual source router + deterministic transforms + ensemble estimation','status_order':['OFFICIEL','RECONSTRUIT','CALCULE','ESTIME','PROXY'],'design':'metadata-driven cell graph with versioned business rules'}}


def prepare_production_context(prepare_context_fn):
    ctx=prepare_context_fn()
    ctx['registry']=build_concept_registry(ctx['bat'],ctx['ck'])
    ctx['registry_errors']=validate_registry(ctx['registry'])
    return ctx
