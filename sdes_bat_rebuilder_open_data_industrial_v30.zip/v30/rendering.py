from __future__ import annotations
import base64, html, io, json, re
from pathlib import Path
import pandas as pd
import numpy as np
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.utils import ImageReader
from catalog import get_bytes
from pdf_assets import page_png, page_tables


def fmt(v):
    if v is None or (isinstance(v,float) and not np.isfinite(v)): return '—'
    x=float(v)
    if abs(x)>=1000:return f'{x:,.0f}'.replace(',',' ')
    if abs(x)>=100:return f'{x:,.1f}'.replace(',',' ')
    return f'{x:,.2f}'.replace('.',',')

def target_label(t): return f'T{t[1]} {t[0]}' if isinstance(t,tuple) else str(t)

def render_html(r, include_reference=True):
    rec=r['records']; by={str(x.get('component','')).lower():x for x in rec}
    rows=[]
    for x in rec + r.get('derived',[]):
        rows.append(f"<tr><td>{html.escape(str(x.get('component','')))}</td><td>{fmt(x.get('value'))}</td><td>{html.escape(str(x.get('status','')))}</td><td>{x.get('confidence',0):.0%}</td><td>{html.escape(str(x.get('method','')))}</td><td>{html.escape(str(x.get('source','')))}</td></tr>")
    fig_html=[]
    for el in r['reference']['bat'].get('figures',[]):
        fig_html.append(f'<div class="asset"><b>{html.escape(el)}</b><div class="asset-note">Figure extraite du gabarit BAT 2024 ; la version reconstruite utilise les séries résolues ci-dessous.</div></div>')
    tab_html=[]
    for el in r['reference']['bat'].get('tables',[]): tab_html.append(f'<div class="asset"><b>{html.escape(el)}</b><div class="asset-note">Tableau détecté dans le gabarit ; extraction structurée visible dans l’audit de page.</div></div>')
    ck_html=[]
    for p in r['reference']['ck']:
        for f in p.get('figures',[]): ck_html.append(f'<div class="asset"><b>Chiffres clés 2026 — p.{p["page"]}: {html.escape(f)}</b><div class="asset-note">Correspondance vers {html.escape(str(p.get("bat_refs")))}</div></div>')
    unresolved=''.join(f'<li>{html.escape(str(x.get("label")))}</li>' for x in r['unresolved']) or '<li>Aucun slot non résolu.</li>'
    checks=''.join(f'<tr><td>{html.escape(c["test"])}</td><td>{c["status"]}</td><td>{html.escape(str(c["detail"]))}</td></tr>' for c in r['checks'])
    return f'''<!doctype html><html lang="fr"><head><meta charset="utf-8"><title>{html.escape(r['fiche'])} — BAT 2025 open data V7</title><style>
body{{margin:0;background:#eef1f4;font-family:Arial,sans-serif;color:#17212b}}.page{{width:178mm;min-height:250mm;margin:10mm auto;background:#fff;padding:15mm;box-sizing:border-box}}.band{{height:6px;background:#2f75b5;margin:-15mm -15mm 10mm}}h1{{font-size:25px;margin:0 0 7px}}h2{{font-size:15px;margin-top:18px;border-bottom:1px solid #c9d3dc;padding-bottom:5px;color:#2f75b5}}h3{{font-size:11px;margin:10px 0 4px}}.lead{{font-size:12.5px;font-weight:600}}.notice{{font-size:9px;background:#edf5fb;border-left:4px solid #2f75b5;padding:8px;margin:10px 0}}.asset{{border:1px solid #d3dbe2;padding:8px;margin:6px 0;font-size:9px}}.asset-note{{color:#62717e;margin-top:4px}}table{{border-collapse:collapse;width:100%;font-size:8px}}th,td{{border:1px solid #cfd7de;padding:5px;vertical-align:top}}th{{background:#eef3f7}}small{{color:#687782}}.badge{{display:inline-block;border-radius:4px;background:#eef3f7;padding:3px 6px;margin-right:4px;font-size:8px}}</style></head><body><section class="page"><div class="band"></div><h1>{html.escape(r['fiche'])}. {html.escape(r['title'])}</h1><div class="lead">Pré-version open data du millésime {html.escape(target_label(r.get('target','')))}</div><div class="notice"><b>Co-production simulée :</b> le même socle de données alimente le BAT 2025 et les Chiffres clés des transports 2026. Les données internes non publiques ne sont pas utilisées.</div><p><span class="badge">{len(r['records'])} cellules résolues</span><span class="badge">{len(r['unresolved'])} non résolues</span><span class="badge">{r['series_index_stats']['series_considered']} séries explorées</span></p><h2>Gabarit et objets éditoriaux</h2><p>Le gabarit du BAT 2024 est conservé comme référence de structure. Les figures, tableaux, sources et correspondances Chiffres clés sont recensés séparément.</p>{''.join(fig_html)}{''.join(tab_html)}{''.join(ck_html)}<h2>Résultats chiffrés reconstruits</h2><table><thead><tr><th>Indicateur</th><th>Valeur</th><th>Statut</th><th>Conf.</th><th>Méthode</th><th>Source</th></tr></thead><tbody>{''.join(rows)}</tbody></table><h2>Séries longues / provenance</h2><p>Le registre machine conserve la série source, l'onglet, la ligne, la fréquence, la dernière observation et les alternatives de résolution. Le détail complet figure dans le JSON/CSV d'audit.</p><h2>Contrôles</h2><table><thead><tr><th>Test</th><th>Statut</th><th>Détail</th></tr></thead><tbody>{checks}</tbody></table><h2>Slots non résolus</h2><ul>{unresolved}</ul><small>Généré {html.escape(r['created_at'])}. Voir JSON/CSV pour la provenance complète.</small></section></body></html>'''


def generate_pdf(r,out_path):
    doc=SimpleDocTemplate(str(out_path),pagesize=A4,rightMargin=28,leftMargin=28,topMargin=30,bottomMargin=28)
    st=getSampleStyleSheet(); title=ParagraphStyle('t',parent=st['Title'],fontSize=19,leading=22); h=ParagraphStyle('h',parent=st['Heading2'],fontSize=12,leading=14,textColor=colors.HexColor('#2f75b5')); body=ParagraphStyle('b',parent=st['BodyText'],fontSize=8.5,leading=10.5)
    flow=[Paragraph(f"{r['fiche']}. {r['title']}",title),Paragraph(f"Pré-version open data — {target_label(r.get('target',''))}",body),Spacer(1,8),Paragraph('Co-production simulée : BAT 2025 + Chiffres clés 2026, à partir de données publiques uniquement.',body),Spacer(1,10)]
    flow += [Paragraph('Objets éditoriaux recensés',h)]
    objs=[]
    for p in r['reference']['bat']['pages']:
        for f in p.get('figures',[]):objs.append(['Figure',f,f'p.{p["page"]}'])
        for t in p.get('tables',[]):objs.append(['Tableau',t,f'p.{p["page"]}'])
    if objs:
        flow.append(Table([['Type','Objet','Page']]+objs,colWidths=[55,395,45],repeatRows=1,style=TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#edf3f8')),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#bfc9d2')),('FONTSIZE',(0,0),(-1,-1),7),('VALIGN',(0,0),(-1,-1),'TOP')])))
    flow += [Spacer(1,10),Paragraph('Résultats et provenance',h)]
    data=[['Indicateur','Valeur','Statut','Conf.','Méthode','Source']]
    for x in r['records']: data.append([x.get('component',''),fmt(x.get('value')),x.get('status',''),f"{x.get('confidence',0):.0%}",x.get('method',''),str(x.get('source',''))[:55]])
    flow.append(Table(data,colWidths=[105,45,55,40,125,105],repeatRows=1,style=TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#edf3f8')),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#bfc9d2')),('FONTSIZE',(0,0),(-1,-1),6.6),('VALIGN',(0,0),(-1,-1),'TOP')])))
    flow += [Spacer(1,8),Paragraph('Contrôles',h),Table([['Test','Statut','Détail']]+[[c['test'],c['status'],str(c['detail'])] for c in r['checks']],colWidths=[145,55,280],repeatRows=1,style=TableStyle([('GRID',(0,0),(-1,-1),.3,colors.HexColor('#bfc9d2')),('BACKGROUND',(0,0),(-1,0),colors.HexColor('#edf3f8')),('FONTSIZE',(0,0),(-1,-1),7)]))]
    doc.build(flow)


def export_bundle(r,out_dir):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    (out/'report.json').write_text(json.dumps(r,ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    pd.DataFrame(r['records']).to_csv(out/'cell_audit.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(r['unresolved']).to_csv(out/'unresolved.csv',index=False,encoding='utf-8-sig')
    html_path=out/'fiche.html';html_path.write_text(render_html(r),encoding='utf-8')
    pdf=out/f"{r['fiche'].replace('/','_')}_{target_label(r.get('target','')).replace(' ','_')}.pdf"; generate_pdf(r,pdf)
    # Create a lightweight source map.
    # Archive exact reference pages used by the fiche (BAT + Chiffres clés) for visual comparison.
    try:
        from catalog import CFG, get_bytes
        from pdf_assets import page_png
        bp=out/'reference_pages'; bp.mkdir(exist_ok=True)
        bat_pdf,_=get_bytes(CFG['reference_bat']['pdf'],30)
        for pg in r['reference']['bat'].get('pages',[]): (bp/f"BAT_{pg['page']:03d}.png").write_bytes(page_png(bat_pdf,pg['page']))
        if r['reference'].get('ck'):
            ck_pdf,_=get_bytes(CFG['chiffres_cles']['pdf'],30)
            for pg in r['reference']['ck']: (bp/f"CK2026_{pg['page']:03d}.png").write_bytes(page_png(ck_pdf,pg['page']))
    except Exception as e:
        (out/'reference_pages_error.txt').write_text(repr(e),encoding='utf-8')
    (out/'README_AUDIT.txt').write_text(f"Fiche: {r['fiche']}\nCible: {target_label(r.get('target',''))}\nMode: {r['edition_mode']}\nOpen data only: oui\nSources/series: {r['series_index_stats']['series_considered']}\n",encoding='utf-8')
    return {'html':html_path,'pdf':pdf,'json':out/'report.json','csv':out/'cell_audit.csv','unresolved':out/'unresolved.csv'}

def export_batch(results, out_zip):
    """Build one auditable ZIP containing all fiche reports + machine-readable registry."""
    from pathlib import Path
    import zipfile, json, pandas as pd
    staging=Path(out_zip).with_suffix('')
    staging.mkdir(parents=True,exist_ok=True)
    registry=[]
    for r in results:
        if 'fatal' in r:
            registry.append({'fiche':r.get('fiche'),'fatal':r['fatal']}); continue
        d=staging/r['fiche'].replace('/','_'); d.mkdir(parents=True,exist_ok=True)
        paths=export_bundle(r,d)
        registry.append({'fiche':r['fiche'],'title':r['title'],'target':r['target'],'records':len(r['records']),'unresolved':len(r['unresolved']),'series_considered':r['series_index_stats']['series_considered'],'pdf':str(Path(paths['pdf']).relative_to(staging)),'html':str(Path(paths['html']).relative_to(staging))})
    (staging/'registry.json').write_text(json.dumps(registry,ensure_ascii=False,indent=2),encoding='utf-8')
    zip_path=Path(out_zip)
    with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
        for p in staging.rglob('*'):
            if p.is_file() and p != zip_path:z.write(p,p.relative_to(staging.parent))
    return zip_path
