from __future__ import annotations
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
import json, math, re
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT=Path(__file__).resolve().parent

@dataclass(frozen=True)
class Evidence:
    id: str
    fiche: str
    label: str
    value: float
    unit: str
    status: str
    provider: str
    published: str
    url: str
    role: str = 'target'
    note: str = ''
    period: str = '2025'

PUBLIC = [
    Evidence('F4-total-2025','F4','Trafic aérien commercial total en France',183.02,'millions de passagers','OFFICIEL_PUBLIC','DGAC','2026-02-01','https://www.ecologie.gouv.fr/politiques-publiques/statistiques-du-trafic-aerien','target'),
    Evidence('F4-metropole-2025','F4','Trafic aérien commercial en métropole',178.15,'millions de passagers','OFFICIEL_PUBLIC','DGAC','2026-02-01','https://www.ecologie.gouv.fr/politiques-publiques/statistiques-du-trafic-aerien','target'),
    Evidence('F4-domestic-2025','F4','Trafic intérieur métropolitain',19.63,'millions de passagers','OFFICIEL_PUBLIC','DGAC','2026-02-01','https://www.ecologie.gouv.fr/politiques-publiques/statistiques-du-trafic-aerien','target'),
    Evidence('F4-intl-2025','F4','Trafic international métropole',153.51,'millions de passagers','OFFICIEL_PUBLIC','DGAC','2026-02-01','https://www.ecologie.gouv.fr/politiques-publiques/statistiques-du-trafic-aerien','target'),
    Evidence('F4-lowcost-2025','F4','Trafic des transporteurs à bas coût',79.9,'millions de passagers','OFFICIEL_PUBLIC','DGAC','2026-01-01','https://www.ecologie.gouv.fr/politiques-publiques/analyses-du-transport-aerien','target'),
    Evidence('F4-lowcost-share-2025','F4','Part du trafic des transporteurs à bas coût',44.8,'%','OFFICIEL_PUBLIC','DGAC','2026-01-01','https://www.ecologie.gouv.fr/politiques-publiques/analyses-du-transport-aerien','target',note='Part du trafic total 2025; stable sur un an.'),
    Evidence('F4-total-2024','F4','Trafic aérien commercial total en France',178.3,'millions de passagers','OBSERVATION_PRODUCTEUR','DGAC','2025-01-01','https://www.ecologie.gouv.fr/sites/default/files/documents/dta_note_conjoncture_trimestrielle_trafic_aerien_t4_2024.pdf','auxiliary'),
    Evidence('D21-transport-delta','D2.1','Variation des émissions de GES des transports',-4.3,'%','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/emissions-de-gaz-a-effet-de-serre-en-france-apercu-du-premier-trimestre-de-lannee-2025-avec-le-barometre-du-citepa/','target',note='Estimation du baromètre Citepa pour T1 2026 vs T1 2025.',period='T1 2026'),
    Evidence('D21-transport-deltaMt','D2.1','Variation des émissions de GES des transports',-1.2,'Mt CO2e','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/emissions-de-gaz-a-effet-de-serre-en-france-apercu-du-premier-trimestre-de-lannee-2025-avec-le-barometre-du-citepa/','target',note='Variation absolue estimée par le producteur.',period='T1 2026'),
    Evidence('D21-national-2026','D2.1','Émissions nationales de GES hors UTCATF',98.1,'Mt CO2e','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/le-rapport-secten-edition-2026-est-en-ligne/','auxiliary',period='T1 2026'),
    Evidence('D21-national-2025','D2.1','Émissions nationales de GES hors UTCATF',103.5,'Mt CO2e','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/le-rapport-secten-edition-2026-est-en-ligne/','auxiliary',period='T1 2025'),
    Evidence('D21-diesel','D2.1','Ventes de gazole',-5.7,'%','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/emissions-de-gaz-a-effet-de-serre-en-france-apercu-du-premier-trimestre-de-lannee-2025-avec-le-barometre-du-citepa/','auxiliary',note='Variation T1 2026/T1 2025; signal explicatif.'),
    Evidence('D21-air-dom','D2.1','Émissions du transport aérien domestique',6.4,'%','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/emissions-de-gaz-a-effet-de-serre-en-france-apercu-du-premier-trimestre-de-lannee-2025-avec-le-barometre-du-citepa/','auxiliary',note='Variation T1 2026/T1 2025.'),
    Evidence('D22-NOx','D2.2','Émissions de NOx des transports',-2.0,'%','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/donnees-air-climat/polluants-atmospheriques/','auxiliary',period='T1 2026'),
    Evidence('D22-PM25','D2.2','Émissions de PM2,5 des transports',-7.9,'%','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/donnees-air-climat/polluants-atmospheriques/','auxiliary',period='T1 2026'),
    Evidence('D22-COVNM','D2.2','Émissions de COVNM des transports',-3.4,'%','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/donnees-air-climat/polluants-atmospheriques/','auxiliary',period='T1 2026'),
    Evidence('D22-SO2','D2.2','Émissions de SO2 des transports',-0.6,'%','ESTIMATION_PRODUCTEUR','Citepa','2026-07-08','https://www.citepa.org/donnees-air-climat/polluants-atmospheriques/','auxiliary',period='T1 2026'),
]

F_CONTRACTS=json.loads((ROOT/'config/f_contracts.json').read_text(encoding='utf8'))
D_CONTRACTS=json.loads((ROOT/'config/d_contracts.json').read_text(encoding='utf8'))


def facts(fiche, period=None, role=None):
    xs=[asdict(x) for x in PUBLIC if x.fiche==fiche]
    if period: xs=[x for x in xs if x['period']==period or x['role']=='auxiliary']
    if role: xs=[x for x in xs if x['role']==role]
    return xs


def fmt(x, decimals=1):
    if x is None:return 'n.d.'
    return f'{float(x):,.{decimals}f}'.replace(',', ' ').replace('.', ',')


def build_f4_2025():
    fs=facts('F4','2025','target'); by={f['label']:f for f in fs}
    total=by['Trafic aérien commercial total en France']['value']; base=next(f.value for f in PUBLIC if f.id=='F4-total-2024')
    yoy=(total/base-1)*100
    return {
        'fiche':'F4','title':F_CONTRACTS['F4']['title'],'target':'2025','period_label':'en 2025','family':'voyageurs',
        'headline':f"En 2025, le trafic aérien commercial atteint {fmt(total,1)} millions de passagers en France, soit environ {yoy:+.1f} % sur un an.",
        'paragraphs':[
            f"Le trafic aérien commercial atteint {fmt(total,1)} millions de passagers en 2025. En métropole, il s’établit à {fmt(by['Trafic aérien commercial en métropole']['value'],1)} millions. Ces résultats confirment la poursuite de la reprise du trafic aérien, après les années marquées par la crise sanitaire.",
            f"Le trafic intérieur métropolitain représente {fmt(by['Trafic intérieur métropolitain']['value'],1)} millions de passagers, contre {fmt(by['Trafic international métropole']['value'],1)} millions pour les liaisons internationales de la métropole. L’international concentre donc l’essentiel du trafic métropolitain.",
            f"Les transporteurs à bas coût acheminent {fmt(by['Trafic des transporteurs à bas coût']['value'],1)} millions de passagers, soit {fmt(by['Part du trafic des transporteurs à bas coût']['value'],1)} % du trafic. La DGAC indique que leur part de marché reste stable par rapport à 2024, tandis que leur croissance ralentit à +3 %.",
        ],
        'records':fs+[next(asdict(x) for x in PUBLIC if x.id=='F4-total-2024')],
        'figures':[{'title':'Trafic aérien commercial en France','kind':'bar_compare','data':{'labels':['2024','2025'],'values':[base,total]},'unit':'millions de passagers'},
                   {'title':'Trafic de la métropole : intérieur / international','kind':'stack','data':{'labels':['2025'],'parts':[by['Trafic intérieur métropolitain']['value'],by['Trafic international métropole']['value']],'names':['Intérieur','International']},'unit':'millions de passagers'},
                   {'title':'Transporteurs à bas coût','kind':'single_share','data':{'value':by['Part du trafic des transporteurs à bas coût']['value'],'label':'Part du trafic total'},'unit':'%' }],
        'table':[
            ['Indicateur','2025','Évolution / note'],
            ['Trafic total France',fmt(total,1),'+'+fmt(yoy,1)+' % vs 2024'],
            ['Trafic métropole',fmt(by['Trafic aérien commercial en métropole']['value'],1),'millions de passagers'],
            ['Trafic intérieur métropolitain',fmt(by['Trafic intérieur métropolitain']['value'],1),'millions de passagers'],
            ['Trafic international métropole',fmt(by['Trafic international métropole']['value'],1),'millions de passagers'],
            ['Transporteurs à bas coût',fmt(by['Trafic des transporteurs à bas coût']['value'],1),'+3 % vs 2024'],
            ['Part des bas coûts',fmt(by['Part du trafic des transporteurs à bas coût']['value'],1),'stable vs 2024'],
        ],
        'sources':sorted({x['url'] for x in fs}),
        'reference_note':'Le BAT 2024 sert ici uniquement à définir la structure éditoriale et les objets à actualiser; aucun chiffre du BAT n’est utilisé comme preuve cible.'
    }


def build_d21_t1_2026():
    fs=facts('D2.1','T1 2026'); delta=next(f.value for f in PUBLIC if f.id=='D21-transport-deltaMt'); rate=next(f.value for f in PUBLIC if f.id=='D21-transport-delta')
    # Explicitly treat the implied levels as calculated from rounded producer estimates.
    base=abs(delta)/abs(rate/100); cur=base+delta
    return {
        'fiche':'D2.1','title':D_CONTRACTS['D2.1']['title'],'target':'T1 2026','period_label':'au premier trimestre 2026','family':'environnement',
        'headline':f"Au premier trimestre 2026, les émissions de GES des transports diminuent de {abs(rate):.1f} %, soit {abs(delta):.1f} Mt CO2e par rapport au premier trimestre 2025.",
        'paragraphs':[
            f"Au premier trimestre 2026, les émissions de gaz à effet de serre des transports diminuent de {abs(rate):.1f} % par rapport au même trimestre de 2025, soit une baisse estimée de {abs(delta):.1f} Mt CO2e. À partir des deux variations publiées par le Citepa, les niveaux implicites sont d’environ {fmt(base,1)} Mt CO2e au T1 2025 et {fmt(cur,1)} Mt CO2e au T1 2026. Ces deux niveaux sont des calculs sur données arrondies et non des observations publiées directement.",
            f"La baisse du secteur est notamment associée au recul de 5,7 % des ventes de gazole au premier trimestre, avec une diminution particulièrement forte en janvier (-10,6 %). Le Citepa relie cette évolution aux émissions des voitures particulières, des poids lourds et des bus et cars diesel.",
            f"À l’inverse, les émissions du transport aérien domestique, incluses dans le total national, augmentent de 6,4 % sur un an. Le mouvement sectoriel s’inscrit dans une baisse plus large des émissions nationales hors UTCATF, estimées à 98,1 Mt CO2e au T1 2026 contre 103,5 Mt au T1 2025.",
        ],
        'records':fs,
        'figures':[{'title':'Émissions de GES des transports — niveaux implicites','kind':'bar_compare','data':{'labels':['T1 2025','T1 2026'],'values':[base,cur]},'unit':'Mt CO2e','disclaimer':'Niveaux calculés à partir des variations publiées; arrondis du producteur.'},
                   {'title':'Principaux signaux d’évolution publiés','kind':'drivers','data':{'labels':['Transports','Ventes gazole','Aérien domestique'],'values':[rate,-5.7,6.4]},'unit':'% vs T1 2025'},
                   {'title':'Contexte national — émissions hors UTCATF','kind':'bar_compare','data':{'labels':['T1 2025','T1 2026'],'values':[103.5,98.1]},'unit':'Mt CO2e','disclaimer':'Champ national; contexte, pas mesure du seul transport.'}],
        'table':[
            ['Indicateur','T1 2026','Lecture'],
            ['GES des transports',fmt(cur,1)+' Mt CO2e','niveau implicite'],
            ['Évolution des GES transports',fmt(rate,1)+' %','estimation Citepa'],
            ['Variation absolue',fmt(delta,1)+' Mt CO2e','estimation Citepa'],
            ['Ventes de gazole',fmt(-5.7,1)+' %','signal explicatif'],
            ['Aérien domestique',fmt(6.4,1)+' %','signal sectoriel'],
        ],
        'sources':sorted({x['url'] for x in fs}),
        'reference_note':'Le BAT 2024/CK 2026 ne fournit aucun chiffre cible ici; il sert seulement de spécification. Les niveaux T1 sont recalculés à partir de variations Citepa arrondies.'
    }


def build_pair_parallel():
    tasks={'F4_2025':build_f4_2025,'D2.1_T1_2026':build_d21_t1_2026}; out={}
    with ThreadPoolExecutor(max_workers=2) as ex:
        fs={ex.submit(fn):name for name,fn in tasks.items()}
        for f in as_completed(fs):
            out[fs[f]]=f.result()
    return out


def write_json(report, path):
    path.parent.mkdir(parents=True,exist_ok=True); path.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
