from __future__ import annotations
import json
from pathlib import Path
import pandas as pd
from engine_v28 import Engine
from render_v29 import export_report
ROOT=Path(__file__).resolve().parent

def run():
    e=Engine(); rows=[]; reports=[]
    for code in e.registry:
        try:
            r=e.build(code,'annual',2025,'2026-08-29'); reports.append(r)
            statuses={s:int(sum(x.get('status')==s for x in r['records'])) for s in sorted(set(x.get('status') for x in r['records']))}
            rows.append({'fiche':code,'famille':r['family'],'cells':len(r['cells']),'resolved':len(r['records']),'unresolved':len(r['unresolved']),'nowcast':sum(x.get('status')=='NOWCAST' for x in r['records']),'direct_public':sum(x.get('status') in {'OFFICIEL_PUBLIC','PROVISOIRE_PUBLIC','ESTIMATION_PRODUCTEUR','PROXY_PRODUCTEUR','CALCULATED_PUBLIC_ESTIMATE'} for x in r['records']),'statuses':json.dumps(statuses,ensure_ascii=False)})
            if code in {'F4','D2.1','A10','C1','E4','E5','G2'}: export_report(r)
        except Exception as ex:
            rows.append({'fiche':code,'famille':e.registry[code]['family'],'cells':len(e.registry[code]['cells']),'resolved':0,'unresolved':len(e.registry[code]['cells']),'nowcast':0,'direct_public':0,'fatal':repr(ex)})
    df=pd.DataFrame(rows); df.to_csv(ROOT/'output/BENCHMARK_ALL_FAMILIES.csv',index=False)
    fam=df.groupby('famille',dropna=False)[['cells','resolved','unresolved','nowcast','direct_public']].sum().reset_index()
    fam.to_csv(ROOT/'output/BENCHMARK_BY_FAMILY.csv',index=False)
    (ROOT/'output/BENCHMARK_ALL_FAMILIES.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
    md=['# Benchmark V29 — 53 fiches / open data','',f'- Fiches : {len(df)}',f'- Cellules contractuelles : {int(df.cells.sum())}',f'- Cellules résolues : {int(df.resolved.sum())}',f'- Non résolues : {int(df.unresolved.sum())}',f'- Nowcasts : {int(df.nowcast.sum())}','', '## Par famille','',fam.to_markdown(index=False)]
    (ROOT/'output/BENCHMARK_ALL_FAMILIES.md').write_text('\n'.join(md),encoding='utf8')
    return df,fam
if __name__=='__main__':
    df,fam=run(); print(fam.to_string(index=False))
