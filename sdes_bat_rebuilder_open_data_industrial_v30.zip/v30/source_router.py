from __future__ import annotations
import math, re
from dataclasses import dataclass
from rapidfuzz.fuzz import token_set_ratio, ratio

STATUS_RANK={'OFFICIEL':100,'RECONSTRUIT':90,'CALCULE':85,'ESTIME':65,'PROXY':40}

@dataclass
class Candidate:
    payload:dict
    score:float
    semantic:float
    source_priority:float
    freshness:float
    unit_fit:float
    scope_fit:float


def _freshness(last_obs, target):
    if not last_obs:return 0.2
    ty=int(target[0] if isinstance(target,tuple) else target)
    ly=int(last_obs.get('year',0) or 0)
    gap=max(0,ty-ly)
    return max(0.0,1.0-gap/8.0)


def _unit_fit(expected, actual):
    e=' '.join(str(x).lower() for x in (expected or [])); a=str(actual or '').lower()
    if not e:return .5
    if any(x and x in a for x in expected): return 1.0
    # dimensional hints
    dims=[('voyageurs-km',['voyageur','voyages']),('tonnes-km',['tonne']),('euros',['euro','eur','€']),('%',['%','pour cent']),('véhicules',['vehicule']),('salariés',['salari'])]
    for _,ws in dims:
        if any(w in e for w in ws) and any(w in a for w in ws): return .8
    return .2


def _scope_fit(cell, series):
    text=' '.join([str(series.get('label','')),str(series.get('source','')),str(series.get('scope','')),str(series.get('provider',''))]).lower()
    label=str(cell.get('label','')).lower()
    # negative scope terms are deliberately conservative
    if 'intérieur' in label and 'international' in text: return .25
    if 'france' in label and 'france' not in text and 'national' not in text: return .7
    return 1.0


def rank_candidates(cell, series_list, target):
    aliases=cell.get('aliases') or [cell.get('label','')]
    out=[]
    for s in series_list:
        label=str(s.get('label',''))
        sem=max(token_set_ratio(str(a),label) for a in aliases) if label else 0
        sem2=max(ratio(str(a),label) for a in aliases) if label else 0
        semantic=0.75*sem+0.25*sem2
        if semantic < 34: continue
        last=(s.get('obs') or [{}])[-1] if s.get('obs') else None
        freshness=_freshness(last,target)
        unit_fit=_unit_fit(cell.get('expected_units'),s.get('unit'))
        scope_fit=_scope_fit(cell,s)
        provider_priority=float(s.get('source_priority',s.get('priority',70)) or 70)
        # Explicit provider priorities from the cell's taxonomy.
        pids=cell.get('priority_providers',[])
        provider=s.get('provider','')
        if provider in pids:
            provider_priority=min(100,provider_priority+8)
        total=.50*(semantic/100)+.16*unit_fit+.14*scope_fit+.12*freshness+.08*(provider_priority/100)
        out.append(Candidate(s,total,semantic,provider_priority,freshness,unit_fit,scope_fit))
    return sorted(out,key=lambda c:c.score,reverse=True)


def choose(candidates):
    if not candidates:return None,[]
    best=candidates[0]
    return best.payload,candidates[1:6]
