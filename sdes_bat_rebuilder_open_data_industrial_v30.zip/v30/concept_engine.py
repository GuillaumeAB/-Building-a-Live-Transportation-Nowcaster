from __future__ import annotations
import json, re, math, unicodedata
from pathlib import Path
from dataclasses import dataclass, asdict
from typing import Any
import numpy as np
from rapidfuzz.fuzz import token_set_ratio, ratio

ROOT=Path(__file__).resolve().parent
CONF=json.loads((ROOT/'config/fiches_2024.json').read_text(encoding='utf-8'))
RULES=json.loads((ROOT/'config/indicator_rules.json').read_text(encoding='utf-8'))

STOP={'transport','transports','en','de','des','du','la','le','les','et','a','au','aux','sur','pour','dans','par','un','une','avec','auprès'}

FAMILY_ONTOLOGY={
 'cadrage': {
   'entities':['PIB','production','emploi','commerce extérieur','infrastructures','réseau','France','Europe','prix'],
   'measures':['niveau','évolution','part','indice','ratio'],
   'units':['%','milliards d’euros','millions d’euros','indice','km','km de réseau']},
 'activite': {
   'entities':['compte satellite','production de transport','dépense ménages','dépense publique','recettes','investissements','financement','échanges extérieurs','prix'],
   'measures':['niveau','évolution','part','indice','ratio'],
   'units':['millions d’euros','milliards d’euros','%','indice']},
 'entreprises': {
   'entities':['entreprises','créations','défaillances','chiffre d’affaires','valeur ajoutée','effectifs','salaires'],
   'measures':['nombre','niveau','évolution','part','taux'],
   'units':['unités','millions d’euros','milliards d’euros','salariés','%']},
 'emploi': {
   'entities':['emploi salarié','salariés','EQTP','rémunération','salaire','profil','PCS','âge','femme','homme'],
   'measures':['effectif','niveau','évolution','part','salaire médian','taux'],
   'units':['salariés','EQTP','euros','%']},
 'environnement': {
   'entities':['énergie','consommation','GES','CO2','polluants','NOx','PM2.5','qualité de l’air','accidentalité','nuisances sonores','artificialisation','milieux naturels'],
   'measures':['niveau','évolution','part','intensité','taux','indice'],
   'units':['TWh','PJ','Mt CO2e','kt','tonnes','%','décès','blessés','dB']},
 'marchandises': {
   'entities':['fret','tonnes-kilomètres','tonnes','route','ferroviaire','fluvial','maritime','aérien','entrepôt','logistique'],
   'measures':['niveau','évolution','part','distance','tonnage'],
   'units':['milliards de tonnes-km','millions de tonnes','tonnes','%','km']},
 'voyageurs': {
   'entities':['voyageurs','voyageurs-kilomètres','passagers','route','ferroviaire','urbain','aérien','maritime','vélo','qualité de service'],
   'measures':['niveau','évolution','part','fréquentation','ponctualité','distance'],
   'units':['milliards de voyageurs-km','millions de voyageurs','passagers','%','minutes','km']},
 'circulation': {
   'entities':['circulation','véhicules-kilomètres','parc','immatriculations','voitures','VUL','poids lourds','carburants','essence','diesel','électrique'],
   'measures':['niveau','évolution','part','taux','consommation'],
   'units':['milliards de véhicules-km','milliers','millions','milliers de m3','%','litres']}
}

PROVIDER_BY_FAMILY={
 'cadrage':['sdes_bat_2024','sdes_ck_2026','sdes_conj','insee_bdm','eurostat','datagouv'],
 'activite':['sdes_bat_2024','sdes_ck_2026','sdes_conj','insee_bdm','eurostat'],
 'entreprises':['sdes_bat_2024','sdes_ck_2026','insee_bdm','francetravail','eurostat'],
 'emploi':['sdes_bat_2024','sdes_ck_2026','insee_bdm','francetravail','eurostat'],
 'environnement':['sdes_bat_2024','sdes_ck_2026','citepa','sdes_conj','onisr','cerema','eurostat'],
 'marchandises':['sdes_bat_2024','sdes_ck_2026','sdes_conj','vnf','eurostat','dgac'],
 'voyageurs':['sdes_bat_2024','sdes_ck_2026','sdes_conj','art_rail','sncf','eurostat','dgac'],
 'circulation':['sdes_bat_2024','sdes_ck_2026','sdes_conj','sdes_specific','onisr','cerema','eurostat']}

SPECIFIC_RULES={
 # Explicit domain semantics, intentionally compact but extensible.
 'D1': {'measure':'consommation_energie','units':['TWh','PJ','ktep','GWh'],'flow':True},
 'D2.1': {'measure':'ges','units':['Mt CO2e','millions de tonnes equivalent CO2','kt CO2e'],'flow':True},
 'D2.2': {'measure':'polluants','units':['kt','tonnes'],'flow':True},
 'D3.2': {'measure':'accidentalite_routiere','units':['décès','blessés','accidents'],'flow':True},
 'D4': {'measure':'emprise_infrastructures','units':['ha','km','%'],'flow':False},
 'D5': {'measure':'nuisances_sonores','units':['dB','population'],'flow':False},
 'E2': {'measure':'fret_routier','units':['milliards de tonnes-km','millions de tonnes'],'flow':True},
 'E3': {'measure':'fret_ferroviaire','units':['milliards de tonnes-km','millions de tonnes'],'flow':True},
 'E4': {'measure':'fret_fluvial','units':['milliards de tonnes-km','millions de tonnes'],'flow':True},
 'E5': {'measure':'fret_maritime','units':['millions de tonnes','tonnes'],'flow':True},
 'E6': {'measure':'fret_aerien','units':['milliers de tonnes','millions de tonnes'],'flow':True},
 'E7': {'measure':'logistique','units':['m2','m²','entrepôts','établissements'],'flow':False},
 'F2': {'measure':'transport_collectif_urbain','units':['voyages','voyageurs-km','millions de voyages'],'flow':True},
 'F4': {'measure':'transport_aerien_voyageurs','units':['passagers','passagers-km','millions de passagers'],'flow':True},
 'F5': {'measure':'transport_maritime_voyageurs','units':['passagers','millions de passagers'],'flow':True},
 'F6': {'measure':'mobilite_velo','units':['km','déplacements','part'],'flow':True},
 'F7': {'measure':'qualite_service','units':['%','minutes','retards'],'flow':False},
 'G1': {'measure':'circulation_routiere','units':['milliards de véhicules-km','véhicules-km'],'flow':True},
 'G2': {'measure':'immatriculations','units':['milliers','millions','véhicules'],'flow':True},
 'G3': {'measure':'carburants_routiers','units':['millions de m3','m3','TWh'],'flow':True},
}

ALIASES={
 'trafic ferroviaire':'transport ferroviaire voyageurs voyageurs-km fréquentation',
 'voyageurs-kilomètres':'voyageurs-km voy km',
 'tonnes-kilomètres':'tonnes-km t km fret',
 'chiffre d’affaires':'chiffre affaires CA turnover',
 'émissions de gaz à effet de serre':'GES CO2 equivalent emissions',
 'immatriculations':'immatriculation véhicules neufs registrations',
 'qualité de service':'ponctualité régularité retards qualité',
 'entreposage':'entrepôts plateformes logistiques warehousing',
 'accidentalité':'accidents décès blessés sécurité',
}


def norm(s:str)->str:
    x=unicodedata.normalize('NFKD',str(s or '')).encode('ascii','ignore').decode().lower()
    x=x.replace('œ','oe')
    return re.sub(r'\s+',' ',re.sub(r'[^a-z0-9%+./-]+',' ',x)).strip()


def infer_measure(title:str, family:str)->str:
    t=norm(title)
    if any(k in t for k in ['immatriculation']): return 'immatriculations'
    if any(k in t for k in ['accidentalite','accidentalite','accident']): return 'accidentalite'
    if 'qualite de service' in t: return 'qualite_service'
    if 'ges' in t or 'gaz a effet de serre' in t: return 'ges'
    if 'polluant' in t or 'qualite de l air' in t: return 'polluants'
    if 'carburant' in t: return 'carburants_routiers'
    if 'marchandise' in t or 'fret' in t: return 'fret'
    if 'voyageur' in t or 'passager' in t: return 'voyageurs'
    if 'emploi' in t or 'salaire' in t: return 'emploi'
    if 'entreprise' in t: return 'entreprises'
    return family


def units_for(title, family, fiche):
    if fiche in SPECIFIC_RULES: return SPECIFIC_RULES[fiche]['units']
    return FAMILY_ONTOLOGY.get(family,{}).get('units',[])


def aliases_for(label, title, family):
    out=[label,title]
    n=norm(label)
    for k,v in ALIASES.items():
        if token_set_ratio(n,norm(k))>=72: out.append(v)
    out += FAMILY_ONTOLOGY.get(family,{}).get('entities',[])[:8]
    return list(dict.fromkeys(x for x in out if x))


def concept_score(query:str, candidate:str)->float:
    q=norm(query); c=norm(candidate)
    if not q or not c:return 0.0
    a=token_set_ratio(q,c)
    b=ratio(q,c)
    # long exact phrases matter, but token overlap is more robust on French labels.
    return 0.72*a+0.28*b


def infer_semantics(fiche, title, family, label):
    t=norm(' '.join([title,label]))
    is_share=bool(re.search(r'part|pour cent|%|structure|repartition',t))
    is_index=bool(re.search(r'indice|base 100',t))
    is_price=bool(re.search(r'prix|cout|tarif',t))
    if is_share: vtype='share'
    elif is_index: vtype='index'
    elif is_price: vtype='stock'
    else: vtype='flow' if family in {'activite','marchandises','voyageurs','circulation','environnement'} else 'stock'
    measure=SPECIFIC_RULES.get(fiche,{}).get('measure') or infer_measure(title,family)
    units=units_for(title,family,fiche)
    return {'variable_type':vtype,'measure_family':measure,'expected_units':units,'priority_providers':PROVIDER_BY_FAMILY.get(family,[]) + (RULES.get(fiche,{}).get('priority_sources',[]) if isinstance(RULES.get(fiche,{}),dict) else [])}


def extract_numeric_claims(text):
    # Keep only likely statistical numbers, preserving local context for review.
    claims=[]
    for m in re.finditer(r'(?<!\w)(\d{1,3}(?:[ .]\d{3})*(?:[,.]\d+)?|\d+(?:[,.]\d+)?)(?:\s*(%|millions?|milliards?|Mt|Md|km|voyageurs-km|tonnes-km|€))?', text, flags=re.I):
        raw=m.group(0)
        ctx=text[max(0,m.start()-100):min(len(text),m.end()+100)].strip()
        try:
            v=float(re.sub(r'[ .]','',m.group(1)).replace(',','.'))
        except: continue
        if math.isfinite(v): claims.append({'value':v,'raw':raw,'context':ctx,'unit_hint':m.group(2) or ''})
    return claims


def build_concept_registry(fiche_manifest, ck_manifest):
    registry={}
    for fiche,(title,start,family) in CONF.items():
        meta=fiche_manifest.get(fiche,{})
        figs=meta.get('figures',[]); tabs=meta.get('tables',[]); pages=meta.get('pages',[])
        # Candidate labels from explicit rules + figure/table captions + title noun phrases.
        labels=[]
        rule=RULES.get(fiche,{})
        for name in rule.get('components',{}): labels.append((name,'component',True))
        if rule.get('total'): labels.append((rule['total'].get('label',title),'total',True))
        for cap in figs+tabs:
            c=re.sub(r'^(Figure|Fig\.|Tableau)\s+[^:–—-]+[:–—-]?\s*','',str(cap),flags=re.I).strip()
            if len(c)>3: labels.append((c,'editorial_candidate',False))
        # Main title itself as a candidate concept when no explicit metric rule exists.
        if not labels: labels.append((title,'main',True))
        seen=set(); cells=[]
        for i,(label,role,mandatory) in enumerate(labels,1):
            key=norm(label)
            if not key or key in seen: continue
            seen.add(key)
            sem=infer_semantics(fiche,title,family,label)
            cells.append({
                'cell_id':f'{fiche}:C{i:03d}','label':label,'aliases':aliases_for(label,title,family),
                'role':role,'mandatory':mandatory,'family':family,'title':title,
                **sem,'status_policy': 'direct_then_aggregate_then_estimate',
                'period_policy':'annual_sum' if sem['variable_type']=='flow' else 'latest_or_average',
                'review_rules': ['unit_mismatch','scope_mismatch','stale_source','break_detected','low_semantic_score']
            })
        refs=[]
        for p in ck_manifest:
            if fiche in set(p.get('bat_refs',[])):
                refs.append(p['page'])
        registry[fiche]={
            'fiche':fiche,'title':title,'family':family,'page_start':start,
            'pages':pages,'figures':[{'asset_id':f'{fiche}:F{i:02d}','caption':x} for i,x in enumerate(figs,1)],
            'tables':[{'asset_id':f'{fiche}:T{i:02d}','caption':x} for i,x in enumerate(tabs,1)],
            'sources':meta.get('sources',[]),'ck_pages':refs,'cells':cells,
            'taxonomy':{'measure_family':infer_measure(title,family),'priority_providers':PROVIDER_BY_FAMILY.get(family,[]),
                        'specific_rule':SPECIFIC_RULES.get(fiche,{})},
            'claims':sum([extract_numeric_claims(p.get('text','')) for p in pages],[])[:250]
        }
    return registry


def validate_registry(registry):
    errors=[]
    for fiche,meta in registry.items():
        ids=[c['cell_id'] for c in meta['cells']]
        if len(ids)!=len(set(ids)): errors.append(f'{fiche}: duplicate cell_id')
        for c in meta['cells']:
            if not c['aliases']: errors.append(f"{fiche}:{c['label']}: no aliases")
    return errors

if __name__=='__main__':
    import pprint
    print('concept_engine import OK')
