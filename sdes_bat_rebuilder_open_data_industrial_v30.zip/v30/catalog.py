from __future__ import annotations
import io, json, re, time, hashlib
from pathlib import Path
from dataclasses import dataclass, asdict
from urllib.parse import urljoin
import requests
from source_audit import fetch as audited_fetch
from bs4 import BeautifulSoup
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parent
CACHE=ROOT/'cache'; CACHE.mkdir(exist_ok=True)
CFG=json.loads((ROOT/'config/edition.json').read_text(encoding='utf-8'))
S=requests.Session(); S.headers['User-Agent']='SDES-BAT-Rebuilder/6.0 (open-data research tool)'


def _hash(u): return hashlib.sha256(u.encode()).hexdigest()
def get_bytes(url, max_age_days=7, force=False):
    b,m=audited_fetch(url,max_age_days=max_age_days,force=force)
    return b, m.get('content_type','cache')


def get_text(url,max_age_days=2): return get_bytes(url,max_age_days)[0].decode('utf-8','ignore')


def discover_downloads(page_url):
    soup=BeautifulSoup(get_text(page_url),'html.parser'); out=[]
    for a in soup.find_all('a',href=True):
        href=urljoin(page_url,a['href']); txt=' '.join(a.stripped_strings)
        if re.search(r'\.(xlsx|xls|csv|pdf|zip)(?:\?|$)',href,re.I) or 'download' in (txt+' '+href).lower():
            out.append({'url':href,'text':txt,'page':page_url})
    seen=set(); return [x for x in out if not (x['url'] in seen or seen.add(x['url']))]


def parse_pdf_pages(pdf_bytes):
    reader=PdfReader(io.BytesIO(pdf_bytes)); return [(i+1,(reader.pages[i].extract_text() or '')) for i in range(len(reader.pages))]


def fiche_page_ranges(fiches):
    items=sorted(((k,int(v[1])) for k,v in fiches.items()), key=lambda z:z[1])
    out={}
    for i,(k,start) in enumerate(items): out[k]=(start, (items[i+1][1]-1 if i+1<len(items) else start+3))
    return out


def extract_elements(text):
    lines=[re.sub(r'\s+',' ',x).strip() for x in text.splitlines() if x.strip()]
    figs=[]; tabs=[]; refs=[]; src=[]
    for i,l in enumerate(lines):
        if re.match(r'^(Figure|Fig\.)\s',l,re.I):
            title=l
            if i+1<len(lines) and len(lines[i+1])<220 and not re.match(r'^(Source|Note|Tableau|Figure)',lines[i+1],re.I): title += ' '+lines[i+1]
            figs.append(title.strip(' .'))
        if re.match(r'^Tableau\s',l,re.I):
            title=l
            if i+1<len(lines) and len(lines[i+1])<220 and not re.match(r'^(Source|Note|Tableau|Figure)',lines[i+1],re.I): title += ' '+lines[i+1]
            tabs.append(title.strip(' .'))
        if re.search(r'(?:consulter|consultez).{0,120}(?:fiche|l[\'’]article)',l,re.I): refs.append(l)
        if re.match(r'^Sources?\s*:',l,re.I):
            s=l
            if i+1<len(lines) and len(lines[i+1])<260 and not re.match(r'^(Figure|Tableau|Note|Champ|Source)',lines[i+1],re.I): s += ' '+lines[i+1]
            src.append(s)
    # fallback: captions embedded mid-line in PDF extraction
    joined=' '.join(lines)
    for pat,out in [(r'((?:Figure|Fig\.)\s+[A-Z]?\d(?:\.\d+)?[^.]{0,180})',figs),(r'(Tableau\s+[A-Z]?\d(?:\.\d+)?[^.]{0,180})',tabs)]:
        for m in re.finditer(pat,joined,re.I):
            z=m.group(1).strip(' .')
            if z not in out: out.append(z)
    return {'figures':list(dict.fromkeys(figs)),'tables':list(dict.fromkeys(tabs)),'crossrefs':list(dict.fromkeys(refs)),'sources':list(dict.fromkeys(src))}


def build_bat_manifest():
    fiches=json.loads((ROOT/'config/fiches_2024.json').read_text(encoding='utf-8'))
    b,_=get_bytes(CFG['reference_bat']['pdf'],30); pages=parse_pdf_pages(b)
    ranges=fiche_page_ranges(fiches); manifest={}
    for fiche,(a,z) in ranges.items():
        page_objs=[]; allf=[]; allt=[]; src=[]
        for p in range(a,min(z,len(pages))+1):
            t=dict(pages)[p]; el=extract_elements(t)
            page_objs.append({'page':p,'text':t,'figures':el['figures'],'tables':el['tables'],'crossrefs':el['crossrefs'],'sources':el['sources']})
            allf+=el['figures']; allt+=el['tables']; src+=el['sources']
        manifest[fiche]={'title':fiches[fiche][0],'page_start':a,'page_end':z,'pages':page_objs,'figures':list(dict.fromkeys(allf)),'tables':list(dict.fromkeys(allt)),'sources':list(dict.fromkeys(src))}
    return manifest


def build_ck_manifest():
    b,_=get_bytes(CFG['chiffres_cles']['pdf'],30); pages=parse_pdf_pages(b); out=[]
    current_section=''
    for page,text in pages:
        lines=[re.sub(r'\s+',' ',x).strip() for x in text.splitlines() if x.strip()]
        if lines:
            if any(re.match(r'^(cadrage|partie|données clés)',l,re.I) for l in lines[:3]): current_section=' '.join(lines[:3])
        figs=[]; tables=[]; refs=[]
        for m in re.finditer(r'((?:Figure|Fig\.)\s+[^\n]{1,180})', ' '.join(lines), re.I):
            figs.append(m.group(1).strip())
        for m in re.finditer(r'(Tableau\s+[^\n]{1,180})', ' '.join(lines), re.I):
            tables.append(m.group(1).strip())
        joined=' '.join(lines)
        for m in re.finditer(r'\b([A-G]\d(?:\.\d+)?)\b', joined, re.I):
            refs.append(m.group(1).upper())
        for m in re.finditer(r'(?:consulter|consultez).*?(?:fiche)\s+[«\"]([^»\"]+)', joined, re.I):
            refs.append(m.group(1).strip())
        out.append({'page':page,'section':current_section,'text':text,'figures':list(dict.fromkeys(figs)),'tables':list(dict.fromkeys(tables)),'bat_refs':list(dict.fromkeys(refs))})
    return out


def build_source_manifest():
    pages=[('sdes_bat_2024',CFG['reference_bat']['url']),('sdes_ck_2026',CFG['chiffres_cles']['url']),('sdes_conj',CFG['conjoncture']['url'])]
    out=[]
    for pid,page in pages:
        try:
            for x in discover_downloads(page):
                ext=re.search(r'\.([a-z0-9]+)(?:\?|$)',x['url'],re.I); ext=ext.group(1).lower() if ext else ''
                if ext in ('xlsx','xls','csv'): out.append({'provider':pid,'kind':ext,'url':x['url'],'label':x['text'] or x['url']})
        except Exception as e: out.append({'provider':pid,'kind':'error','url':page,'label':f'ERREUR découverte: {e}'})
    known={'chiffres_cles_2026_xlsx':CFG['chiffres_cles']['xlsx']}
    out.append({'provider':'sdes_ck_2026','kind':'xlsx','url':known['chiffres_cles_2026_xlsx'],'label':'Données sur les chiffres clés des transports — édition 2026'})
    # canonical external sources; dynamic adapters may use these page endpoints
    ext=[
      ('art','https://opendata.autorite-transports.fr/rapports/transport-ferroviaire-de-voyageurs/','ART — transport ferroviaire voyageurs'),
      ('sncf','https://ressources.data.sncf.com/explore/dataset/frequentation-gares/','SNCF Open Data — fréquentation gares'),
      ('citepa','https://www.citepa.org/fr/donneesair-et-climat/','Citepa — inventaires'),
      ('onisr','https://www.onisr.securite-routiere.gouv.fr/','ONISR'),
      ('vnf','https://www.vnf.fr/vnf/services/open-data/','VNF Open Data'),
      ('dgac','https://www.ecologie.gouv.fr/politiques-publiques/aviation-civile-statistiques','DGAC — statistiques aviation'),
      ('insee','https://bdm.insee.fr/','Insee BDM / SDMX'),
      ('eurostat','https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data/','Eurostat API'),
      ('datagouv','https://www.data.gouv.fr/fr/search/','data.gouv.fr')]
    out += [{'provider':p,'kind':'page','url':u,'label':l} for p,u,l in ext]
    seen=set(); return [x for x in out if not (x['url'] in seen or seen.add(x['url']))]
