from __future__ import annotations
import argparse, json
from pathlib import Path
from pipeline import prepare_context
from concept_engine import build_concept_registry, validate_registry

ROOT=Path(__file__).resolve().parent

def main():
    ap=argparse.ArgumentParser(description='Compile le dictionnaire métier BAT à partir du corpus public.')
    ap.add_argument('--out',default='config/compiled_business_registry.json')
    args=ap.parse_args()
    ctx=prepare_context()
    reg=build_concept_registry(ctx['bat'],ctx['ck'])
    errors=validate_registry(reg)
    out=ROOT/args.out
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps({'version':'9.0','compiled_at':ctx['prepared_at'],'fiches':reg,'errors':errors},ensure_ascii=False,indent=2,default=str),encoding='utf-8')
    print(f'{len(reg)} fiches compilées -> {out}')
    if errors: print('\n'.join(errors))

if __name__=='__main__': main()
