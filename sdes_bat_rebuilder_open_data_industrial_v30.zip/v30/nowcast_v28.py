from __future__ import annotations
import math, re
import numpy as np
import pandas as pd
from rapidfuzz.fuzz import token_set_ratio


def norm(s):
    s=str(s or '').lower()
    for a,b in {'é':'e','è':'e','ê':'e','ë':'e','à':'a','â':'a','ä':'a','î':'i','ï':'i','ô':'o','ö':'o','ù':'u','û':'u','ü':'u','ç':'c','œ':'oe'}.items(): s=s.replace(a,b)
    return re.sub(r'\s+',' ',re.sub(r'[^a-z0-9+.-]+',' ',s)).strip()

def annualize(obs, variable_type='flow'):
    df=pd.DataFrame(obs)
    if df.empty or 'year' not in df:return pd.DataFrame(columns=['year','value'])
    df['value']=pd.to_numeric(df['value'],errors='coerce'); df=df.dropna(subset=['year','value'])
    if 'month' in df.columns and df['month'].notna().any():
        return df.groupby('year',as_index=False).value.agg('mean' if variable_type in {'stock','index','rate','share'} else 'sum').sort_values('year')
    if 'quarter' in df.columns and df['quarter'].notna().any():
        return df.groupby('year',as_index=False).value.agg('mean' if variable_type in {'stock','index','rate','share'} else 'sum').sort_values('year')
    return df.groupby('year',as_index=False).value.mean().sort_values('year')

def backtest_bridge(target_hist, driver_hist):
    y=annualize(target_hist)[['year','value']].rename(columns={'value':'y'})
    x=annualize(driver_hist)[['year','value']].rename(columns={'value':'x'})
    z=pd.merge(y,x,on='year').sort_values('year')
    if len(z)<9:return None
    errs=[]
    for i in range(7,len(z)):
        tr=z.iloc[:i].copy()
        gy=tr.y.pct_change().replace([np.inf,-np.inf],np.nan).dropna()
        gx=tr.x.pct_change().replace([np.inf,-np.inf],np.nan).dropna()
        m=pd.concat([gy.rename('gy'),gx.rename('gx')],axis=1).dropna()
        if len(m)<5: continue
        X=np.column_stack([np.ones(len(m)),m.gx.to_numpy()]); beta=np.linalg.lstsq(X,m.gy.to_numpy(),rcond=None)[0]
        g=float(beta[0]+beta[1]*m.gx.iloc[-1]); pred=float(tr.y.iloc[-1]*(1+np.clip(g,-0.4,0.4)))
        actual=float(z.y.iloc[i]);
        if actual: errs.append(abs(pred/actual-1)*100)
    return float(np.median(errs)) if errs else None

def bridge_nowcast(target_hist, drivers, target_value_previous, target_year, driver_target_values):
    scored=[]
    for d in drivers:
        bt=backtest_bridge(target_hist,d.get('obs',[]))
        if bt is None: continue
        ah=annualize(d.get('obs',[])); ah=ah[ah.year<target_year]
        if len(ah)<2: continue
        last=ah.value.iloc[-1]; dv=driver_target_values.get(d.get('id'))
        if dv is None or last==0: continue
        gx=float(dv/last-1)
        # estimate target growth with robust regression on historical growths
        yh=annualize(target_hist); yh=yh[yh.year<target_year]
        zh=pd.merge(yh[['year','value']].rename(columns={'value':'y'}),ah[['year','value']].rename(columns={'value':'x'}),on='year').sort_values('year')
        gy=zh.y.pct_change(); gxx=zh.x.pct_change(); m=pd.concat([gy.rename('gy'),gxx.rename('gx')],axis=1).dropna()
        if len(m)<5: continue
        X=np.column_stack([np.ones(len(m)),m.gx.to_numpy()]); beta=np.linalg.lstsq(X,m.gy.to_numpy(),rcond=None)[0]
        g=float(beta[0]+beta[1]*gx); pred=float(target_value_previous*(1+np.clip(g,-0.35,0.35)))
        weight=1/max(bt,0.25)
        scored.append({'driver':d.get('label'), 'pred':pred, 'mae_pct':bt, 'growth_driver':gx, 'weight':weight, 'provider':d.get('provider'), 'source':d.get('source')})
    if not scored:return None
    w=np.array([x['weight'] for x in scored],float); p=np.array([x['pred'] for x in scored],float)
    v=float(np.average(p,weights=w)); unc=float(min(0.6,max(0.04,(np.std(p)/max(abs(v),1e-9))+0.01)))
    return {'value':v,'lower':max(0,v*(1-unc)),'upper':v*(1+unc),'uncertainty':unc,'method':'bridge ensemble pondéré par performance rolling-origin','drivers':sorted(scored,key=lambda x:x['mae_pct'])[:5]}
