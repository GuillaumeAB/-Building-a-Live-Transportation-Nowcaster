from __future__ import annotations
import io, json, re, math, zipfile, hashlib, time
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import numpy as np, pandas as pd
from rapidfuzz.fuzz import token_set_ratio
from pypdf import PdfReader

from catalog import CFG, get_bytes, build_bat_manifest, build_ck_manifest, build_source_manifest, fiche_page_ranges
from series import workbook_series, score, target_value, project, backtest, norm

ROOT=Path(__file__).resolve().parent
CONF=json.loads((ROOT/'config/fiches_2024.json').read_text(encoding='utf-8'))
RULES=json.loads((ROOT/'config/indicator_rules.json').read_text(encoding='utf-8'))
BLUE=json.loads((ROOT/'config/blueprints.json').read_text(encoding='utf-8'))
CACHE=ROOT/'cache'; CACHE.mkdir(exist_ok=True)


def fiche_aliases(fiche, title, elements):
    parts=[title, fiche]
    parts += re.findall(r'[A-Za-zÀ-ÿ][A-Za-zÀ-ÿ0-9À-ÿ/\- ]{2,50}', title)
    for f in elements.get('figures',[]): parts.append(f)
    for t in elements.get('tables',[]): parts.append(t)
    return list(dict.fromkeys(parts))


def discover_data_files():
    # Use live page discovery. The list is cached in a JSON manifest so an offline session can inspect the last successful run.
    mp=ROOT/'cache/source_manifest.json'
    try:
        m=build_source_manifest(); mp.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8'); return m
    except Exception as e:
        if mp.exists(): return json.loads(mp.read_text(encoding='utf-8'))
        raise RuntimeError(f'Impossible de découvrir les sources SDES : {e}')


def classify_source(src):
    u=(src.get('url') or '').lower(); p=src.get('provider','')
    if p=='sdes_bat_2024':return 100
    if p=='sdes_ck_2026':return 98
    if p=='sdes_conj':return 97
    if p in ('art','dgac','citepa','onisr','vnf'):return 90
    if p in ('insee','eurostat'):return 85
    return 75


def source_candidates_for_fiche(fiche,manifest):
    fam=CONF[fiche][2]
    words=(CONF[fiche][0]+' '+fam).lower()
    out=[]
    for s in manifest:
        if s.get('kind') not in ('xlsx','xls','csv'): continue
        hay=(s.get('label','')+' '+s.get('url','')).lower()
        bonus=20 if any(w in hay for w in ['transport','voyageur','marchandise','entreprise','emploi','energie','environnement','circulation','cadrage','conjoncture']) else 0
        # Keep most SDES xlsx; domain match affects rank, not hard filtering.
        out.append({**s,'source_priority':classify_source(s)+bonus})
    return sorted(out,key=lambda x:-x['source_priority'])


def build_series_index(urls, max_files=20):
    idx=[]; errors=[]
    for s in urls[:max_files]:
        try:
            rows=workbook_series(s['url'],s.get('label','SDES'))
            for r in rows:
                r['provider']=s.get('provider'); r['source_priority']=s.get('source_priority',80)
            idx.extend(rows)
        except Exception as e:
            errors.append({'source':s,'error':repr(e)})
    return idx,errors


def resolve_cell(cell, series_idx, target_kind, target):
    aliases=cell.get('aliases') or [cell['label']]
    cands=[]
    for s in series_idx:
        sc=score(s['label'],aliases)
        if sc<42: continue
        tv=target_value(s['obs'],target_kind,target,cell.get('variable_type','flow'))
        status=None; method=''
        if tv:
            v,kind=tv; status='OFFICIEL' if kind=='direct' else 'RECONSTRUIT'; method=kind
            lo=hi=float(v); bt=backtest(s['obs'],cell.get('variable_type','flow'))
            conf=min(.995,.55+0.004*sc+0.002*s.get('source_priority',70))
        else:
            pred=project(s['obs'],target_kind,target,cell.get('variable_type','flow'))
            if not pred: continue
            v=float(pred['value']); lo=float(pred['lower']); hi=float(pred['upper']); status='ESTIME'; method=pred['method']; bt=backtest(s['obs'],cell.get('variable_type','flow'))
            conf=max(.08,min(.89,1-pred['uncertainty']))
        cands.append({'value':v,'lower':lo,'upper':hi,'status':status,'method':method,'confidence':round(conf,3),'backtest_mae_pct':bt,'frequency':('monthly' if any(o.get('month') for o in s['obs']) else 'quarterly' if any(o.get('quarter') for o in s['obs']) else 'annual'),'source':s['source'],'url':s['url'],'provider':s.get('provider'),'sheet':s['sheet'],'row':s['row'],'matched_label':s['label'],'semantic_score':sc,'unit':cell.get('unit',''),'last_observation':s['obs'][-1],'alternatives':[]})
    if not cands:return None
    rank={'OFFICIEL':4,'RECONSTRUIT':3,'ESTIME':2,'PROXY':1}
    cands.sort(key=lambda x:(rank[x['status']],x['confidence'],x['semantic_score'],x['source'] is not None),reverse=True)
    b=cands[0]; b['alternatives']=cands[1:5]; return b


def make_cells(fiche,manifest):
    bp=BLUE.get(fiche)
    if bp:
        labels=[]
        for fig in bp.get('figures',[]): labels += fig.get('components',[])
        total=(RULES.get(fiche) or {}).get('total')
        if total: labels.append(total['label'])
    else:
        labels=[]
    # Add every figure and table as first-class editorial objects, while keeping numeric slots from rules/blueprints.
    bat=manifest[fiche]
    existing={norm(x) for x in labels}
    for el in bat.get('figures',[]):
        if norm(el) not in existing: labels.append(el); existing.add(norm(el))
    for el in bat.get('tables',[]):
        if norm(el) not in existing: labels.append(el); existing.add(norm(el))
    cells=[]
    rule=RULES.get(fiche,{})
    for i,lbl in enumerate(labels):
        spec={'cell_id':f'{fiche}:slot:{i+1}','fiche':fiche,'block':'auto','label':lbl,'role':'figure_or_table_slot','unit':'','variable_type':'flow','aliases':[lbl]}
        for name,rr in rule.get('components',{}).items():
            if token_set_ratio(norm(lbl),norm(name))>=80 or norm(name) in norm(lbl):
                spec.update({'label':name,'unit':rr.get('unit',''),'variable_type':rr.get('type','flow'),'aliases':rr.get('aliases',[name]),'role':'component'}); break
        cells.append(spec)
    return cells


def extract_reference_elements(fiche,bat_manifest,ck_manifest):
    b=bat_manifest[fiche]; ck=[]
    fcode=re.sub(r'^.*?(?=([A-G]\d))','',fiche)
    pat=re.compile(rf'\b{re.escape(fiche.split(" ")[0])}\b',re.I)
    for p in ck_manifest:
        if any(fiche.lower() in r.lower() for r in p.get('bat_refs',[])) or any(fcode.lower() in r.lower() for r in p.get('bat_refs',[])):
            ck.append(p)
    return {'bat':b,'ck':ck}


def reconcile_components(records,fiche):
    rule=RULES.get(fiche,{})
    total=rule.get('total'); out=[]
    if not total:return out
    comp_labels=list(rule.get('components',{}).keys()); by={norm(r.get('component') or r.get('label')):r for r in records}
    comps=[by.get(norm(c)) for c in comp_labels]; comps=[c for c in comps if c]
    if len(comps)>=2:
        val=sum(float(c['value']) for c in comps); lo=sum(float(c.get('lower',c['value'])) for c in comps); hi=sum(float(c.get('upper',c['value'])) for c in comps)
        stat='OFFICIEL' if all(c.get('status')=='OFFICIEL' for c in comps) else 'RECONSTRUIT'; conf=min(c.get('confidence',0.5) for c in comps)
        out.append({'cell_id':f'{fiche}:TOTAL','component':total['label'],'label':total['label'],'role':'derived_total','value':val,'lower':lo,'upper':hi,'status':stat,'method':'somme des composantes','confidence':conf,'unit':total.get('unit',''),'sources':[c.get('source') for c in comps]})
    return out


def checks(records,derived,fiche):
    ch=[]; n=len(records); resolved=sum(r.get('value') is not None for r in records); ch.append({'test':'Couverture des slots','status':'OK' if resolved>=max(1,n//2) else 'ALERTE','detail':f'{resolved}/{n}'})
    neg=[r for r in records if r.get('value') is not None and r.get('unit')!='%' and float(r['value'])<0]; ch.append({'test':'Valeurs négatives','status':'ALERTE' if neg else 'OK','detail':len(neg)})
    dupl=len(records)-len({r['cell_id'] for r in records}); ch.append({'test':'Identifiants uniques','status':'OK' if dupl==0 else 'ERREUR','detail':dupl})
    if derived:
        d=derived[0]; ch.append({'test':'Total dérivé','status':'OK','detail':f"{d['value']:.3f} {d.get('unit','')}"})
    return ch


def prepare_context():
    """Prepare one shared, cached corpus context. Heavy: downloads + PDF parsing + series indexing."""
    bat=build_bat_manifest()
    ck=build_ck_manifest()
    sm=discover_data_files()
    # Mark each source with a deterministic priority before sorting.
    urls=[]
    for x in sm:
        if x.get('kind') in ('xlsx','xls','csv'):
            urls.append({**x,'source_priority':classify_source(x)})
    urls=sorted(urls,key=lambda x:-x['source_priority'])
    series_idx,errors=build_series_index(urls)
    return {'bat':bat,'ck':ck,'sources':sm,'series_idx':series_idx,'series_errors':errors,'prepared_at':datetime.now(timezone.utc).isoformat()}


def build_fiche(fiche,target_kind,target,ctx=None):
    ctx=ctx or prepare_context()
    bat,ck,sm=ctx['bat'],ctx['ck'],ctx['sources']
    refs=extract_reference_elements(fiche,bat,ck)
    cells=make_cells(fiche,bat)
    rec=[]; unresolved=[]
    # Numeric matching is only attempted for explicit component cells. Figure/table assets are retained separately.
    for c in cells:
        if c.get('role') not in ('component',):
            unresolved.append(c); continue
        rr=resolve_cell(c,ctx['series_idx'],target_kind,target)
        if rr:
            rr.update({'cell_id':c['cell_id'],'block':c['block'],'component':c['label'],'role':c['role']}); rec.append(rr)
        else: unresolved.append(c)
    derived=reconcile_components(rec,fiche)
    chk=checks(rec,derived,fiche)
    return {'version':'6.0.0','edition_mode':'BAT 2025 + Chiffres clés 2026 co-produits','target_year':CFG['target']['bat_year'],'created_at':datetime.now(timezone.utc).isoformat(),'fiche':fiche,'title':CONF[fiche][0],'family':CONF[fiche][2],'target_kind':target_kind,'target':target,'reference':refs,'cells':cells,'records':rec,'derived':derived,'unresolved':unresolved,'checks':chk,'sources':sm,'series_index_stats':{'series_considered':len(ctx['series_idx']),'errors':ctx['series_errors']},'open_data_only':True,'context_prepared_at':ctx['prepared_at']}


def build_all(target_year=2025,ctx=None):
    ctx=ctx or prepare_context(); out=[]
    for fiche in CONF:
        try: out.append(build_fiche(fiche,'annual',target_year,ctx=ctx))
        except Exception as e: out.append({'fiche':fiche,'fatal':repr(e)})
    return out
