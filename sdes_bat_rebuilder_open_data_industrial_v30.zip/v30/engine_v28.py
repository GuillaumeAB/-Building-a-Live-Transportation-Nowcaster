from __future__ import annotations
import json, math, re
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
import numpy as np
import pandas as pd
from rapidfuzz.fuzz import token_set_ratio
from data_lake_v28 import DataLake, norm
from source_policy import policy, audit_records, evidence_ok
from nowcast_v28 import annualize, bridge_nowcast

ROOT=Path(__file__).resolve().parent
REG=json.loads((ROOT/'config/registry_v28_upgrade.json').read_text(encoding='utf8'))
FACTS=json.loads((ROOT/'config/public_facts_v29.json').read_text(encoding='utf8')).get('facts',[])
IR=json.loads((ROOT/'config/indicator_rules_v28.json').read_text(encoding='utf8'))
REF_IDS={'sdes_bat_2024','sdes_ck_2026'}

@dataclass
class Record:
    cell_id:str; fiche:str; label:str; value:float|None; unit:str; status:str; method:str
    confidence:float
    source:str=''; url:str=''; provider:str=''; source_tier:str=''
    last_observation:Any=None; publication_date:str|None=None
    semantic_score:float=0.0; concept_score:float=0.0; unit_score:float=1.0; scope_score:float=1.0
    note:str=''; lower:float|None=None; upper:float|None=None
    history:list[dict]=None


def _date(s):
    if not s: return None
    try: return datetime.fromisoformat(str(s).replace('Z','+00:00')).date()
    except Exception:
        try: return datetime.strptime(str(s)[:10], '%Y-%m-%d').date()
        except Exception: return None


def _num_unit(s):
    x=norm(s)
    if '%' in x or 'pour cent' in x: return 'share'
    if 'voyageur' in x and 'km' in x: return 'voykm'
    if 'passager' in x and 'km' in x: return 'voykm'
    if 'tonne' in x and 'km' in x: return 'tkm'
    if 'twh' in x or 'mtep' in x: return 'energy'
    if 'million de tonnes' in x or 'millions de tonnes' in x: return 'tonnage'
    if 'milliard' in x and 'euro' in x: return 'eurobn'
    if 'milliard' in x: return 'bn'
    if 'million de vehicules' in x: return 'vehiclesm'
    if 'vehicule' in x: return 'vehicles'
    if 'salari' in x: return 'employees'
    if 'personnes' in x: return 'people'
    if 'indice' in x: return 'index'
    if 'km' in x: return 'km'
    if 'gram' in x and 'co2' in x: return 'co2intensity'
    return x


def unit_score(expected, got):
    if not expected or not got: return 0.6
    e=_num_unit(expected); g=_num_unit(got)
    if e==g: return 1.0
    # explicit compatible variants
    compat={('vehiclesm','vehicles'):0.8,('bn','eurobn'):0.7,('voykm','bn'):0.6,('tkm','bn'):0.6}
    return compat.get((e,g),compat.get((g,e),0.05))


class Engine:
    def __init__(self, root=None):
        self.root=Path(root or ROOT)
        self.registry=REG
        self.lake=DataLake(self.root/'acquired/live', self.root/'reference')
        self.facts=FACTS
        self.source_meta=self._load_manifest()

    def _load_manifest(self):
        p=self.root/'data_lake/HARVEST_MANIFEST.json'
        if not p.exists(): return {}
        try:
            m=json.loads(p.read_text(encoding='utf8'))
            out={}
            for x in m.get('live',[]):
                out[Path(x.get('url','')).name]={'publication_date':x.get('publication_date'),'retrieved_at':x.get('retrieved_at'),'url':x.get('url')}
            return out
        except Exception: return {}

    def _allowed_fact(self, f, asof):
        if f.get('evidence_role','target')!='target': return False
        if not policy(f.get('provider',''),'target').allowed_for_target: return False
        d=_date(f.get('date_published'))
        return d is None or d <= _date(asof)

    def _fact_for(self, cell, target_kind, target, asof):
        # Public facts are an explicit target-evidence registry. A fact can only fill the
        # declared cell_label; semantic similarity is deliberately NOT allowed here,
        # because it can duplicate a total into a subcomponent.
        fiche=cell.get('fiche') or getattr(self,'_current_fiche',None)
        labels={norm(cell.get('label','')), *[norm(x) for x in cell.get('aliases',[]) if x]}
        candidates=[f for f in self.facts if f.get('fiche')==fiche and self._allowed_fact(f,asof)]
        exact=[]
        for f in candidates:
            fl=norm(f.get('cell_label',''))
            if fl and fl in labels:
                if target_kind=='quarterly':
                    tp=norm(f.get('target_period',''))
                    wanted=norm(f'{target[0]} T{target[1]}')
                    if not tp or tp != wanted:
                        continue
                else:
                    tp=norm(f.get('target_period',''))
                    if tp:
                        continue
                exact.append(f)
        if not exact:
            return None,0
        # Prefer latest publication when multiple exact public facts exist.
        exact.sort(key=lambda f:str(f.get('date_published','')), reverse=True)
        return exact[0],100

    def _series_candidates(self,cell):
        return self.lake.all_candidates(cell.get('aliases',[cell['label']]), cell.get('priority_providers') or None)

    def _series_resolution(self,cell,target_kind,target,asof):
        target_year=int(target[0] if isinstance(target,tuple) else target); target_q=int(target[1]) if target_kind=='quarterly' else None
        scored=[]
        for sem,s in self._series_candidates(cell):
            if not policy(s.get('provider',''),'target',s.get('url','')).allowed_for_target: continue
            uf=max([unit_score(u,s.get('unit','')) for u in cell.get('expected_units',[])],default=.6)
            scope=.9 if s.get('scope') else .6
            provider_rank=max(1,len(cell.get('priority_providers') or []))
            pscore=(sem*.55)+(uf*25)+(scope*10)
            scored.append((pscore,sem,uf,scope,s))
        scored.sort(key=lambda x:-x[0])
        for _,sem,uf,scope,s in scored[:20]:
            obs=pd.DataFrame(s.get('obs',[]));
            if obs.empty: continue
            obs['value']=pd.to_numeric(obs['value'],errors='coerce'); obs=obs.dropna(subset=['value'])
            if target_kind=='annual':
                if any(pd.notna(obs.get('month'))):
                    d=annualize(obs.to_dict('records'),cell.get('variable_type','flow')); direct=d[d.year==target_year]
                    if not direct.empty:
                        v=float(direct.value.iloc[-1])
                        return self._record_from_series(cell,s,v,'OFFICIEL' if s.get('provider')!='art' else 'PROVISOIRE_PUBLIC','observation/agrégation infra-annuelle',sem,uf,scope,target_year)
                direct=obs[obs.year==target_year]
                if not direct.empty:
                    v=float(direct.value.iloc[-1]); return self._record_from_series(cell,s,v,'OFFICIEL' if s.get('provider') not in {'art'} else 'PROVISOIRE_PUBLIC','observation directe',sem,uf,scope,target_year)
            else:
                direct=obs[(obs.year==target_year)&(obs.quarter==target_q)]
                if not direct.empty:
                    v=float(direct.value.iloc[-1]); return self._record_from_series(cell,s,v,'OFFICIEL' if s.get('provider')!='art' else 'PROVISOIRE_PUBLIC','observation directe',sem,uf,scope,target_year)
                # monthly to quarterly
                mm=obs[(obs.year==target_year)&(obs.month.notna())]
                if len(mm)>=3:
                    if target_q==1: qmm=mm[mm.month.isin([1,2,3])]
                    elif target_q==2: qmm=mm[mm.month.isin([4,5,6])]
                    elif target_q==3: qmm=mm[mm.month.isin([7,8,9])]
                    else: qmm=mm[mm.month.isin([10,11,12])]
                    if len(qmm)>=2:
                        vals=qmm.value.tolist(); v=float(sum(vals) if cell.get('variable_type')=='flow' else np.mean(vals)); return self._record_from_series(cell,s,v,'RECONSTRUIT','agrégation mensuelle → trimestre',sem,uf,scope,target_year)
        return None

    def _record_from_series(self,cell,s,v,status,method,sem,uf,scope,target_year):
        ah=annualize(s.get('obs',[]),cell.get('variable_type','flow'))
        hist=[]
        if not ah.empty:
            hist=[{'year':int(r.year),'value':float(r.value)} for r in ah.tail(10).itertuples()]
        last=hist[-1] if hist else None
        conf=min(.98,.55+.003*sem+.12*uf+.08*scope)
        rr=Record(cell['cell_id'],cell['fiche'],cell['label'],float(v),cell.get('expected_units',[''])[0] if cell.get('expected_units') else s.get('unit',''),status,method,conf,s.get('label',''),s.get('url',''),s.get('provider',''),'primary_open',last,None,float(sem),float(sem),float(uf),float(scope),'',None,None,hist)
        setattr(rr,'raw_obs',s.get('obs',[])[-48:])
        return rr

    def _reference_history(self,cell):
        out=[]
        for s in self.lake.all_reference_candidates(cell.get('aliases',[cell['label']]),None):
            if policy(s.get('provider',''),'history_calibration',s.get('url','')).allowed_for_history_calibration: out.append(s)
        return out[:10]

    def _drivers(self,cell):
        prof=self.registry[cell['fiche']]
        out=[]
        for s in self.lake.live:
            sem=max(token_set_ratio(norm(s.get('label','')),norm(d)) for d in prof.get('driver_concepts',[])) if prof.get('driver_concepts') else 0
            if sem>=55: out.append((sem,s))
        return [s for _,s in sorted(out,key=lambda z:-z[0])[:20]]

    def _nowcast(self,cell,target_kind,target):
        if target_kind!='annual': return None
        year=int(target)
        refs=self._reference_history(cell)
        if not refs: return None
        ref=refs[0]; prev=annualize(ref.get('obs',[]),cell.get('variable_type','flow')); prev=prev[prev.year<year]
        if prev.empty: return None
        previous=float(prev.value.iloc[-1]); drivers=self._drivers(cell)
        if not drivers: return None
        driver_targets={f"{d.get('source_file')}::{d.get('sheet')}::{d.get('row')}":None for d in drivers}
        scored=[]
        for d in drivers:
            aa=annualize(d.get('obs',[])); x=aa[aa.year==year]
            if x.empty: continue
            driver_targets[f"{d.get('source_file')}::{d.get('sheet')}::{d.get('row')}"]=float(x.value.iloc[-1])
        if not driver_targets:return None
        pred=bridge_nowcast(ref.get('obs',[]),drivers,previous,year,driver_targets)
        if not pred:return None
        # prohibit model if backtest is poor
        if pred['uncertainty']>.35:return None
        return pred,ref

    def _fact_record(self,cell,f):
        val=float(f['value']); status=f.get('status','OFFICIEL_PUBLIC')
        conf=.98 if status=='OFFICIEL_PUBLIC' else (.90 if 'PRODUCTEUR' in status or 'PROVISOIRE' in status else .80)
        return Record(cell['cell_id'],cell['fiche'],cell['label'],val,f.get('unit',''),status,'preuve publique directe',conf,f.get('concept',''),f.get('url',''),f.get('provider',''),'primary_open',None,f.get('date_published'),100.0,100.0,1.0,1.0, f.get('note',''),None,None,[])

    def build(self,fiche,target_kind='annual',target=2025,asof='2026-08-29'):
        meta=self.registry[fiche]; self._current_fiche=fiche; records=[]; unresolved=[]
        # explicit cells with a target fact
        for cell in meta['cells']:
            cell=dict(cell); cell['fiche']=fiche
            fact,score=self._fact_for(cell,target_kind,target,asof)
            rr=None
            if fact: rr=self._fact_record(cell,fact)
            if rr is None: rr=self._series_resolution(cell,target_kind,target,asof)
            if rr is None:
                nw=self._nowcast(cell,target_kind,target)
                if nw:
                    pred,ref=nw
                    rr=Record(cell['cell_id'],fiche,cell['label'],pred['value'],cell.get('expected_units',[''])[0] if cell.get('expected_units') else ref.get('unit',''),'NOWCAST','ensemble ponté sur signaux publics + backtest rolling',max(.15,min(.9,1-pred['uncertainty'])), ', '.join(d['driver'] for d in pred['drivers'][:3]),'', '', 'nowcast_public', None,None,0,0,0,0,'Dernier recours: aucune preuve cible compatible trouvée; calibration historique séparée.',pred['lower'],pred['upper'],[])
            if rr:
                rd=asdict(rr)
                dec=policy(rd.get('provider',''),'target',rd.get('url',''))
                rd['evidence_role']='target'
                rd['source_class']=dec.classification
                rd['source_allowed']=dec.allowed_for_target
                # Composite source/fit score for review, deliberately distinct from statistical uncertainty.
                rd['source_quality_score']=round(max(0,min(100,0.45*rd.get('semantic_score',0)+20*rd.get('unit_score',0)+10*rd.get('scope_score',0)+25*(1 if dec.classification=='primary_open' else 0.6)),1))
                records.append(rd)
            else: unresolved.append({**cell,'reason':'aucune preuve cible compatible et aucun nowcast validé hors échantillon'})

        derived=[]
        # generic evolution + shares from records; never use reference values as target inputs
        by={r['label']:r for r in records if r.get('value') is not None}
        for r in list(records):
            if r.get('history'):
                hist=sorted(r['history'],key=lambda x:x['year']); prev=[x for x in hist if x['year']<int(target[0] if isinstance(target,tuple) else target)]
                if prev:
                    pv=prev[-1]['value']; r['compared_to_previous_public_history']=pv
                    if pv not in (0,None): r['yoy_pct']=100*(r['value']/pv-1)
        # known explicit total rules, but only if exact target components all resolved
        rule=IR.get(fiche,{})
        if rule.get('total') and rule.get('components'):
            comps=rule['components']; got={k:by.get(k) for k in comps}
            if all(got.values()):
                vals=[got[k]['value'] for k in comps]; total=float(sum(vals)); conf=min(x['confidence'] for x in got.values())
                derived.append({'cell_id':f'{fiche}:DERIVED_TOTAL','label':rule['total']['label'],'value':total,'unit':rule['total'].get('unit',''),'status':'CALCULE','method':'somme des composantes cible','confidence':conf,'inputs':[got[k]['cell_id'] for k in comps]})
                for k in comps:
                    derived.append({'cell_id':f'{fiche}:SHARE:{k}','label':f'Part - {k}','value':100*got[k]['value']/total,'unit':'%','status':'CALCULE','method':'part calculée sur le même périmètre cible','confidence':conf,'inputs':[got[k]['cell_id'],f'{fiche}:DERIVED_TOTAL']})
        qa=[]
        ref_used=[r for r in records if not evidence_ok(r)]
        qa.append({'test':'Firewall BAT/CK -> cible','status':'OK' if not ref_used else 'ERREUR','detail':len(ref_used)})
        qa.append({'test':'Qualité des sources cibles','status':'OK' if all(evidence_ok(r) for r in records) else 'ERREUR','detail':len(records)})
        qa.append({'test':'Couverture','status':'OK' if len(records)==len(meta['cells']) else 'ALERTE','detail':f'{len(records)}/{len(meta["cells"])}'})
        qa.append({'test':'Nowcasts uniquement en dernier recours','status':'OK','detail':sum(r['status']=='NOWCAST' for r in records)})
        qa.append({'test':'Provenance URL externe','status':'OK' if all((not r.get('value') or r.get('url')) for r in records if r['status'] not in {'CALCULE'}) else 'ALERTE'})
        qa.append({'test':'Cellules non résolues','status':'OK' if not unresolved else 'REVUE','detail':len(unresolved)})
        # Share closure checks for contracts that define a complete market composition
        share_cfg=IR.get(fiche,{}).get('shares_sum')
        if share_cfg:
            vals=[by.get(k,{}).get('value') for k in share_cfg if k in by]
            if len(vals)==len(share_cfg):
                ssum=float(sum(vals)); tol=float(IR.get(fiche,{}).get('tolerance_pp',0.5)); ok=abs(ssum-100)<=tol
                qa.append({'test':'Somme des parts','status':'OK' if ok else 'ALERTE','detail':f'{ssum:.2f}% (tolérance ±{tol} pp)'})
            else:
                qa.append({'test':'Somme des parts','status':'NON_TESTABLE','detail':f'{len(vals)}/{len(share_cfg)} parts disponibles'})
        ref_tpl={}
        rp=self.root/'data_lake/REFERENCE_OBJECTS.json'
        if rp.exists():
            try: ref_tpl=json.loads(rp.read_text(encoding='utf8')).get(fiche,{})
            except Exception: ref_tpl={}
        meta_out=dict(meta); meta_out['reference_template']={k:ref_tpl.get(k,[]) for k in ('page_start','page_end','figures','tables','sources') if k in ref_tpl}
        # Explicit expected figure/table contract from F/D blueprints when available.
        contracts = {}
        for _fn in ('f_contracts.json','d_contracts.json'):
            _pp=self.root/'config'/_fn
            if _pp.exists():
                try: contracts.update(json.loads(_pp.read_text(encoding='utf8')))
                except Exception: pass
        cc=contracts.get(fiche,{})
        meta_out['expected_figures']=cc.get('figures',[])
        meta_out['expected_table']=cc.get('table','')
        meta_out['narrative_sections']=cc.get('narrative_sections', meta_out.get('narrative_sections',[]))
        aux=[f for f in self.facts if f.get('fiche')==fiche and f.get('evidence_role')=='auxiliary' and self._allowed_fact({**f,'evidence_role':'target'},asof)]
        return {'version':'29.0','fiche':fiche,'title':meta['title'],'family':meta['family'],'target_kind':target_kind,'target':target,'as_of':asof,'open_data_only':True,
                'source_policy':'BAT 2024 / CK 2026 = gabarit et calibration historique uniquement; aucune valeur cible ni preuve cible issue du gabarit. Firewall vérifié par provider ET URL.',
                'cells':meta['cells'],'records':records,'derived':derived,'unresolved':unresolved,'qa':qa,
                'reference_contract':meta_out,'source_audit':audit_records(records),'target_providers':sorted({r.get('provider') for r in records if r.get('provider')}),'auxiliary_facts':aux,'created_at':datetime.now(timezone.utc).isoformat(),'series_index_stats':{'live_series':len(self.lake.live),'reference_series':len(self.lake.reference),'public_facts':len(self.facts),'parse_errors':len(self.lake.errors)}}


def build_all(target=2025,asof='2026-08-29',fiches=None):
    e=Engine(); return [e.build(c,'annual',target,asof) for c in (fiches or list(e.registry))]
