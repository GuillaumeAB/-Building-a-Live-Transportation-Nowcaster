from v30_core import build_pair_parallel, write_json
from render_v30 import export
from pathlib import Path
import csv, json, time
ROOT=Path(__file__).resolve().parent

def main():
    t=time.perf_counter(); reports=build_pair_parallel(); rows=[]
    for name,r in reports.items():
        pdf=export(r); rows.append({'run':name,'fiche':r['fiche'],'target':r['target'],'records':len(r['records']),'paragraphs':len(r['paragraphs']),'figures':len(r['figures']),'table_rows':len(r['table'])-1,'pdf':str(pdf.relative_to(ROOT))})
    out=ROOT/'output'/'INTERNAL_LAUNCH_F4_D21_20260829.json'; out.write_text(json.dumps({'elapsed_s':round(time.perf_counter()-t,3),'rows':rows},ensure_ascii=False,indent=2),encoding='utf8')
    with (ROOT/'output'/'INTERNAL_LAUNCH_F4_D21_20260829.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]); w.writeheader(); w.writerows(rows)
    print(json.dumps({'elapsed_s':round(time.perf_counter()-t,3),'rows':rows},ensure_ascii=False,indent=2))
if __name__=='__main__': main()
