from __future__ import annotations
import math, statistics
import numpy as np

def _sorted_obs(obs): return sorted(obs,key=lambda x:(x.get('year',0),x.get('quarter') or 0,x.get('month') or 0))

def growths(obs):
    x=_sorted_obs(obs); out=[]
    for a,b in zip(x,x[1:]):
        va,vb=a.get('value'),b.get('value')
        if va is None or vb is None or va==0: continue
        out.append((vb/va)-1)
    return out

def break_score(obs, window=4):
    g=growths(obs)
    if len(g)<max(6,window*2): return {'score':0.0,'detected':False,'reason':'historique insuffisant'}
    a=np.array(g[-window:],dtype=float); b=np.array(g[-2*window:-window],dtype=float)
    pooled=np.sqrt((a.var(ddof=1)+b.var(ddof=1))/2) if len(a)>1 else 0
    z=abs(a.mean()-b.mean())/(pooled+1e-9)
    return {'score':float(min(1,z/4)),'detected':bool(z>=2.5),'mean_recent':float(a.mean()),'mean_previous':float(b.mean()),'z_approx':float(z)}

def quality(obs):
    o=_sorted_obs(obs); vals=[x.get('value') for x in o if isinstance(x.get('value'),(int,float))]
    positive=sum(v>=0 for v in vals)
    bd=break_score(o)
    return {'n_obs':len(o),'n_numeric':len(vals),'negative_share':1-positive/len(vals) if vals else 0,'break':bd,
            'span_years':(o[-1].get('year',0)-o[0].get('year',0)) if len(o)>=2 else 0}
