from __future__ import annotations
import math

def fmt(x):
    if x is None: return 'n.d.'
    x=float(x)
    if abs(x)>=1000:return f'{x:,.0f}'.replace(',',' ').replace('.',',')
    if abs(x)>=100:return f'{x:,.1f}'.replace('.',',')
    if abs(x)>=10:return f'{x:,.1f}'.replace('.',',')
    return f'{x:,.2f}'.replace('.',',')

def pct_change(v,p):
    if v is None or p in (None,0): return None
    return 100*(v/p-1)

FAMILY_CONTEXT={
'activite':'L’activité économique des transports est lue à travers la dépense, la production, les prix et l’investissement.',
'entreprises':'La dynamique des entreprises reflète les évolutions de la demande, des coûts et du tissu productif.',
'emploi':'L’emploi permet de suivre directement l’activité du secteur et les tensions du marché du travail.',
'environnement':'Les indicateurs environnementaux combinent activité, consommation d’énergie, motorisation et facteurs réglementaires.',
'marchandises':'Les flux de marchandises reflètent l’activité économique et les arbitrages entre modes.',
'voyageurs':'La mobilité des voyageurs dépend de la demande, de l’offre de transport, des prix et des comportements.',
'circulation':'La circulation routière combine parc, usages, motorisations et activité économique.',
'cadrage':'Le cadrage replace les transports dans leur environnement macroéconomique et territorial.'}

def build_narrative(report):
    target=report['target'][0] if isinstance(report['target'],tuple) else report['target']
    period=f"au {report['target'][1]}e trimestre {target}" if isinstance(report['target'],tuple) else f'en {target}'
    rec=[r for r in report['records'] if r.get('value') is not None]
    est=[r for r in rec if r.get('status') in {'NOWCAST','PROXY','ESTIME','PROXY_PRODUCTEUR','CALCULATED_PUBLIC_ESTIMATE','ESTIMATION_PRODUCTEUR'}]
    paras=[]
    if not rec:
        paras.append(f"La fiche {report['fiche']} est préparée {period}, mais aucune preuve cible suffisamment compatible n’a été identifiée dans les sources publiques autorisées.")
        paras.append("Le moteur n’utilise pas le BAT 2024 ni les Chiffres clés 2026 comme valeurs cibles : ces documents servent uniquement de spécification éditoriale, de définition et de calibration historique.")
        paras.append("Les cellules restantes peuvent être résolues par agrégation, source publique spécialisée ou nowcast de dernier recours lorsque le backtest valide l’usage d’indicateurs avancés.")
        return paras
    # headline: prefer main cell, then highest confidence
    main=[r for r in rec if r.get('cell_id','').endswith(':main') or r.get('label','').lower().startswith(report['title'].lower()[:15])]
    lead=max(main or rec,key=lambda r:r.get('confidence',0))
    ctx=FAMILY_CONTEXT.get(report['family'],'Les principaux indicateurs de la fiche évoluent avec l’activité et les comportements de transport.')
    paras.append(f"{period.capitalize()}, {lead['label'].lower()} atteint {fmt(lead['value'])} {lead.get('unit','')}. {ctx}")
    yoy=[]
    for r in rec:
        if r.get('yoy_pct') is not None: yoy.append((abs(r['yoy_pct']),r['yoy_pct'],r))
    yoy.sort(reverse=True)
    if yoy:
        bits=[f"{r['label']} ({g:+.1f} %)" for _,g,r in yoy[:3]]
        paras.append("Les évolutions les plus marquées concernent " + ', '.join(bits) + ".")
    else:
        paras.append("La comparaison interannuelle est renseignée lorsque la série publique compatible est disponible ; elle n’est pas reconstituée à partir d’une définition différente.")
    if est:
        paras.append("Certaines cellules restent provisoires ou estimées : " + '; '.join(f"{r['label']} ({r['status']})" for r in est[:4]) + ".")
    else:
        paras.append("Aucun nowcast de dernier recours n’est nécessaire pour les cellules résolues dans cette version.")
    return paras[:4]
