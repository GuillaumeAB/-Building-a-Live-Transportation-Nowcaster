from __future__ import annotations
import json, html, math
from pathlib import Path
from collections import defaultdict
import numpy as np
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from editorial_v29 import build_narrative, fmt
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)


def _safe(s): return html.escape(str(s or ''))

def _group_levels(records):
    g=defaultdict(list)
    for r in records:
        u=r.get('unit','').strip() or 'unité non renseignée'
        if r.get('value') is not None and '%' not in u:
            g[u].append(r)
    return g


def make_figures(report,outdir):
    outdir.mkdir(parents=True,exist_ok=True)
    rec=[r for r in report.get('records',[]) if r.get('value') is not None]
    paths=[]
    used=set()
    # A. same-unit level figure, avoiding mixed magnitudes.
    for unit,rows in _group_levels(rec).items():
        if len(rows)<2: continue
        rows=rows[:6]
        fig=plt.figure(figsize=(7.25,2.45)); ax=fig.add_subplot(111)
        vals=[r['value'] for r in rows]
        ax.bar(np.arange(len(rows)),vals)
        ax.set_xticks(np.arange(len(rows)),[r['label'][:28] for r in rows],rotation=32,ha='right',fontsize=6.5)
        ax.set_ylabel(unit,fontsize=7); ax.set_title('Niveaux disponibles à la période cible',fontsize=9,loc='left'); ax.grid(axis='y',alpha=.18)
        fig.tight_layout(); p=outdir/f'figure_{len(paths)+1:02d}.png'; fig.savefig(p,dpi=190,bbox_inches='tight'); plt.close(fig); paths.append(p)
        break
    # B. shares: if they sum near 100 or are explicitly share indicators.
    shares=[r for r in rec if '%' in r.get('unit','')]
    if len(shares)>=2:
        vals=np.array([r['value'] for r in shares],float)
        fig=plt.figure(figsize=(7.25,2.35)); ax=fig.add_subplot(111)
        ax.bar(np.arange(len(shares)),vals)
        ax.set_xticks(np.arange(len(shares)),[r['label'][:27] for r in shares],rotation=32,ha='right',fontsize=6.3)
        ax.set_ylabel('%',fontsize=7); ax.set_title('Répartition / parts publiquement disponibles',fontsize=9,loc='left'); ax.grid(axis='y',alpha=.18)
        fig.tight_layout(); p=outdir/f'figure_{len(paths)+1:02d}.png'; fig.savefig(p,dpi=190,bbox_inches='tight'); plt.close(fig); paths.append(p)
    # C. time series from target-compatible source history only, one unit family at a time.
    hist=[r for r in rec if len(r.get('history') or [])>=4]
    if hist:
        # choose first common-unit subset
        unit=hist[0].get('unit',''); chosen=[r for r in hist if r.get('unit','')==unit][:3]
        if chosen:
            fig=plt.figure(figsize=(7.25,2.35)); ax=fig.add_subplot(111)
            for r in chosen:
                h=sorted(r['history'],key=lambda x:x['year']); ax.plot([x['year'] for x in h],[x['value'] for x in h],marker='o',label=r['label'][:22])
            ax.set_title('Évolution historique de séries publiques compatibles',fontsize=9,loc='left'); ax.grid(alpha=.18); ax.tick_params(labelsize=7); ax.legend(fontsize=6,ncol=2)
            fig.tight_layout(); p=outdir/f'figure_{len(paths)+1:02d}.png'; fig.savefig(p,dpi=190,bbox_inches='tight'); plt.close(fig); paths.append(p)
    return paths


def _figure_inventory(report):
    expected=report.get('reference_contract',{}).get('expected_figures',[]) or []
    rec=report.get('records',[])
    labels=' '.join((r.get('label','')+' '+r.get('matched_label','')) for r in rec).lower()
    inv=[]
    for fig in expected:
        low=str(fig).lower()
        status='NON RECONSTRUITE'
        detail='pas de preuve cible compatible'
        if 'répartition' in low or 'parts' in low:
            shares=[r for r in rec if '%' in r.get('unit','')]
            if len(shares)>=2: status='RECONSTRUITE'; detail='parts cibles disponibles'
        elif 'mensuel' in low:
            raws=[r for r in rec if len(r.get('raw_obs') or [])>=3 and any(o.get('month') for o in r.get('raw_obs') if isinstance(o,dict))]
            if raws: status='RECONSTRUITE'; detail='série mensuelle cible disponible'
        elif 'évolution' in low or 'trajectoire' in low or 'série longue' in low or 'dynamique' in low:
            hs=[r for r in rec if len(r.get('history') or [])>=4]
            if hs: status='RECONSTRUITE'; detail='historique cible compatible'
        elif 'intérieur / international' in low:
            if any('intérieur' in r.get('label','').lower() for r in rec) and any('international' in r.get('label','').lower() for r in rec): status='RECONSTRUITE'; detail='deux composantes cibles disponibles'
        else:
            if rec: status='PARTIELLE'; detail='cellules cibles disponibles, cartographie à valider'
        inv.append((fig,status,detail))
    return inv

def build_pdf(report,out_path):
    out_path.parent.mkdir(parents=True,exist_ok=True); figs=make_figures(report,out_path.parent); narr=build_narrative(report)
    rec=report.get('records',[]); der=report.get('derived',[])
    doc=SimpleDocTemplate(str(out_path),pagesize=A4,leftMargin=11.5*mm,rightMargin=11.5*mm,topMargin=9.5*mm,bottomMargin=9.5*mm)
    ss=getSampleStyleSheet()
    title=ParagraphStyle('v29t',parent=ss['Title'],fontName='Helvetica-Bold',fontSize=16,leading=17,spaceAfter=2)
    sub=ParagraphStyle('v29s',parent=ss['BodyText'],fontSize=8,leading=9.5,textColor=colors.HexColor('#555555'),spaceAfter=4)
    h=ParagraphStyle('v29h',parent=ss['Heading2'],fontSize=10.2,leading=11,spaceBefore=3,spaceAfter=2,textColor=colors.HexColor('#1f4e79'))
    body=ParagraphStyle('v29b',parent=ss['BodyText'],fontSize=8.2,leading=9.7,spaceAfter=3)
    small=ParagraphStyle('v29m',parent=ss['BodyText'],fontSize=5.9,leading=6.9,textColor=colors.HexColor('#555555'))
    story=[Paragraph(f"{_safe(report['fiche'])}. {_safe(report['title'])}",title), Paragraph(f"Pré-version open data — cible {_safe(report['target'])} — connaissance au {_safe(report['as_of'])}",sub), Paragraph('<b>Règle de preuve.</b> Le BAT 2024 et les Chiffres clés 2026 servent uniquement de gabarit documentaire, de définition et de calibration historique. Ils sont interdits comme preuves numériques de la cible.',small), Paragraph('À retenir',h)]
    for p in narr[:3]: story.append(Paragraph(_safe(p),body))
    if figs: story.append(Image(str(figs[0]),width=177*mm,height=58*mm))
    story.append(Paragraph('Tableau de synthèse',h))
    data=[['Indicateur','Valeur','Statut','Conf.']]
    for r in (rec+der)[:9]:
        stt=r.get('status',''); short={'OFFICIEL_PUBLIC':'OFFICIEL','PROVISOIRE_PUBLIC':'PROVISOIRE','ESTIMATION_PRODUCTEUR':'ESTIM. PROD.','CALCULATED_PUBLIC_ESTIMATE':'CALCULÉ / PUBLIC','RECONSTRUIT':'RECONSTRUIT','NOWCAST':'NOWCAST','ESTIME':'ESTIMÉ'}.get(stt,stt); data.append([_safe(r.get('label','')),fmt(r.get('value'))+' '+_safe(r.get('unit','')),short,f"{100*r.get('confidence',.0):.0f}%"])
    if len(data)==1: data.append(['Aucune cellule cible résolue','-','NON RÉSOLU','-'])
    t=Table(data,colWidths=[80*mm,37*mm,33*mm,20*mm],repeatRows=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#D9E2F3')),('GRID',(0,0),(-1,-1),.28,colors.HexColor('#AAAAAA')),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),5.9),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2)])); story.append(t)
    story.append(PageBreak()); story.append(Paragraph('Figures, méthodes et preuves cibles',h))
    for fp in figs[1:3]: story.append(Image(str(fp),width=177*mm,height=56*mm))
    # Show the reference structure without importing its source values.
    ref=report.get('reference_contract',{})
    figs_ref=ref.get('reference_template',{}).get('figures',[]) if isinstance(ref.get('reference_template'),dict) else []
    tabs_ref=ref.get('reference_template',{}).get('tables',[]) if isinstance(ref.get('reference_template'),dict) else []
    if figs_ref or tabs_ref:
        story.append(Paragraph('Structure éditoriale du gabarit (sans reprise des chiffres)',h))
        for x in figs_ref[:5]: story.append(Paragraph('• '+_safe(str(x)),small))
        for x in tabs_ref[:4]: story.append(Paragraph('• '+_safe(str(x)),small))
    inv=_figure_inventory(report)
    if inv:
        story.append(Paragraph('Contrat des figures',h)); fi=[['Figure attendue','État','Base']] + [[_safe(a),b,_safe(c)] for a,b,c in inv]
        ft=Table(fi,colWidths=[83*mm,30*mm,55*mm],repeatRows=1); ft.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#D9E2F3')),('GRID',(0,0),(-1,-1),.25,colors.HexColor('#AAAAAA')),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),5.8),('VALIGN',(0,0),(-1,-1),'TOP')])) ; story.append(ft)
    if rec:
        story.append(Paragraph('Provenance des valeurs cibles',h)); t2=[['Cellule','Méthode','Preuve cible','Date pub.']]
        for r in rec[:12]: t2.append([_safe(r.get('label')), _safe(r.get('method')), _safe((r.get('provider') or '')+' — '+str(r.get('source_quality_score',''))+'/100'), _safe(r.get('publication_date') or '')])
        tt=Table(t2,colWidths=[57*mm,59*mm,30*mm,24*mm],repeatRows=1); tt.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#D9E2F3')),('GRID',(0,0),(-1,-1),.25,colors.HexColor('#AAAAAA')),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),5.9),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2)])); story.append(tt)
    else: story.append(Paragraph('Aucune preuve cible directe n’a été suffisamment résolue.',small))
    aux=report.get('auxiliary_facts',[])
    if aux:
        story.append(Paragraph('Signaux publics de contexte',h))
        for a in aux[:5]: story.append(Paragraph(_safe(f"{a.get('concept','')}: {a.get('value')} {a.get('unit','')} — {a.get('note','')}"),small))
    story.append(Paragraph('Contrôles et limites',h))
    for q in report.get('qa',[])[:6]: story.append(Paragraph(_safe(f"{q.get('test')}: {q.get('status')} — {q.get('detail','')}"),small))
    story.append(Spacer(1,2)); story.append(Paragraph(_safe(narr[3] if len(narr)>3 else 'Le nowcast n’intervient qu’en dernier recours et reste explicitement identifié.'),small))
    doc.build(story); return out_path


def export_report(report):
    d=OUT/report['fiche']; d.mkdir(parents=True,exist_ok=True); report=dict(report); report['narrative']=build_narrative(report)
    (d/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    out=d/f"{report['fiche'].replace(' ','_')}_{str(report['target']).replace('/','-').replace(' ','_')}.pdf"; build_pdf(report,out); return d,out
