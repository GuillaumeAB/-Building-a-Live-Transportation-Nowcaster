from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
facts=[]
def add(fiche, cell_label, concept, value, unit, status, provider, date_published, url, note='', evidence_role='target'):
    facts.append({'id':f'{fiche}:{cell_label}:{date_published}:{provider}', 'fiche':fiche,'cell_label':cell_label,'concept':concept,'value':value,'unit':unit,'status':status,'provider':provider,'date_published':date_published,'url':url,'note':note,'evidence_role':evidence_role})

# G2 - exact categories, aligned to 2025 SDES publication
u='https://www.statistiques.developpement-durable.gouv.fr/donnees-2025-sur-les-immatriculations-des-vehicules'
add('G2','Immatriculations de voitures particulières neuves','Voitures particulières neuves 2025',1.665,'millions de véhicules','OFFICIEL_PUBLIC','sdes_specific','2026-02-11',u)
for lab,val in [('Électrique et hydrogène neuf',19.9),('Essence - hybride non rechargeable neuf',42.5),('Motorisations thermiques neuves',26.7),('Hybride rechargeable neuf',6.6)]:
    add('G2',lab,lab+' 2025',val,'%', 'OFFICIEL_PUBLIC','sdes_specific','2026-02-11',u)
add('G2','Voitures particulières d’occasion','Voitures particulières d’occasion 2025',5.534,'millions de véhicules','OFFICIEL_PUBLIC','sdes_specific','2026-02-11',u)
# G1 current public parc/circulation
u1='https://www.statistiques.developpement-durable.gouv.fr/40-millions-de-voitures-en-circulation-en-france-au-1er-janvier-2026'
add('G1','Distance parcourue par les voitures particulières','Distance annuelle moyenne des voitures particulières 2025',11600,'km/véhicule/an','OFFICIEL_PUBLIC','sdes_specific','2026-07-10',u1,'Indicateur de parcours moyen; ne remplace pas une distance totale en veh-km.', 'auxiliary')
add('G1','Distance totale parcourue par les véhicules routiers','Variation 2025 des distances parcourues par les voitures',-0.3,'%','OFFICIEL_PUBLIC','sdes_specific','2026-07-10',u1,'Signal de circulation; pas une valeur absolue.', 'auxiliary')
# E2 current quarterly road freight
u2='https://www.statistiques.developpement-durable.gouv.fr/activite-du-transport-routier-de-marchandises-au-quatrieme-trimestre-2025'
add('E2','Transport routier intérieur de marchandises','TRM pavillon français T4 2025',42.3,'milliards de tonnes-km CVS-CJO','PROVISOIRE_PUBLIC','sdes_specific','2026-04-14',u2)
u3='https://www.statistiques.developpement-durable.gouv.fr/donnees-relatives-a-lactivite-du-transport-routier-interieur-du-pavillon-francais-au-1er-trimestre-2026'
add('E2','Transport routier intérieur de marchandises','TRM pavillon français T1 2026',41.4,'milliards de tonnes-km CVS-CJO','PROVISOIRE_PUBLIC','sdes_specific','2026-07-07',u3,evidence_role='auxiliary')
# E4 / E5
add('E4','Transport fluvial de marchandises','Transport fluvial 2025',43.1,'millions de tonnes','OFFICIEL_PUBLIC','vnf','2026-01-01','https://www.vnf.fr/vnf/accueil/logistique-fluviale/economie-du-secteur-logistique/panorama-tendances-et-chiffres-cles-du-transport-fluvial/')
add('E4','Tonnage-kilomètres fluviaux','Tonnage-kilomètres fluviaux 2025',5.67,'milliards de tonnes-km','OFFICIEL_PUBLIC','vnf','2026-01-01','https://www.vnf.fr/vnf/accueil/logistique-fluviale/economie-du-secteur-logistique/panorama-tendances-et-chiffres-cles-du-transport-fluvial/')
add('E5','Trafic maritime de marchandises','Trafic maritime de marchandises 2025',333.4,'millions de tonnes','OFFICIEL_PUBLIC','sdes_specific','2026-07-24','https://www.statistiques.developpement-durable.gouv.fr/transport-maritime-de-marchandises')
add('E5','Trafic des grands ports maritimes','Trafic des grands ports T4 2025',74.2,'millions de tonnes CVS-CJO','PROVISOIRE_PUBLIC','sdes_specific','2026-03-20','https://www.statistiques.developpement-durable.gouv.fr/le-transport-maritime-de-marchandises-au-quatrieme-trimestre-2025',evidence_role='auxiliary')
# C1
u4='https://www.statistiques.developpement-durable.gouv.fr/emploi-salarie-et-marche-du-travail-dans-les-transports-au-quatrieme-trimestre-2025'
add('C1','Emploi salarié transports et entreposage','Effectif salarié transports et entreposage T4 2025',1564300,'salariés','OFFICIEL_PUBLIC','sdes_specific','2026-04-16',u4,'Point de fin d’année; la cible annuelle doit privilégier une moyenne/agrégat lorsque disponible.')
# F4
u5='https://www.ecologie.gouv.fr/sites/default/files/documents/Bulletin_Statistiques_transport_aerien_2025.pdf'
for lab,val in [('Trafic aérien total France',183.02),('Trafic métropole',178.15),('Trafic intérieur métropolitain',19.63),('Trafic international métropole',153.51)]:
    add('F4',lab,lab+' 2025',val,'millions de passagers','OFFICIEL_PUBLIC','dgac','2026-02-01',u5)
# F3 public provisional
u6='https://www.autorite-transports.fr/wp-content/uploads/2026/06/art-bilan-ferroviaire-france-premiers-chiffres-2025.pdf'
add('F3','Trafic ferroviaire total','Trafic ferroviaire de voyageurs 2025',118.0,'milliards de passagers-km','PROVISOIRE_PUBLIC','art','2026-06-01',u6,'Premiers chiffres 2025, provisoires; utilisé comme contrôle externe tant que la série SDES comparable n’est pas disponible.')
add('F3','Trafic ferroviaire total','Trafic ferroviaire hors Île-de-France 2025',2.4,'%','PROVISOIRE_PUBLIC','sdes_specific','2026-04-16','https://www.statistiques.developpement-durable.gouv.fr/activite-du-transport-ferroviaire-de-voyageurs-au-quatrieme-trimestre-2025','Évolution 2025/2024; signal annuel, pas un niveau.', 'auxiliary')
# F6 signals
add('F6','Fréquentation cyclable','Fréquentation cyclable 2025',5.0,'%','OFFICIEL_PUBLIC','reseau_velo_marche','2026-01-01','https://reseau-velo-marche.org/actualites/bilan-2025-de-la-frequentation-cyclable-en-france/','Variation annuelle d’un réseau de compteurs; signal pour le nowcast.', 'auxiliary')
# D2.1: public producer estimates
u7='https://www.citepa.org/emissions-de-gaz-a-effet-de-serre-en-france-apercu-du-premier-trimestre-de-lannee-2025-avec-le-barometre-du-citepa/'
add('D2.1','Émissions de GES des transports','GES transports T1 2026 vs T1 2025',-4.3,'%','ESTIMATION_PRODUCTEUR','citepa','2026-07-08',u7,'Estimation du baromètre Citepa. Variation, pas niveau.', 'auxiliary')
add('D2.1','Émissions de GES des transports','GES transports T1 2026 vs T1 2025',-1.2,'Mt CO2e','ESTIMATION_PRODUCTEUR','citepa','2026-07-08',u7,'Variation absolue, pas niveau.', 'auxiliary')
add('D2.1','Émissions de GES des transports','GES transports 2025',123.0,'Mt CO2e','PROXY_PRODUCTEUR','citepa','2026-06-16','https://www.citepa.org/le-rapport-secten-edition-2026-est-en-ligne/','Estimation Secten 2026, à traiter comme estimation producteur.', 'target')
# A10 quarterly price changes
u8='https://www.statistiques.developpement-durable.gouv.fr/indices-des-prix-du-transport-de-fret-et-de-lentreposage-au-quatrieme-trimestre-2025'
for lab,val in [('Prix du fret maritime',-4.4),('Prix du fret ferroviaire',-1.3),('Prix du fret routier',0.6)]:
    add('A10',lab,lab+' T4 2025 vs T3 2025',val,'% T/T-1','OFFICIEL_PUBLIC','sdes_specific','2026-03-10',u8,'Évolution trimestrielle de prix; cible annuelle d’indice nécessite une série de niveau.', 'auxiliary')
# D1 energy signal
add('D1','Consommation d’énergie des transports','Émissions CO2 combustion fossile T1 2026 vs T1 2025',-6.5,'%','OBSERVATION_PRODUCTEUR','sdes_specific','2026-05-12','https://www.statistiques.developpement-durable.gouv.fr/conjoncture-energetique-trimestrielle-premier-trimestre-2026','Signal macro-énergétique, pas niveau de consommation transport.', 'auxiliary')
# D3.2 exact 2025
u9='https://www.onisr.securite-routiere.gouv.fr/etat-de-linsecurite-routiere/bilans-annuels-de-la-securite-routiere/bilan-2025-de-la-securite-routiere'
add('D3.2','Tués sur les routes','Tués route France métropolitaine 2025',3263,'personnes','OFFICIEL_PUBLIC','onisr','2026-05-29',u9)
add('D3.2','Blessés sur les routes','Blessés route métropole 2025',247000,'personnes','ESTIMATION_PRODUCTEUR','onisr','2026-05-29',u9)
add('D3.2','Blessés graves','Blessés graves route métropole 2025',16800,'personnes','ESTIMATION_PRODUCTEUR','onisr','2026-05-29',u9)
(ROOT/'config/public_facts_v28.json').write_text(json.dumps({'version':'28.2','facts':facts},ensure_ascii=False,indent=2),encoding='utf8')
print('facts',len(facts))
