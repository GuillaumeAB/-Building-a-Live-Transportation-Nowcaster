from __future__ import annotations
import math, re

def eval_formula(expr, values):
    """Tiny safe expression evaluator for derived cells. Supports + - * /, min/max, abs and parentheses."""
    if not expr: return None
    names={k:float(v) for k,v in values.items() if isinstance(v,(int,float))}
    names.update({'min':min,'max':max,'abs':abs})
    if not re.fullmatch(r'[A-Za-z0-9_+\-*/()., <>=%]+',expr):
        raise ValueError('Expression interdite')
    return eval(expr,{'__builtins__':{}},names)
