from __future__ import annotations
import io, re
from pathlib import Path
import fitz
import pdfplumber
from catalog import get_bytes


def page_png(pdf_bytes:bytes,page_num:int,scale:float=1.35)->bytes:
    doc=fitz.open(stream=pdf_bytes,filetype='pdf'); page=doc.load_page(page_num-1); pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False); return pix.tobytes('png')


def page_tables(pdf_bytes:bytes,page_num:int):
    try:
        with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
            p=pdf.pages[page_num-1]
            tabs=p.extract_tables() or []
            clean=[]
            for t in tabs:
                rows=[]
                for r in t:
                    vals=[('' if x is None else str(x).strip()) for x in r]
                    if any(vals):rows.append(vals)
                if len(rows)>=2:clean.append(rows)
            return clean
    except Exception:
        return []
