# V28 - release notes

## Corrections critiques

- Le BAT 2024 / Chiffres clés 2026 sont explicitement interdits comme preuves numériques de la cible.
- Les faits publics ont désormais un `cell_label` obligatoire pour le routage exact ; plus de propagation d'un total vers des sous-composantes par fuzzy matching.
- G2 est alignée sur les catégories publiées 2025 : total en millions de véhicules + quatre parts de motorisation qui ferment à 95,7% selon la classification publiée, sans inventer un diesel séparé.
- Les sources sont datées et filtrées par `as-of` lorsqu'une date de publication est connue.

## Nouveautés

- contrat statistique enrichi pour les 53 fiches ; 183 cellules contractuelles ;
- data lake SQLite et index séries ;
- source firewall ;
- estimation de dernier recours ;
- figures / tableaux / narration reliés aux mêmes cellules cible ;
- benchmark complet des 53 fiches ;
- support XLSX / XLS / CSV, y compris `xlrd` pour les vieux XLS ;
- CLI et UI multi-fiches.
