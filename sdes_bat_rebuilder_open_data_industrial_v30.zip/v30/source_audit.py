from __future__ import annotations
import hashlib, json, time
from datetime import datetime, timezone
from pathlib import Path
import requests

ROOT=Path(__file__).resolve().parent
CACHE=ROOT/'cache'/'http'; CACHE.mkdir(parents=True,exist_ok=True)
SESSION=requests.Session(); SESSION.headers['User-Agent']='SDES-BAT-Rebuilder/8.0 (open-data research tool)'

def _key(url): return hashlib.sha256(url.encode()).hexdigest()

def fetch(url, max_age_days=7, timeout=90, force=False):
    k=_key(url); body=CACHE/f'{k}.bin'; meta=CACHE/f'{k}.json'
    if body.exists() and meta.exists() and not force and time.time()-body.stat().st_mtime < max_age_days*86400:
        m=json.loads(meta.read_text(encoding='utf-8')); return body.read_bytes(),{**m,'from_cache':True}
    started=time.time()
    try:
        r=SESSION.get(url,timeout=timeout)
        r.raise_for_status(); b=r.content
        body.write_bytes(b)
        m={'url':url,'retrieved_at':datetime.now(timezone.utc).isoformat(),'http_status':r.status_code,'content_type':r.headers.get('content-type',''),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'elapsed_s':round(time.time()-started,3)}
        meta.write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8'); return b,{**m,'from_cache':False}
    except Exception as e:
        # Last known snapshot is valuable during provider downtime.
        if body.exists() and meta.exists():
            m=json.loads(meta.read_text(encoding='utf-8')); m['error']=repr(e); m['from_cache']=True; return body.read_bytes(),m
        raise


def manifest_hash(manifest):
    raw=json.dumps(sorted(manifest,key=lambda x:(x.get('url',''),x.get('provider',''))),sort_keys=True,ensure_ascii=False).encode()
    return hashlib.sha256(raw).hexdigest()
