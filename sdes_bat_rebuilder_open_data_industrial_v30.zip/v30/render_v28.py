from __future__ import annotations
import json, html
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from editorial_v28 import build_narrative, fmt
ROOT=Path(__file__).resolve().parent; OUT=ROOT/'output'; OUT.mkdir(exist_ok=True)

def _safe_text(s): return html.escape(str(s or ''))

def make_figures(report,outdir):
    outdir.mkdir(parents=True,exist_ok=True); paths=[]
    rec=[r for r in report['records'] if r.get('value') is not None]
    # Figure 1: target values by component; avoid mixing share and level units
    for idx,group in enumerate([rec]):
        vals=[r for r in group if r.get('unit') and '%' not in r.get('unit','')][:8]
        if vals:
            plt.figure(figsize=(7.4,2.45)); plt.bar(np.arange(len(vals)),[r['value'] for r in vals]);
            plt.xticks(np.arange(len(vals)),[r['label'][:28] for r in vals],rotation=35,ha='right',fontsize=6.5)
            plt.ylabel(vals[0].get('unit',''),fontsize=7); plt.title('Niveau des principaux indicateurs à la période cible',fontsize=9,loc='left'); plt.grid(axis='y',alpha=.2); plt.tight_layout()
            p=outdir/'figure_01.png'; plt.savefig(p,dpi=180,bbox_inches='tight'); plt.close(); paths.append(p)
    # Figure 2: composition when all are shares
    shares=[r for r in rec if '%' in r.get('unit','') and r.get('value') is not None]
    if len(shares)>=2:
        plt.figure(figsize=(7.4,2.45)); plt.bar(np.arange(len(shares)),[r['value'] for r in shares]);
        plt.axhline(0,linewidth=.6); plt.xticks(np.arange(len(shares)),[r['label'][:26] for r in shares],rotation=35,ha='right',fontsize=6.5); plt.ylabel('%',fontsize=7); plt.title('Répartition / parts disponibles à la période cible',fontsize=9,loc='left'); plt.grid(axis='y',alpha=.2); plt.tight_layout()
        p=outdir/'figure_02.png'; plt.savefig(p,dpi=180,bbox_inches='tight'); plt.close(); paths.append(p)
    # Figure 3: histories from live target sources only
    hist_candidates=[r for r in rec if len(r.get('history') or [])>=3]
    if hist_candidates:
        chosen=hist_candidates[:4]; plt.figure(figsize=(7.4,2.45))
        for r in chosen:
            h=sorted(r['history'],key=lambda x:x['year']); plt.plot([x['year'] for x in h],[x['value'] for x in h],marker='o',label=r['label'][:22])
        plt.title('Évolution historique de séries publiques compatibles',fontsize=9,loc='left'); plt.grid(alpha=.2); plt.legend(fontsize=6.5,ncol=2); plt.tight_layout(); p=outdir/'figure_03.png'; plt.savefig(p,dpi=180,bbox_inches='tight'); plt.close(); paths.append(p)
    return paths

def build_pdf(report,out_path):
    d=out_path.parent; figs=make_figures(report,d); narr=build_narrative(report); rec=report['records']; der=report['derived'];
    doc=SimpleDocTemplate(str(out_path),pagesize=A4,leftMargin=12*mm,rightMargin=12*mm,topMargin=10*mm,bottomMargin=10*mm)
    ss=getSampleStyleSheet();
    title=ParagraphStyle('v28t',parent=ss['Title'],fontName='Helvetica-Bold',fontSize=16,leading=17,spaceAfter=2)
    sub=ParagraphStyle('v28s',parent=ss['BodyText'],fontSize=8,leading=9.5,textColor=colors.HexColor('#555555'),spaceAfter=5)
    h=ParagraphStyle('v28h',parent=ss['Heading2'],fontSize=10.5,leading=11.5,spaceBefore=4,spaceAfter=2,textColor=colors.HexColor('#1f4e79'))
    body=ParagraphStyle('v28b',parent=ss['BodyText'],fontSize=8.5,leading=10,spaceAfter=3.5)
    small=ParagraphStyle('v28m',parent=ss['BodyText'],fontSize=6.2,leading=7.2,textColor=colors.HexColor('#555555'))
    story=[Paragraph(f"{_safe_text(report['fiche'])}. {_safe_text(report['title'])}",title),Paragraph(f"Pré-version open data — cible {html.escape(str(report['target']))} — connaissance au {html.escape(str(report['as_of']))}",sub),Paragraph('<b>Politique.</b> Les documents BAT 2024 / Chiffres clés 2026 servent de gabarit, définition et calibration historique. Ils sont interdits comme preuves numériques de la cible.',small),Paragraph('À retenir',h)]
    for p in narr[:3]: story.append(Paragraph(_safe_text(p),body))
    if figs: story.append(Image(str(figs[0]),width=178*mm,height=58*mm));
    story.append(Paragraph('Tableau de synthèse',h))
    data=[['Indicateur','Valeur','Statut','Confiance']]
    for r in rec[:10]: data.append([_safe_text(r['label']),fmt(r['value'])+' '+_safe_text(r.get('unit','')),r.get('status',''),f"{100*r.get('confidence',0):.0f}%"])
    if der:
        for r in der[:6]: data.append([_safe_text(r['label']),fmt(r['value'])+' '+_safe_text(r.get('unit','')),r.get('status','CALCULE'),f"{100*r.get('confidence',0):.0f}%"])
    if len(data)==1: data.append(['Aucune cellule cible résolue','-','NON_RESOLU','-'])
    tab=Table(data,colWidths=[82*mm,39*mm,30*mm,20*mm],repeatRows=1)
    tab.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#D9E2F3')),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#AAAAAA')),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),6.4),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2)])); story.append(tab)
    story.append(PageBreak()); story.append(Paragraph('Figures, méthode et provenance',h))
    for fp in figs[1:]: story.append(Image(str(fp),width=178*mm,height=58*mm));
    if rec:
        story.append(Paragraph('Méthodes et qualité',h))
        t2=[['Cellule','Méthode','Source','Intervalle / note']]
        for r in rec[:12]:
            interval=''
            if r.get('lower') is not None and r.get('upper') is not None: interval=f"{fmt(r['lower'])} – {fmt(r['upper'])}"
            t2.append([_safe_text(r['label']),_safe_text(r.get('method','')), _safe_text(r.get('provider','')), _safe_text(interval or r.get('note',''))])
        tt=Table(t2,colWidths=[52*mm,48*mm,28*mm,43*mm],repeatRows=1); tt.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#D9E2F3')),('GRID',(0,0),(-1,-1),.3,colors.HexColor('#AAAAAA')),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),6.1),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),2),('RIGHTPADDING',(0,0),(-1,-1),2)])); story.append(tt)
    story.append(Spacer(1,3)); story.append(Paragraph(_safe_text(narr[3] if len(narr)>3 else 'Les estimations sont utilisées uniquement en dernier recours et restent identifiées.'),small))
    story.append(Paragraph('Sources ouvertes utilisées pour la cible',h))
    seen=set()
    for r in rec:
        u=r.get('url'); p=r.get('provider');
        if u and (p,u) not in seen: story.append(Paragraph(_safe_text(f'{p}: {u}'),small)); seen.add((p,u))
    doc.build(story); return out_path

def export_report(report):
    d=OUT/report['fiche']; d.mkdir(parents=True,exist_ok=True); report=dict(report); report['narrative']=build_narrative(report)
    (d/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8'); (d/'cells.json').write_text(json.dumps(report['records']+report['derived'],ensure_ascii=False,indent=2),encoding='utf8')
    out=d/f"{report['fiche'].replace(' ','_')}_{report['target']}.pdf"; build_pdf(report,out); return d,out
