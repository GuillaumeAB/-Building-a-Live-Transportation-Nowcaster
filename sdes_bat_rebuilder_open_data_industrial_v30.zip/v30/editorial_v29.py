from __future__ import annotations
import math


def fmt(x):
    if x is None: return 'n.d.'
    x=float(x)
    if abs(x)>=1000: return f'{x:,.0f}'.replace(',',' ').replace('.',',')
    if abs(x)>=100: return f'{x:,.1f}'.replace('.',',')
    if abs(x)>=10: return f'{x:,.1f}'.replace('.',',')
    return f'{x:,.2f}'.replace('.',',')


FAMILY_CONTEXT={
'activite':'L’activité économique des transports est suivie à travers les dépenses, la production, les prix et l’investissement.',
'entreprises':'La dynamique des entreprises renseigne sur le tissu productif et les évolutions sectorielles.',
'emploi':'L’emploi et les salaires décrivent l’évolution de l’activité et du marché du travail du secteur.',
'environnement':'Les indicateurs environnementaux relient activité de transport, consommation d’énergie, émissions et sécurité.',
'marchandises':'Les flux de marchandises reflètent l’activité économique et les arbitrages entre modes de transport.',
'voyageurs':'La mobilité des voyageurs dépend de l’offre, de la demande, des prix et des comportements.',
'circulation':'La circulation routière combine parc, usages, motorisations et consommation de carburants.',
'cadrage':'Le cadrage replace les transports dans leur environnement macroéconomique, européen et territorial.'}


def _status_phrase(r):
    s=r.get('status','')
    if s in {'OFFICIEL','OFFICIEL_PUBLIC'}: return 'donnée publique'
    if s in {'PROVISOIRE_PUBLIC','ESTIMATION_PRODUCTEUR','PROXY_PRODUCTEUR'}: return 'donnée publique provisoire/estimée par le producteur'
    if s in {'RECONSTRUIT','CALCULE'}: return 'valeur reconstruite à partir de données publiques'
    if s in {'NOWCAST','ESTIME'}: return 'estimation open data de dernier recours'
    return s.lower() or 'résultat'


def _period(report):
    if isinstance(report['target'], tuple): return f"au {report['target'][1]}e trimestre {report['target'][0]}"
    return f"en {report['target']}"


def build_narrative(report):
    rec=[r for r in report.get('records',[]) if r.get('value') is not None]
    der=[r for r in report.get('derived',[]) if r.get('value') is not None]
    allr=rec+der
    period=_period(report)
    ctx=FAMILY_CONTEXT.get(report.get('family'),'Les principaux indicateurs décrivent l’évolution récente des transports.')
    paras=[]
    if not rec:
        paras.append(f"{report['title']} : aucune preuve cible suffisamment compatible n’a encore été trouvée {period} dans les sources publiques autorisées.")
        paras.append("Le document de référence du BAT sert uniquement à définir la structure, les indicateurs et les figures à reproduire ; ses chiffres ne sont pas utilisés comme preuves de la cible.")
        paras.append("Le moteur recherche d’abord une observation directe, puis une agrégation ou un calcul déterministe. Le nowcast n’intervient qu’en dernier recours et seulement lorsqu’un backtest hors échantillon justifie l’usage de signaux avancés.")
        return paras
    # Lead: prefer first mandatory/main record, then highest confidence/value relevance.
    lead=sorted(rec,key=lambda r:(r.get('role')!='main',-r.get('confidence',0)))[0]
    paras.append(f"{period.capitalize()}, {lead['label'].lower()} atteint {fmt(lead['value'])} {lead.get('unit','')}. {ctx} Il s’agit d’une {_status_phrase(lead)}.")
    # Strong YoY facts
    yoy=sorted([(abs(r['yoy_pct']),r['yoy_pct'],r) for r in rec if r.get('yoy_pct') is not None],reverse=True)
    if yoy:
        bits=[]
        for _,g,r in yoy[:3]:
            bits.append(f"{r['label']} ({g:+.1f} %)")
        paras.append("Les évolutions interannuelles disponibles mettent notamment en évidence " + ', '.join(bits) + ".")
    else:
        # Use auxiliary public signals to make the narrative informative without treating them as target cells.
        aux=report.get('auxiliary_facts',[])
        if aux:
            bits=[]
            for a in aux[:3]:
                bits.append(f"{a.get('concept','indicateur')} ({a.get('value')} {a.get('unit','')})")
            paras.append("Les publications récentes apportent aussi des signaux de contexte : " + '; '.join(bits) + ".")
        else:
            component=rec[:4]
            if len(component)>=2:
                bits=[f"{r['label']} : {fmt(r['value'])} {r.get('unit','')}" for r in component[:3]]
                paras.append("Les principaux postes disponibles sont " + '; '.join(bits) + ".")
            else:
                paras.append("La comparaison interannuelle est ajoutée dès qu’une série publique comparable est disponible ; elle n’est pas déduite d’un périmètre différent.")
    flags=[r for r in rec if r.get('status') in {'PROVISOIRE_PUBLIC','ESTIMATION_PRODUCTEUR','PROXY_PRODUCTEUR','NOWCAST','ESTIME','RECONSTRUIT','CALCULE'}]
    if flags:
        bits=[]
        for r in flags[:4]: bits.append(f"{r['label']} ({r.get('status')})")
        paras.append("Certaines valeurs sont provisoires, reconstruites ou estimées : " + '; '.join(bits) + ".")
    else:
        paras.append("Aucun nowcast de dernier recours n’est nécessaire pour les cellules actuellement résolues.")
    return paras[:4]
