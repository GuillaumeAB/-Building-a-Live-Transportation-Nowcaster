@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  py -3.14 -m venv .venv || py -3 -m venv .venv
  .venv\Scripts\python.exe -m pip install -r requirements.txt
)
echo [V30] Lancement parallele F4 2025 + D2.1 T1 2026...
.venv\Scripts\python.exe run_v30_examples.py
if errorlevel 1 (
  echo ECHEC - voir les messages ci-dessus.
  pause
  exit /b 1
)
echo.
echo PDF F4: output\F4\F4_2025.pdf
echo PDF D2.1: output\D2.1\D21_T1_2026.pdf
echo.
pause
