from __future__ import annotations
import re
from typing import Sequence
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

STOP={'transport','transports','transportation','de','du','des','la','le','les','et','en','pour','dans','par','avec','aux','au','sur','en','france'}

def _clean(x):
    x=re.sub(r'[^\wÀ-ÿ%+\-/ ]+',' ',str(x or '').lower())
    return ' '.join(w for w in x.split() if w not in STOP)

def rank(query:str, labels:Sequence[str], limit=10):
    labels=list(labels)
    if not labels:return []
    docs=[_clean(query)]+[_clean(x) for x in labels]
    X=TfidfVectorizer(ngram_range=(1,2),min_df=1).fit_transform(docs)
    sims=cosine_similarity(X[0:1],X[1:]).ravel()
    return sorted(zip(labels,sims),key=lambda z:z[1],reverse=True)[:limit]
