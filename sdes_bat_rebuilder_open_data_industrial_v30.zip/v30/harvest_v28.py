from __future__ import annotations
import json, re, hashlib, time, os
from pathlib import Path
from urllib.parse import urljoin, urlparse
import requests
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parent
CFG=json.loads((ROOT/'config/source_registry_v28.json').read_text(encoding='utf-8'))
REF=ROOT/'reference'; CAL=ROOT/'reference/calibration'; LIVE=ROOT/'acquired/live'; META=ROOT/'data_lake'
CAL.mkdir(parents=True,exist_ok=True)
for d in (REF,LIVE,META): d.mkdir(parents=True,exist_ok=True)

S=requests.Session(); S.headers.update({'User-Agent':'SDES-BAT-Rebuilder/28 (open-data research; contact-free)'})
TIMEOUT=45

def sha256_bytes(b): return hashlib.sha256(b).hexdigest()

def safe_name(url, fallback='download.bin'):
    name=Path(urlparse(url).path).name or fallback
    name=re.sub(r'[^A-Za-z0-9_.-]+','_',name)
    return name[:180]

def fetch(url):
    r=S.get(url,timeout=TIMEOUT,allow_redirects=True)
    r.raise_for_status(); return r

def discover_links(page_url):
    r=fetch(page_url); soup=BeautifulSoup(r.text,'html.parser'); out=[]
    for a in soup.find_all('a',href=True):
        u=urljoin(page_url,a['href']); txt=' '.join(a.stripped_strings)
        ext=re.search(r'\.(xlsx|xls|csv|zip|pdf)(?:\?|$)',u,re.I)
        if ext:
            out.append({'url':u,'label':txt or safe_name(u),'page':page_url,'kind':ext.group(1).lower()})
    seen=set(); res=[]
    for x in out:
        if x['url'] not in seen: seen.add(x['url']); res.append(x)
    return res

def download(item, root=LIVE, publication_date=None):
    r=fetch(item['url']); b=r.content
    fn=safe_name(item['url'])
    p=root/fn
    p.write_bytes(b)
    meta={'url':item['url'],'final_url':r.url,'publication_date':publication_date,'status':r.status_code,'content_type':r.headers.get('content-type',''),'size':len(b),'sha256':sha256_bytes(b),'retrieved_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'label':item.get('label',''),'page':item.get('page',''),'provider':item.get('provider'),'kind':item.get('kind')}
    meta['local_file']=str(p); return p,meta

def run():
    manifest={'generated_at':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'reference':[],'live':[],'errors':[]}
    # Reference documents and pages are stored separately; their data files are never copied to live.
    for ref_name,url in [('BAT_2024_PAGE','https://www.statistiques.developpement-durable.gouv.fr/bilan-annuel-des-transports-en-2024'),('CK_2026_PAGE','https://www.statistiques.developpement-durable.gouv.fr/chiffres-cles-des-transports-edition-2026')]:
        try:
            rr=fetch(url); (REF/(ref_name+'.html')).write_text(rr.text,encoding='utf-8')
            manifest['reference'].append({'name':ref_name,'url':url,'status':rr.status_code})
            try:
                pdfs=[x for x in discover_links(url) if x['kind']=='pdf']
                for x in pdfs[:2]:
                    try:
                        p,m=download(x,REF); m['reference_role']='template_only'; manifest['reference'].append(m)
                    except Exception as e: manifest['errors'].append({'stage':'reference_pdf','url':x['url'],'error':repr(e)})
            except Exception: pass
        except Exception as e: manifest['errors'].append({'stage':'reference','url':url,'error':repr(e)})
    # Download historical BAT/CK data files into a separate calibration store.
    # These are NEVER treated as target evidence.
    for provider,page in [('sdes_bat_2024','https://www.statistiques.developpement-durable.gouv.fr/bilan-annuel-des-transports-en-2024'),('sdes_ck_2026','https://www.statistiques.developpement-durable.gouv.fr/chiffres-cles-des-transports-edition-2026')]:
        try:
            for x in discover_links(page):
                if x['kind'] not in {'xlsx','xls','csv'}: continue
                x['provider']=provider
                p,m=download(x,CAL); m['reference_role']='history_calibration_only'; manifest['reference'].append(m)
        except Exception as e: manifest['errors'].append({'stage':'calibration','url':page,'provider':provider,'error':repr(e)})

    # Explicit current public pages: only their data downloads become target evidence.
    seen=set()
    for rec in CFG.get('current_public_pages',[]):
        page=rec['url']; provider=rec['provider']; publication_date=rec.get('date')
        try:
            for x in discover_links(page):
                x['provider']=provider
                key=(x['url'],provider)
                if key in seen or x['kind'] not in {'xlsx','xls','csv'}: continue
                seen.add(key)
                try:
                    p,m=download(x,LIVE,publication_date); manifest['live'].append(m)
                except Exception as e: manifest['errors'].append({'stage':'download','url':x['url'],'provider':provider,'error':repr(e)})
        except Exception as e:
            manifest['errors'].append({'stage':'page','url':page,'provider':provider,'error':repr(e)})
    # Current SDES search pages by family: discover latest themed publications and their data files.
    family_queries={
      'cadrage':'infrastructures transports activité économique Europe PIB',
      'activite':'dépenses transport production transport investissements prix fret',
      'entreprises':'entreprises transport créations défaillances chiffre affaires',
      'emploi':'emploi salarié transport marché travail salaires transport',
      'environnement':'énergie transports émissions polluants accidents nuisances',
      'marchandises':'transport routier ferroviaire fluvial maritime aérien marchandises',
      'voyageurs':'transport voyageurs ferroviaire aérien maritime urbain vélo',
      'circulation':'circulation routière immatriculations parc carburants'
    }
    base='https://www.statistiques.developpement-durable.gouv.fr/recherche?text='
    for fam,q in family_queries.items():
        try:
            sr=fetch(base+requests.utils.quote(q)); soup=BeautifulSoup(sr.text,'html.parser')
            links=[]
            for a in soup.find_all('a',href=True):
                u=urljoin(sr.url,a['href']); txt=' '.join(a.stripped_strings)
                if 'statistiques.developpement-durable.gouv.fr/' in u and '/recherche' not in u and txt:
                    if u.count('/')>3: links.append((u,txt))
            for u,txt in links[:12]:
                try:
                    for x in discover_links(u):
                        if x['kind'] not in {'xlsx','xls','csv'}: continue
                        x['provider']='sdes_specific'; key=(x['url'],'sdes_specific')
                        if key in seen: continue
                        seen.add(key); p,m=download(x,LIVE); m['discovered_from']=u; m['family']=fam; manifest['live'].append(m)
                except Exception as e: manifest['errors'].append({'stage':'family_discovery','url':u,'family':fam,'error':repr(e)})
        except Exception as e: manifest['errors'].append({'stage':'family_search','url':base+q,'family':fam,'error':repr(e)})
    (META/'HARVEST_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    return manifest

if __name__=='__main__':
    m=run(); print(json.dumps({'live_files':len(m['live']),'errors':len(m['errors'])},ensure_ascii=False))
