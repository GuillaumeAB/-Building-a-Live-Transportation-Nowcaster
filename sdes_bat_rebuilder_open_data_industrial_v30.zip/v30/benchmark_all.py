from benchmark_v28 import run
if __name__ == "__main__":
    df,fam=run(); print(df.to_string(index=False)); print("\nPAR FAMILLE\n",fam.to_string(index=False))
