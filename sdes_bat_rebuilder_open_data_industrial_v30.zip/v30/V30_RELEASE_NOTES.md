# V30 — benchmark public F/D et production parallèle

## Objectif

V30 corrige le défaut méthodologique principal des versions précédentes : le BAT 2024 / Chiffres clés servent de spécification éditoriale, jamais de preuve numérique cible.

La livraison inclut un lancement interne reproductible en parallèle de deux fiches démonstratrices :
- F4 au titre de 2025 ;
- D2.1 au titre du T1 2026.

Les preuves cibles sont exclusivement issues de producteurs publics externes au BAT de référence (DGAC / Citepa dans ces deux cas).

## Améliorations

- exécution parallèle des fiches de démonstration ;
- séparation stricte gabarit / preuve cible ;
- registres de faits publics datés et URL ;
- rendu 2 pages avec texte analytique, graphiques et tableau ;
- niveaux implicites D2.1 explicitement marqués comme calculs à partir de variations arrondies ;
- comparaison 2024/2025 F4 avec base DGAC, sans réutiliser un chiffre BAT ;
- rapport de lancement interne (`output/INTERNAL_LAUNCH_F4_D21_20260829.json`).
