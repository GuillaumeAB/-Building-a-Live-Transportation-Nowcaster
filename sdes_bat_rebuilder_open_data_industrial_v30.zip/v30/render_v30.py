from __future__ import annotations
import json
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from v30_core import fmt
ROOT=Path(__file__).resolve().parent

BLUE=colors.HexColor('#1f4e79'); PALE=colors.HexColor('#eaf0f7'); GREY=colors.HexColor('#666666'); LIGHT=colors.HexColor('#f5f7fa')

def draw_figure(report, spec, out):
    out.parent.mkdir(parents=True,exist_ok=True)
    fig=plt.figure(figsize=(7.15,2.55)); ax=fig.add_subplot(111)
    k=spec['kind']; d=spec['data']; unit=spec.get('unit','')
    if k=='bar_compare':
        x=np.arange(len(d['labels'])); vals=np.array(d['values'],float); ax.bar(x,vals,width=.52)
        ax.set_xticks(x,d['labels']); ax.set_ylabel(unit,fontsize=7)
        for i,v in enumerate(vals): ax.text(i,v+(max(vals)*.022 if max(vals)>0 else .02),fmt(v,1),ha='center',fontsize=8)
    elif k=='stack':
        bottom=0
        for name,v in zip(d['names'],d['parts']):
            ax.bar(['2025'],[v],bottom=bottom,label=f'{name} : {fmt(v,1)}'); bottom+=v
        ax.set_ylabel(unit,fontsize=7); ax.legend(fontsize=7,frameon=False,loc='upper center',bbox_to_anchor=(.5,1.18),ncol=2)
    elif k=='single_share':
        v=float(d['value']); ax.barh([0],[v],height=.34); ax.set_xlim(0,100); ax.set_xlabel('%',fontsize=7); ax.set_yticks([0],[d['label']]); ax.text(v+1,0,fmt(v,1)+' %',va='center',fontsize=9); ax.grid(axis='x',alpha=.18)
    elif k=='drivers':
        x=np.arange(len(d['labels'])); vals=np.array(d['values'],float); ax.bar(x,vals,width=.52); ax.axhline(0,linewidth=.7); ax.set_xticks(x,d['labels']); ax.set_ylabel(unit,fontsize=7)
        for i,v in enumerate(vals): ax.text(i,v+(0.6 if v>=0 else -0.6),f'{v:+.1f} %',ha='center',va='bottom' if v>=0 else 'top',fontsize=8)
    ax.set_title(spec['title'],loc='left',fontsize=9.5,fontweight='bold',pad=6); ax.grid(axis='y',alpha=.17); ax.tick_params(labelsize=7)
    fig.tight_layout(); fig.savefig(out,dpi=190,bbox_inches='tight'); plt.close(fig); return out

def page_footer(canvas,doc):
    canvas.saveState(); canvas.setFont('Helvetica',5.8); canvas.setFillColor(GREY)
    canvas.drawString(11*mm,5*mm,'Pré-version open data — la future publication officielle peut diverger (révisions, périmètres, sources).')
    canvas.drawRightString(199*mm,5*mm,f'{doc.page}')
    canvas.restoreState()

def build_pdf(report,path):
    out=path.parent; out.mkdir(parents=True,exist_ok=True)
    fpaths=[draw_figure(report,spec,out/f'figure_{i:02d}.png') for i,spec in enumerate(report['figures'],1)]
    ss=getSampleStyleSheet()
    title=ParagraphStyle('title',parent=ss['Title'],fontName='Helvetica-Bold',fontSize=17.2,leading=18.5,textColor=BLUE,spaceAfter=2)
    deck=ParagraphStyle('deck',parent=ss['BodyText'],fontSize=8,leading=9.5,textColor=GREY,spaceAfter=5)
    h=ParagraphStyle('h',parent=ss['Heading2'],fontSize=10.6,leading=11.6,textColor=BLUE,spaceBefore=2.5,spaceAfter=3)
    body=ParagraphStyle('body',parent=ss['BodyText'],fontSize=8.55,leading=10.35,spaceAfter=4)
    small=ParagraphStyle('small',parent=ss['BodyText'],fontSize=6.05,leading=7.1,textColor=GREY)
    source=ParagraphStyle('source',parent=small,fontSize=5.6,leading=6.5)
    doc=SimpleDocTemplate(str(path),pagesize=A4,leftMargin=11*mm,rightMargin=11*mm,topMargin=9*mm,bottomMargin=9*mm)
    story=[Paragraph(f"{report['fiche']} — {report['title']}",title),Paragraph(f"Pré-version open data • {report['period_label']} • connaissance au 29/08/2026",deck),Paragraph('<b>Positionnement.</b> Les données cibles ci-dessous proviennent exclusivement de producteurs publics. Les documents BAT 2024 et Chiffres clés 2026 ne servent qu’à définir la structure et les objets éditoriaux.',small),Paragraph('À retenir',h)]
    story += [Paragraph(p,body) for p in report['paragraphs'][:2]]
    story += [Image(str(fpaths[0]),width=176*mm,height=59*mm),Spacer(1,2),Paragraph('Tableau de synthèse',h)]
    tbl=Table(report['table'],colWidths=[75*mm,35*mm,60*mm],repeatRows=1)
    tbl.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),PALE),('TEXTCOLOR',(0,0),(-1,0),BLUE),('FONTNAME',(0,0),(-1,0),'Helvetica-Bold'),('FONTSIZE',(0,0),(-1,-1),6.7),('LEADING',(0,0),(-1,-1),7.6),('GRID',(0,0),(-1,-1),.25,colors.HexColor('#b9c1ca')),('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),3),('RIGHTPADDING',(0,0),(-1,-1),3)])); story.append(tbl)
    story.append(Paragraph('Sources cibles : '+ '; '.join(report['sources']),source))
    story.append(PageBreak())
    story += [Paragraph('Évolutions, lecture et méthode',h)]
    for p in report['paragraphs'][2:]: story.append(Paragraph(p,body))
    for fp,spec in zip(fpaths[1:],report['figures'][1:]):
        story.append(Image(str(fp),width=176*mm,height=58*mm));
        if spec.get('disclaimer'): story.append(Paragraph(spec['disclaimer'],small))
        story.append(Spacer(1,2))
    story.append(Paragraph('Provenance et limites',h))
    for r in report['records']:
        role='cible' if r.get('role','target')=='target' else 'auxiliaire'
        story.append(Paragraph(f"<b>{r['label']}</b> : {r['value']} {r['unit']} — {r['status']} — {r['provider']} — publié le {r['published']} — {role}.",small))
    story.append(Spacer(1,2)); story.append(Paragraph(report['reference_note'],small))
    doc.build(story,onFirstPage=page_footer,onLaterPages=page_footer)
    return path

def export(report):
    out=ROOT/'output'/report['fiche']; out.mkdir(parents=True,exist_ok=True)
    path=out/(f"{report['fiche'].replace('.','')}_{report['target'].replace(' ','_').replace('/','-')}.pdf")
    build_pdf(report,path); (out/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8'); return path
