from __future__ import annotations
from pathlib import Path
import json

def priority(row):
    status=row.get('status','')
    conf=float(row.get('confidence',0) or 0)
    score=float(row.get('semantic_score',0) or 0)
    if status=='NON_RESOLU': return 100
    if status=='ESTIME' and conf<0.7: return 80
    if score<55: return 70
    if row.get('break_detected'): return 75
    if status=='PROXY': return 60
    return 10

def review_queue(records, unresolved=None):
    rows=[]
    for r in records:
        z=dict(r); z['review_priority']=priority(z); rows.append(z)
    for u in unresolved or []:
        z=dict(u); z.update({'status':'NON_RESOLU','review_priority':100}); rows.append(z)
    return sorted(rows,key=lambda x:-x['review_priority'])
