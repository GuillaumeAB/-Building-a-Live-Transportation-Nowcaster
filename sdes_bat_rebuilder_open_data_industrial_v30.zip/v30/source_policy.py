from __future__ import annotations
from dataclasses import dataclass
from urllib.parse import urlparse

REFERENCE_ONLY = {"sdes_bat_2024", "sdes_ck_2026"}
REFERENCE_HOSTS = {
    "www.statistiques.developpement-durable.gouv.fr": ("/bilan-annuel-des-transports-en-2024", "/chiffres-cles-des-transports-edition-2026"),
}
PRIMARY = {
    "sdes_specific", "sdes_conj", "insee", "eurostat", "art", "sncf", "citepa",
    "onisr", "vnf", "dgac", "cerema", "idfm", "ratp", "urssaf", "francetravail",
    "groupe_adp", "dgitm", "dgamapa", "garts", "data_gouv", "energie_sdes", "bodacc",
    "reseau_velo_marche", "haropa", "isula", "banque_france",
}

@dataclass(frozen=True)
class SourceDecision:
    allowed_for_target: bool
    allowed_for_history_calibration: bool
    reason: str
    classification: str


def _looks_reference_url(url: str) -> bool:
    try:
        p = urlparse(url or "")
        host = p.netloc.lower()
        path = p.path.lower()
        if host in REFERENCE_HOSTS:
            prefixes = REFERENCE_HOSTS[host]
            return any(path.startswith(x) for x in prefixes)
        # Also block obvious downloaded BAT/CK assets that may carry a generic provider label.
        return host.endswith("statistiques.developpement-durable.gouv.fr") and any(x in path for x in ("/bilan-annuel-des-transports-en-2024", "/chiffres-cles-des-transports-edition-2026"))
    except Exception:
        return False


def classify(provider: str, url: str = "") -> str:
    p = (provider or "").lower()
    if p in REFERENCE_ONLY or _looks_reference_url(url):
        return "reference_only"
    if p in PRIMARY:
        return "primary_open"
    return "other_open"


def policy(provider: str, purpose: str = "target", url: str = "") -> SourceDecision:
    cls = classify(provider, url)
    if cls == "reference_only":
        if purpose == "history_calibration":
            return SourceDecision(False, True, "BAT 2024 / Chiffres clés 2026 : référence documentaire et calibration historique uniquement.", cls)
        return SourceDecision(False, False, "BAT 2024 / Chiffres clés 2026 interdits comme preuve numérique de la cible.", cls)
    return SourceDecision(True, True, "Source publique hors gabarit, utilisable sous réserve de compatibilité conceptuelle, temporelle et d'unité.", cls)


def evidence_ok(record: dict) -> bool:
    return policy(record.get("provider", ""), "target", record.get("url", "")).allowed_for_target


def audit_records(records: list[dict]) -> list[dict]:
    out=[]
    for r in records:
        d=policy(r.get("provider",""),"target",r.get("url",""))
        out.append({"cell_id":r.get("cell_id"),"provider":r.get("provider"),"url":r.get("url"),"classification":d.classification,"allowed":d.allowed_for_target,"reason":d.reason})
    return out
