from __future__ import annotations
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
REG=json.loads((ROOT/'config/registry_v28_upgrade.json').read_text(encoding='utf8'))
def make_registry(): return REG
