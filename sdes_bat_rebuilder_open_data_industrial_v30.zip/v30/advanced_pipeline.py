from __future__ import annotations
import json, math, re
from pathlib import Path
from datetime import datetime, timezone
import numpy as np, pandas as pd
from rapidfuzz.fuzz import token_set_ratio
from semantic_match import rank as semantic_rank
from expert_registry import norm, build_registry
from pipeline import prepare_context
from series import target_value, project, backtest, score
from series_diagnostics import quality

ROOT=Path(__file__).resolve().parent
CONF=json.loads((ROOT/'config/fiches_2024.json').read_text(encoding='utf-8'))
RULES=json.loads((ROOT/'config/indicator_rules.json').read_text(encoding='utf-8'))

STATUS_RANK={'OFFICIEL':5,'RECONSTRUIT':4,'CALCULE':4,'ESTIME':3,'PROXY':2}

def _freq(s):
    o=s.get('obs',[])
    if any(x.get('month') for x in o): return 'mensuel'
    if any(x.get('quarter') for x in o): return 'trimestriel'
    return 'annuel'

def _last(s): return max((x.get('year',0),x.get('quarter') or 0,x.get('month') or 0) for x in s.get('obs',[])) if s.get('obs') else None

def _ratio_from_records(a,b,label,unit='%'):
    if a is None or b is None:return None
    den=float(b.get('value')) if isinstance(b,dict) else float(b)
    num=float(a.get('value')) if isinstance(a,dict) else float(a)
    if not np.isfinite(den) or den==0 or not np.isfinite(num):return None
    v=100*num/den
    return {'value':v,'lower':v,'upper':v,'status':'CALCULE','method':f'{label}: numérateur/dénominateur','confidence':min(a.get('confidence',1),b.get('confidence',1)),'unit':unit}

def resolve_cell(cell,series_idx,target_kind,target):
    aliases=cell.get('aliases') or [cell['label']]
    labels=[s.get('label','') for s in series_idx]
    sem=dict(semantic_rank(' '.join(aliases),labels,limit=min(50,len(labels)))) if labels else {}
    cand=[]
    for s in series_idx:
        fuzzy=score(s['label'],aliases)
        sim=float(sem.get(s.get('label',''),0.0))*100
        sc=max(fuzzy,sim*0.9+fuzzy*0.1)
        if sc<38:continue
        tv=target_value(s['obs'],target_kind,target,cell.get('variable_type','flow'))
        bt=backtest(s['obs'],cell.get('variable_type','flow'))
        if tv:
            v,k=tv; status='OFFICIEL' if k=='direct' else 'RECONSTRUIT'; unc=0.0
        else:
            pr=project(s['obs'],target_kind,target,cell.get('variable_type','flow'))
            if not pr:continue
            v,k=pr['value'],pr['method']; status='ESTIME'; unc=pr['uncertainty']
        prov=s.get('source') or s.get('url')
        src_pr=s.get('source_priority',80)
        diag=quality(s.get('obs',[]))
        freshness=1.0
        last=_last(s)
        if last:
            now_year=int(target if target_kind=='annual' else target[0])
            gap=max(0,now_year-last[0]); freshness=max(0.35,1-0.08*gap)
        conf=max(.05,min(.995, .35 + .0035*sc + .0015*src_pr + .12*freshness - unc - 0.15*diag['break']['score']))
        cand.append({'value':float(v),'lower':float(v)*(1-unc),'upper':float(v)*(1+unc),'status':status,'method':k,'confidence':round(conf,3),'backtest_mae_pct':bt,
                     'frequency':_freq(s),'source':prov,'url':s.get('url'),'provider':s.get('provider'),'sheet':s.get('sheet'),'row':s.get('row'),
                     'matched_label':s.get('label'),'semantic_score':sc,'unit':cell.get('unit',''),'last_observation':s.get('obs',[])[-1],
                     'freshness_gap_years':(int(target if target_kind=='annual' else target[0])-last[0] if last else None),'alternatives':[],
                     'break_detected':diag['break']['detected'],'break_score':diag['break']['score'],'n_obs':diag['n_numeric'],'span_years':diag['span_years']})
    if not cand:return None
    cand.sort(key=lambda x:(STATUS_RANK[x['status']],x['confidence'],x['semantic_score']),reverse=True)
    best=cand[0]; best['alternatives']=cand[1:6]
    return best

def reconcile(fiche,records,registry):
    out=[]; rule=RULES.get(fiche,{})
    if rule.get('total'):
        labels=list(rule.get('components',{}))
        by={norm(r['label']):r for r in records}
        comps=[by.get(norm(x)) for x in labels]
        if all(comps):
            v=sum(x['value'] for x in comps); lo=sum(x.get('lower',x['value']) for x in comps); hi=sum(x.get('upper',x['value']) for x in comps)
            out.append({'cell_id':f'{fiche}:TOTAL','label':rule['total']['label'],'value':v,'lower':lo,'upper':hi,'status':'CALCULE','method':'somme contrôlée des composantes','confidence':min(x.get('confidence',.5) for x in comps),'unit':rule['total'].get('unit',''),'inputs':[x['cell_id'] for x in comps]})
    # Cross-source diagnostic: if total is published separately, compare to derived sum when available.
    published_total=(RULES.get(fiche) or {}).get('total')
    if published_total:
        lbl=norm(published_total.get('label',''))
        tc=[r for r in records if norm(r.get('label',''))==lbl]
        if tc and out:
            x=tc[0]; d=out[0];
            if x.get('value') not in (None,0):
                gap=(d['value']-x['value'])/abs(x['value'])
                out[0]['published_total_gap_pct']=100*gap
                out[0]['status']='CALCULE_CONTROLE'
    return out

def build(fiche,target_kind,target,ctx=None):
    ctx=ctx or prepare_context(); bat=ctx['bat']; ck=ctx['ck']
    registry=build_registry(bat); meta=registry[fiche]
    rec=[]; unresolved=[]
    for c in meta['cells']:
        if c['role']=='candidate' and c['mandatory'] is False and len(c['aliases'])==0: unresolved.append(c); continue
        rr=resolve_cell(c,ctx['series_idx'],target_kind,target)
        if rr:
            rr.update({'cell_id':c['cell_id'],'label':c['label'],'role':c['role'],'mandatory':c['mandatory']}); rec.append(rr)
        else: unresolved.append(c)
    derived=reconcile(fiche,rec,registry)
    # Derived editorial stats from any available total/component data.
    shares=[]
    tot=next((d for d in derived if d.get('label')==((RULES.get(fiche) or {}).get('total') or {}).get('label')),None)
    if tot and tot.get('value'):
        for r in rec:
            if r.get('role') in ('component','candidate'):
                z=_ratio_from_records(r,tot,f"Part de {r['label']}")
                if z: z.update({'cell_id':r['cell_id']+':SHARE','label':f"Part de {r['label']}",'role':'derived_share'}); shares.append(z)
    # Structural checks
    checks=[]
    resolved=sum(r.get('value') is not None for r in rec); mandatory=sum(1 for c in meta['cells'] if c['mandatory'])
    checks.append({'test':'Couverture globale','status':'OK' if resolved else 'ALERTE','detail':f'{resolved}/{len(meta["cells"])} cellules résolues'})
    checks.append({'test':'Couverture des cellules obligatoires','status':'OK' if resolved>=mandatory else 'ALERTE','detail':f'{resolved}/{mandatory}'})
    bad=[r for r in rec if r['unit']!='%' and r['value']<0]
    checks.append({'test':'Valeurs négatives','status':'ALERTE' if bad else 'OK','detail':len(bad)})
    if tot: checks.append({'test':'Réconciliation totale','status':'OK','detail':f"{tot['value']:.3f} {tot['unit']}"})
    return {'version':'7.0.0','fiche':fiche,'title':meta['title'],'family':meta['family'],'target_kind':target_kind,'target':target,
            'edition_mode':'BAT 2025 + Chiffres clés 2026 co-produits, open data uniquement','open_data_only':True,
            'reference':{'bat':bat[fiche],'ck':[p for p in ck if any(fiche.lower() in str(x).lower() for x in p.get('bat_refs',[])) or any(fiche.split()[0].lower() in str(x).lower() for x in p.get('bat_refs',[]))]},
            'editorial':{'figures':meta['figures'],'tables':meta['tables'],'sources':meta['sources'],'pages':bat[fiche].get('pages',[])},
            'cells':meta['cells'],'records':rec,'derived':derived+shares,'unresolved':unresolved,'review_queue':__import__('review').review_queue(rec,unresolved),'checks':checks,
            'sources':ctx['sources'],'series_index_stats':{'series_considered':len(ctx['series_idx']),'errors':ctx['series_errors']},'created_at':datetime.now(timezone.utc).isoformat()}

def build_all(target_year=2025,ctx=None):
    ctx=ctx or prepare_context(); return [build(f,'annual',target_year,ctx) for f in CONF]
