from __future__ import annotations
import hashlib, json, sqlite3, time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parent
WS_ROOT=ROOT/'workspaces'; WS_ROOT.mkdir(exist_ok=True)
DB=ROOT/'cache'/'workspace.sqlite3'


def now_iso(): return datetime.now(timezone.utc).isoformat()

def sha256_bytes(b: bytes): return hashlib.sha256(b).hexdigest()

def sha256_file(path: Path, chunk=1<<20):
    h=hashlib.sha256()
    with path.open('rb') as f:
        while True:
            x=f.read(chunk)
            if not x: break
            h.update(x)
    return h.hexdigest()


def init_db():
    DB.parent.mkdir(exist_ok=True)
    con=sqlite3.connect(DB)
    con.executescript('''
    CREATE TABLE IF NOT EXISTS runs(
      run_id TEXT PRIMARY KEY, project TEXT, target_kind TEXT, target TEXT,
      fiche TEXT, created_at TEXT, app_version TEXT, source_manifest_hash TEXT,
      status TEXT, output_dir TEXT
    );
    CREATE TABLE IF NOT EXISTS sources(
      id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, provider TEXT, url TEXT,
      label TEXT, retrieved_at TEXT, http_status INTEGER, content_type TEXT,
      bytes INTEGER, sha256 TEXT, from_cache INTEGER, error TEXT
    );
    CREATE TABLE IF NOT EXISTS reviews(
      id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, fiche TEXT, cell_id TEXT,
      decision TEXT, chosen_source TEXT, note TEXT, reviewer TEXT, updated_at TEXT,
      UNIQUE(run_id,cell_id)
    );
    CREATE TABLE IF NOT EXISTS results(
      run_id TEXT, fiche TEXT, cell_id TEXT, label TEXT, value REAL, status TEXT,
      confidence REAL, method TEXT, source TEXT, url TEXT, semantic_score REAL,
      last_observation TEXT, PRIMARY KEY(run_id,cell_id)
    );
    ''')
    con.commit(); con.close()
init_db()


def create_run(project, target_kind, target, fiche=None, app_version='8.0.0'):
    ts=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    suffix=fiche or 'ALL'
    run_id=f'{ts}_{suffix.replace("/","_").replace(" ","_")}'
    out=WS_ROOT/run_id; out.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(DB); con.execute('INSERT INTO runs VALUES (?,?,?,?,?,?,?,?,?,?)',
      (run_id,project,target_kind,json.dumps(target,ensure_ascii=False),fiche,now_iso(),app_version,None,'RUNNING',str(out)))
    con.commit(); con.close()
    return run_id


def set_run_status(run_id,status,source_manifest_hash=None):
    con=sqlite3.connect(DB)
    con.execute('UPDATE runs SET status=?, source_manifest_hash=? WHERE run_id=?',(status,source_manifest_hash,run_id))
    con.commit(); con.close()


def record_sources(run_id, sources):
    con=sqlite3.connect(DB)
    for s in sources:
        con.execute('INSERT INTO sources(run_id,provider,url,label,retrieved_at,http_status,content_type,bytes,sha256,from_cache,error) VALUES (?,?,?,?,?,?,?,?,?,?,?)',
          (run_id,s.get('provider'),s.get('url'),s.get('label'),s.get('retrieved_at',now_iso()),s.get('http_status'),s.get('content_type'),s.get('bytes'),s.get('sha256'),int(bool(s.get('from_cache'))),s.get('error')))
    con.commit(); con.close()


def record_results(run_id, fiche, records):
    con=sqlite3.connect(DB)
    for r in records:
        con.execute('INSERT OR REPLACE INTO results VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',(
            run_id,fiche,r.get('cell_id'),r.get('label') or r.get('component'),r.get('value'),r.get('status'),
            r.get('confidence'),r.get('method'),r.get('source'),r.get('url'),r.get('semantic_score'),json.dumps(r.get('last_observation'),ensure_ascii=False,default=str)))
    con.commit(); con.close()


def save_review(run_id, fiche, cell_id, decision, chosen_source='', note='', reviewer=''):
    con=sqlite3.connect(DB)
    con.execute('''INSERT INTO reviews(run_id,fiche,cell_id,decision,chosen_source,note,reviewer,updated_at)
      VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(run_id,cell_id) DO UPDATE SET decision=excluded.decision,
      chosen_source=excluded.chosen_source,note=excluded.note,reviewer=excluded.reviewer,updated_at=excluded.updated_at''',
      (run_id,fiche,cell_id,decision,chosen_source,note,reviewer,now_iso()))
    con.commit(); con.close()


def list_runs(limit=50):
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    rows=[dict(r) for r in con.execute('SELECT * FROM runs ORDER BY created_at DESC LIMIT ?', (limit,)).fetchall()]
    con.close(); return rows


def reviews_for(run_id):
    con=sqlite3.connect(DB); con.row_factory=sqlite3.Row
    rows=[dict(r) for r in con.execute('SELECT * FROM reviews WHERE run_id=? ORDER BY updated_at DESC',(run_id,)).fetchall()]
    con.close(); return rows


def project_snapshot(run_id, payload):
    out=WS_ROOT/run_id/'run_snapshot.json'; out.write_text(json.dumps(payload,ensure_ascii=False,indent=2,default=str),encoding='utf-8'); return out
