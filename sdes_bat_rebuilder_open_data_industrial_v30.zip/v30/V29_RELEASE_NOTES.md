# V29

- Firewall de preuve renforcé : contrôle provider + URL.
- Les cellules cibles portent désormais evidence_role, source_class, source_allowed et source_quality_score.
- Le moteur conserve BAT 2024 / CK 2026 comme référence/calibration seulement.
- Résolution explicite pour les 53 fiches via registry_v28_upgrade (183 cellules contractuelles).
- Rendu 2 pages amélioré : texte analytique, figures construites uniquement à partir de valeurs cibles compatibles, tableau de provenance cible et structure du gabarit sans reprise des valeurs du BAT.
- Nowcast strictement de dernier recours.
- Tests attendus : source firewall, formules, nowcast fallback, registre complet.
