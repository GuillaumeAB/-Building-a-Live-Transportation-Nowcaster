from __future__ import annotations
import io, json, re, math, hashlib, time
from pathlib import Path
import numpy as np, pandas as pd
from rapidfuzz.fuzz import token_set_ratio
from catalog import get_bytes

ROOT=Path(__file__).resolve().parent
CACHE=ROOT/'cache'; CACHE.mkdir(exist_ok=True)

MONTHS={'janvier':1,'jan':1,'fevrier':2,'fev':2,'mars':3,'avril':4,'avr':4,'mai':5,'juin':6,'juillet':7,'juil':7,'aout':8,'septembre':9,'sept':9,'octobre':10,'oct':10,'novembre':11,'nov':11,'decembre':12,'dec':12}

def norm(s):
    x=str(s or '').lower()
    for a,b in {'é':'e','è':'e','ê':'e','ë':'e','à':'a','â':'a','ä':'a','î':'i','ï':'i','ô':'o','ö':'o','ù':'u','û':'u','ü':'u','ç':'c','œ':'oe','æ':'ae'}.items(): x=x.replace(a,b)
    x=re.sub(r'[^a-z0-9%+\-.]+',' ',x); return re.sub(r'\s+',' ',x).strip()

def numeric(v):
    if pd.isna(v): return np.nan
    if isinstance(v,(int,float,np.number)): return float(v)
    s=str(v).replace('\u202f','').replace(' ','').replace(',','.')
    s=s.replace('%','')
    try:return float(s)
    except:return np.nan

def parse_period(v):
    s=norm(v); y=None;q=None;m=None
    a=re.search(r'(?<!\d)(20\d{2})(?!\d)',s)
    if a:y=int(a.group(1))
    b=re.search(r'(?:t|trim|trimestre|q)\s*([1-4])',s)
    if b:q=int(b.group(1))
    for k,vv in MONTHS.items():
        if re.search(rf'\b{k}\b',s):m=vv;break
    if not y:return None
    return {'year':y,'quarter':q,'month':m}

def detect_period_columns(df):
    out={}
    for j in range(df.shape[1]):
        for i in range(min(60,len(df))):
            p=parse_period(df.iat[i,j])
            if p:out[j]=p;break
    return out

def workbook_series(url, source_label='SDES', max_rows=30000, max_cols=220):
    content,_=get_bytes(url,14); xl=pd.ExcelFile(io.BytesIO(content),engine='openpyxl')
    rows=[]
    for sh in xl.sheet_names:
        try:df=pd.read_excel(io.BytesIO(content),sheet_name=sh,header=None,engine='openpyxl')
        except Exception:continue
        df=df.iloc[:max_rows,:max_cols]
        pcols=detect_period_columns(df)
        if not pcols:continue
        for i in range(len(df)):
            vals=[str(x) for x in df.iloc[i].tolist() if pd.notna(x)]
            if not vals:continue
            label=' | '.join(vals[:8])
            if sum(numeric(x)==numeric(x) for x in df.iloc[i].tolist())<2:continue
            obs=[]
            for j,p in pcols.items():
                v=numeric(df.iat[i,j])
                if np.isfinite(v):obs.append({**p,'value':v})
            if len(obs)>=2:
                rows.append({'source':source_label,'url':url,'sheet':sh,'row':i+1,'label':label[:600],'norm_label':norm(label),'obs':obs})
    return rows

def score(label,aliases):
    nl=norm(label); return max([token_set_ratio(nl,norm(a)) for a in aliases] or [0])

def target_value(obs,target_kind,target,variable_type='flow'):
    if not obs:return None
    df=pd.DataFrame(obs)
    if target_kind=='annual':
        y=int(target); x=df[df.year==y]
        if x.empty:return None
        if 'month' in x and x.month.notna().any():
            val=x.value.mean() if variable_type=='stock' else x.value.sum()
            return float(val),'aggregated' if len(x)<12 else 'complete_aggregation'
        if 'quarter' in x and x.quarter.notna().any():
            val=x.value.mean() if variable_type=='stock' else x.value.sum()
            return float(val),'aggregated' if len(x)<4 else 'complete_aggregation'
        return float(x.value.iloc[-1]),'direct'
    y,q=target; x=df[(df.year==int(y))&(df.quarter==int(q))]
    if not x.empty:return float(x.value.iloc[-1]),'direct'
    x=df[(df.year==int(y))&(df.month.between(3*q-2,3*q))]
    if x.empty:return None
    return float(x.value.mean() if variable_type=='stock' else x.value.sum()),'monthly_aggregation'

def project(obs,target_kind,target,variable_type='flow'):
    df=pd.DataFrame(obs).copy();
    if df.empty:return None
    # convert to native regular index
    if target_kind=='annual':
        df=df.groupby('year',as_index=False).value.agg('mean' if variable_type=='stock' else 'sum'); df['key']=df.year
        tk=int(target)
    else:
        if df['quarter'].notna().any(): df=df[df.quarter.notna()].copy(); df['key']=df.year*4+df.quarter; tk=target[0]*4+target[1]
        else: df=df[df.month.notna()].copy(); df['key']=df.year*12+df.month; tk=target[0]*12+target[1]*3
    df=df.sort_values('key');
    if len(df)<4:return None
    lastk=int(df.key.iloc[-1]); h=tk-lastk
    if h<=0:return None
    vals=df.value.to_numpy(float); preds=[]; recent=vals[-min(12,len(vals)):]
    g=vals[1:]/vals[:-1]-1; g=g[np.isfinite(g)]
    if len(g):preds.append(vals[-1]*(1+float(np.clip(np.median(g[-8:]),-.30,.30)))**h)
    if np.all(recent>0):
        k=len(recent); sl,it=np.polyfit(np.arange(k),np.log(recent),1);preds.append(float(np.exp(np.log(vals[-1])+sl*h)))
    k=len(recent); sl,it=np.polyfit(np.arange(k),recent,1);preds.append(float(it+sl*(k-1+h)))
    preds=[p for p in preds if np.isfinite(p) and p>=0]
    if not preds:return None
    val=float(np.median(preds)); vol=float(np.std(g[-12:],ddof=1)) if len(g)>=4 else .10
    unc=min(.60,max(.03,vol*math.sqrt(h)))
    return {'value':val,'lower':max(0,val*(1-unc)),'upper':val*(1+unc),'uncertainty':unc,'method':'ensemble robuste (croissance, log-tendance, tendance)','horizon':h}

def backtest(obs,variable_type='flow'):
    if len(obs)<12:return None
    df=pd.DataFrame(obs)
    if target := 'annual': pass
    # use annualized values for a stable cross-series error measure
    y=df.groupby('year',as_index=False).value.agg('mean' if variable_type=='stock' else 'sum').sort_values('year')
    if len(y)<8:return None
    errs=[]
    for i in range(6,len(y)):
        tr=y.iloc[:i].copy(); vals=tr.value.to_numpy(float); actual=float(y.iloc[i].value)
        if len(vals)<4 or actual==0:continue
        g=vals[1:]/vals[:-1]-1;g=g[np.isfinite(g)]
        preds=[]
        if len(g):preds.append(vals[-1]*(1+float(np.clip(np.median(g[-4:]),-.30,.30))))
        if np.all(vals[-6:]>0):
            sl,it=np.polyfit(np.arange(min(6,len(vals))),np.log(vals[-min(6,len(vals)):]),1);preds.append(float(np.exp(np.log(vals[-1])+sl)))
        if preds:errs.append(abs(np.median(preds)/actual-1)*100)
    return float(np.median(errs[-8:])) if errs else None
