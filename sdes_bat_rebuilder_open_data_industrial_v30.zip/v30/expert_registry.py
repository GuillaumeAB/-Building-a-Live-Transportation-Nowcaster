from __future__ import annotations
import json, re, unicodedata
from pathlib import Path
from rapidfuzz.fuzz import token_set_ratio

ROOT=Path(__file__).resolve().parent
CONF=json.loads((ROOT/'config/fiches_2024.json').read_text(encoding='utf-8'))
RULES=json.loads((ROOT/'config/indicator_rules.json').read_text(encoding='utf-8'))

DOMAIN_SEEDS={
 'cadrage':['transport','économie','infrastructure','France','Europe','activité','prix','PIB','commerce'],
 'activite':['dépenses','recettes','investissements','financement','ménages','administrations','prix','échanges','transport'],
 'entreprises':['entreprises','créations','défaillances','chiffre d’affaires','salariés','activité'],
 'emploi':['emploi','salariés','effectifs','salaire','rémunération','marché du travail','EQTP'],
 'environnement':['énergie','émissions','GES','CO2','polluants','qualité de l’air','accidents','nuisances','sols','biodiversité'],
 'marchandises':['marchandises','fret','tonnes-kilomètres','route','ferroviaire','fluvial','maritime','aérien','entrepôt','logistique'],
 'voyageurs':['voyageurs','voyageurs-kilomètres','passagers','ferroviaire','aérien','urbain','vélo','mobilité','qualité de service'],
 'circulation':['circulation','véhicules-kilomètres','immatriculations','voitures','véhicules','carburants','diesel','essence','électrique']
}

def norm(s):
    x=unicodedata.normalize('NFKD',str(s or '')).encode('ascii','ignore').decode().lower()
    return re.sub(r'\s+',' ',re.sub(r'[^a-z0-9%+./-]+',' ',x)).strip()

def unit_guess(text):
    t=norm(text)
    for pat,u in [
        (r'voyageur.?\s*-?km','milliards de voyageurs-km'),(r'tonne.?\s*-?km','milliards de tonnes-km'),
        (r'milliard', 'milliards'),(r'million','millions'),(r'%|pour cent','%'),
        (r'euro|€','millions d’euros'),(r'tonne','millions de tonnes'),(r'kilom','km'),
        (r'véhicule|vehicule','véhicules'),(r'salari','personnes / salariés')]:
        if re.search(pat,t): return u
    return ''

def var_type(text):
    t=norm(text)
    if any(w in t for w in ['parc ','stock','effectif','infrastructure','nombre de','prix','indice','taux','part','ratio','qualite','émission moyenne']): return 'stock'
    return 'flow'

def seeds_for(fiche,title,family,figures,tables):
    if fiche in RULES:
        return list(RULES[fiche].get('components',{}).keys()) + ([RULES[fiche]['total']['label']] if RULES[fiche].get('total') else [])
    base=[title]+DOMAIN_SEEDS.get(family,[])+figures+tables
    # take short noun phrases from captions; avoid generic stopwords
    toks=[]
    for x in base:
        parts=re.split(r'[:;,.()\-–—/]+',x)
        toks.extend([p.strip() for p in parts if 3<=len(p.strip())<=90])
    out=[]
    for x in toks:
        if norm(x) in {norm(y) for y in out}: continue
        if token_set_ratio(norm(x),norm(title))>=88 or len(x.split())>=2: out.append(x)
    return out[:18]

def build_registry(bat_manifest):
    registry={}
    for fiche,(title,page,family) in CONF.items():
        b=bat_manifest.get(fiche,{})
        figs=b.get('figures',[]); tabs=b.get('tables',[])
        seeds=seeds_for(fiche,title,family,figs,tabs)
        cells=[]
        for i,label in enumerate(seeds,1):
            rr=None
            if fiche in RULES:
                for name,spec in RULES[fiche].get('components',{}).items():
                    if norm(name)==norm(label): rr=spec; break
            if rr:
                aliases=rr.get('aliases',[label]); unit=rr.get('unit',''); vt=rr.get('type','flow'); role='component'
            else:
                aliases=[label]+[x for x in DOMAIN_SEEDS.get(family,[]) if token_set_ratio(norm(label),norm(x))>55]
                unit=unit_guess(label); vt=var_type(label); role='candidate'
            cells.append({'cell_id':f'{fiche}:I{i:03d}','label':label,'aliases':list(dict.fromkeys(aliases)),'unit':unit,'variable_type':vt,'role':role,'mandatory': role=='component','family':family})
        # explicit editorial objects are first-class, but no numeric forcing
        registry[fiche]={'title':title,'family':family,'page_start':page,'cells':cells,
                         'figures':[{'asset_id':f'{fiche}:FIG{i:02d}','label':x,'kind':'figure'} for i,x in enumerate(figs,1)],
                         'tables':[{'asset_id':f'{fiche}:TAB{i:02d}','label':x,'kind':'table'} for i,x in enumerate(tabs,1)],
                         'sources':b.get('sources',[]),'crossrefs':b.get('pages',[])}
    return registry
