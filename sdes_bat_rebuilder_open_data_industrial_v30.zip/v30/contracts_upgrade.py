from __future__ import annotations
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
FICHES=json.loads((ROOT/'config/fiches_2024.json').read_text())
BASE=json.loads((ROOT/'config/business_rules_v9.json').read_text())['fiches']
F=json.loads((ROOT/'config/f_contracts.json').read_text())
D=json.loads((ROOT/'config/d_contracts.json').read_text())

PROFILES={
'activite':['insee','sdes_conj','eurostat','banque_france','sdes_specific'],
'entreprises':['insee','urssaf','sdes_specific','eurostat','bodacc','data_gouv'],
'emploi':['sdes_specific','insee','urssaf','francetravail','sdes_conj'],
'marchandises':['sdes_specific','sdes_conj','eurostat','vnf','art','dgac'],
'circulation':['sdes_specific','energie_sdes','cerema','sdes_conj','onisr','eurostat'],
'cadrage':['insee','eurostat','sdes_conj','dgitm','dgamapa'],
'voyageurs':['sdes_specific','sdes_conj','art','sncf','dgac','idfm','ratp','eurostat'],
'environnnement':[] ,
}

def c(code,label,aliases=None,unit=None,typ='flow',family=None,providers=None,role='main'):
    return {'cell_id':f'{code}:{label}', 'label':label, 'aliases':aliases or [label], 'role':role, 'mandatory':True,
            'family':family,'variable_type':typ,'measure_family':family,
            'expected_units':[unit] if unit else [], 'priority_providers':providers or PROFILES.get(family,[]),
            'status_policy':'direct_then_aggregate_then_nowcast','period_policy':'target_period','review_rules':['unit_mismatch','scope_mismatch','stale_source','break_detected','low_semantic_score']}

T={}
# Activity
T['A1']=[c('A1','Dépense totale de transport', ['dépense totale transport','DTT'], 'milliards d’euros courants','flow','activite'),c('A1','Dépense courante de transport',['DCT'],'milliards d’euros courants','flow','activite'),c('A1','Dépense d’investissement de transport',['DIT'],'milliards d’euros courants','flow','activite'),c('A1','Production de la branche des transports',['production transport'],'indice','flow','activite')]
T['A2']=[c('A2','Production marchande de transport',['production marchande transport'],'indice','flow','activite'),c('A2','Valeur ajoutée de la branche des transports',['valeur ajoutée transports'],'milliards d’euros','flow','activite'),c('A2','Emploi de la branche des transports',['emploi branche transport'],'milliers de salariés','stock','activite')]
T['A3']=[c('A3','Dépense des ménages en transport',['dépense ménages transport'],'milliards d’euros courants','flow','activite'),c('A3','Part du transport dans le budget des ménages',['budget ménages transport'],'%','share','activite'),c('A3','Achat de véhicules',['achat voitures véhicules ménages'],'milliards d’euros courants','flow','activite'),c('A3','Carburants',['dépenses carburants ménages'],'milliards d’euros courants','flow','activite')]
T['A4']=[c('A4','Dépenses publiques de transport',['dépenses administrations transport'],'milliards d’euros courants','flow','activite'),c('A4','Administrations centrales',['APU centrales transport'],'milliards d’euros','flow','activite'),c('A4','Administrations locales',['APU locales transport'],'milliards d’euros','flow','activite')]
T['A5.1']=[c('A5.1','Transferts publics aux opérateurs de transport collectif',['transferts opérateurs transport collectif'],'milliards d’euros','flow','activite'),c('A5.1','Transferts au transport ferroviaire',['subventions ferroviaire'],'milliards d’euros','flow','activite'),c('A5.1','Transferts au transport collectif urbain',['subventions TCU'],'milliards d’euros','flow','activite')]
T['A5.2']=[c('A5.2','Transferts aux gestionnaires d’infrastructures',['transferts gestionnaires infrastructure'],'milliards d’euros','flow','activite'),c('A5.2','Routes',['financement routes'],'milliards d’euros','flow','activite'),c('A5.2','Rail',['financement réseau ferré'],'milliards d’euros','flow','activite')]
T['A6']=[c('A6','Recettes publiques liées au transport',['recettes fiscales transport'],'milliards d’euros','flow','activite'),c('A6','TICPE',['TICPE transport carburants'],'milliards d’euros','flow','activite'),c('A6','Autres taxes transport',['taxes transport hors TICPE'],'milliards d’euros','flow','activite')]
T['A7.1']=[c('A7.1','Investissements en infrastructures de transport',['investissement infrastructures transport'],'milliards d’euros','flow','activite'),c('A7.1','Investissements ferroviaires',['investissement ferroviaire'],'milliards d’euros','flow','activite'),c('A7.1','Investissements routiers',['investissement routier'],'milliards d’euros','flow','activite'),c('A7.1','Investissements transports collectifs',['investissement TC'],'milliards d’euros','flow','activite')]
T['A7.2']=[c('A7.2','Financement des infrastructures de transport',['financement infrastructures transport'],'milliards d’euros','flow','activite'),c('A7.2','AFIT France',['AFITF financement'],'milliards d’euros','flow','activite'),c('A7.2','Partenariats public-privé',['PPP transport'],'milliards d’euros','flow','activite')]
T['A8']=[c('A8','Exportations de services de transport',['exportations services transport'],'milliards d’euros','flow','activite'),c('A8','Importations de services de transport',['importations services transport'],'milliards d’euros','flow','activite'),c('A8','Solde des échanges de services de transport',['solde commerce services transport'],'milliards d’euros','flow','activite')]
T['A9']=[c('A9','Investissements français dans le transport à l’étranger',['IDE français transport étranger'],'milliards d’euros','flow','activite'),c('A9','Investissements étrangers dans le transport en France',['IDE étrangers transport France'],'milliards d’euros','flow','activite')]
T['A10']=[c('A10','Prix du fret routier',['indice prix fret routier'],'indice','index','activite'),c('A10','Prix du fret ferroviaire',['indice prix fret ferroviaire'],'indice','index','activite'),c('A10','Prix du fret maritime',['indice prix fret maritime'],'indice','index','activite'),c('A10','Prix du fret aérien',['indice prix fret aérien'],'indice','index','activite'),c('A10','Prix de l’entreposage',['indice prix entreposage'],'indice','index','activite')]
# Enterprises
T['B1']=[c('B1','Entreprises de transport',['nombre entreprises transport'],'milliers d’entreprises','stock','entreprises'),c('B1','Créations d’entreprises de transport',['créations entreprises transport'],'milliers','flow','entreprises'),c('B1','Défaillances d’entreprises de transport',['défaillances transport'],'nombre','flow','entreprises')]
for code,name,aliases in [('B2.1','Entreprises de transport routier',['entreprises TRM','entreprises transport routier']),('B2.2','Entreprises de transport collectif urbain',['entreprises TCU','opérateurs urbains']),('B2.3','Entreprises de transport ferroviaire',['entreprises ferroviaires','opérateurs ferroviaires']),('B2.4','Entreprises de transport par eau',['entreprises maritime fluvial','entreprises navigation']),('B2.5','Entreprises de transport aérien',['entreprises aériennes','transport aérien'])]:
    T[code]=[c(code,name,aliases,'entreprises','stock','entreprises'),c(code,'Chiffre d’affaires',aliases+['chiffre affaires'],'milliards d’euros','flow','entreprises'),c(code,'Effectifs salariés',aliases+['effectifs'],'milliers de salariés','stock','emploi'),c(code,'Créations / défaillances',aliases+['créations défaillances'],'nombre','flow','entreprises')]
T['B3']=[c('B3','Chiffre d’affaires des entreprises de transport',['CA entreprises transport'],'milliards d’euros','flow','entreprises'),c('B3','Valeur ajoutée des entreprises de transport',['VA entreprises transport'],'milliards d’euros','flow','entreprises'),c('B3','Investissement des entreprises de transport',['investissement entreprises transport'],'milliards d’euros','flow','entreprises')]
# Employment
T['C1']=[c('C1','Emploi salarié transports et entreposage',['emploi salarié transport entreposage'],'milliers de salariés','stock','emploi'),c('C1','Emploi intérimaire mobilisé par les transports',['intérim transport'],'milliers de salariés','stock','emploi'),c('C1','Salaire moyen mensuel par tête',['SMPT transport'],'euros','stock','emploi')]
T['C2']=[c('C2','Part des ouvriers dans les transports',['ouvriers transport'],'%','share','emploi'),c('C2','Part des conducteurs',['conducteurs transport'],'%','share','emploi'),c('C2','Âge moyen des salariés',['age salariés transport'],'années','stock','emploi')]
T['C3']=[c('C3','Salaire moyen mensuel par tête',['SMPT'],'euros','stock','emploi'),c('C3','Évolution des salaires',['salaires transport variation'],'%','rate','emploi'),c('C3','Écart salarial femmes-hommes',['écart salaire femmes hommes transport'],'%','rate','emploi')]
# Goods
T['E1']=[c('E1','Transport intérieur de marchandises',['transport intérieur marchandises'],'milliards de tonnes-km','flow','marchandises'),c('E1','Transport routier',['transport routier marchandises'],'milliards de tonnes-km','flow','marchandises'),c('E1','Transport ferroviaire',['transport ferroviaire marchandises'],'milliards de tonnes-km','flow','marchandises'),c('E1','Transport fluvial',['transport fluvial marchandises'],'milliards de tonnes-km','flow','marchandises'),c('E1','Oléoducs',['transport oléoducs'],'milliards de tonnes-km','flow','marchandises')]
T['E2']=[c('E2','Transport routier intérieur de marchandises',['TRM transport routier intérieur'],'milliards de tonnes-km','flow','marchandises'),c('E2','Pavillon français',['TRM pavillon français'],'milliards de tonnes-km','flow','marchandises'),c('E2','Pavillon étranger',['TRM pavillon étranger'],'milliards de tonnes-km','flow','marchandises'),c('E2','Parcourus à vide',['circulation poids lourds à vide'],'%','share','marchandises')]
T['E3']=[c('E3','Transport ferroviaire de marchandises',['fret ferroviaire'],'milliards de tonnes-km','flow','marchandises'),c('E3','Produits manufacturés',['fret ferroviaire produits manufacturés'],'%','share','marchandises'),c('E3','Produits agricoles et agroalimentaires',['fret ferroviaire produits agricoles'],'%','share','marchandises'),c('E3','Matériaux de construction',['fret ferroviaire matériaux construction'],'%','share','marchandises')]
T['E4']=[c('E4','Transport fluvial de marchandises',['trafic fluvial','fret fluvial'],'millions de tonnes','flow','marchandises'),c('E4','Tonnage-kilomètres fluviaux',['t-km fluvial'],'milliards de tonnes-km','flow','marchandises'),c('E4','Part des produits agricoles et alimentaires',['fret fluvial agriculture'],'%','share','marchandises')]
T['E5']=[c('E5','Trafic maritime de marchandises',['fret maritime','trafic ports français'],'millions de tonnes','flow','marchandises'),c('E5','Trafic des grands ports maritimes',['grands ports maritimes trafic'],'millions de tonnes','flow','marchandises'),c('E5','Conteneurs',['trafic conteneurs ports'],'millions de tonnes','flow','marchandises')]
T['E6']=[c('E6','Transport aérien de marchandises',['fret aérien'],'milliers de tonnes','flow','marchandises'),c('E6','Fret international',['fret aérien international'],'milliers de tonnes','flow','marchandises'),c('E6','Fret intérieur',['fret aérien intérieur'],'milliers de tonnes','flow','marchandises')]
T['E7']=[c('E7','Surface des entrepôts et plateformes logistiques',['surface entrepôts plateformes'],'millions de m2','stock','marchandises'),c('E7','Entrepôts de 10 000 m2 ou plus',['entrepôts logistiques grands'],'millions de m2','stock','marchandises'),c('E7','Évolution des surfaces logistiques',['surface plateformes évolution'],'%','rate','marchandises')]
# G
T['G1']=[c('G1','Distance totale parcourue par les véhicules routiers',['circulation routière kilomètres'],'milliards de véhicules-km','flow','circulation'),c('G1','Distance parcourue par les voitures particulières',['circulation VP kilomètres'],'milliards de véhicules-km','flow','circulation'),c('G1','Distance parcourue par les VUL',['circulation VUL kilomètres'],'milliards de véhicules-km','flow','circulation'),c('G1','Distance parcourue par les poids lourds',['circulation PL kilomètres'],'milliards de véhicules-km','flow','circulation')]
T['G2']=[c('G2','Immatriculations de voitures particulières neuves',['voitures particulières neuves','VP neuves'],'millions de véhicules','flow','circulation',PROFILES['circulation'],'main'),c('G2','Électrique et hydrogène neuf',['électrique hydrogène voitures neuves'],'%','share','circulation'),c('G2','Essence - hybride non rechargeable neuf',['essence hybride non rechargeable voitures neuves'],'%','share','circulation'),c('G2','Motorisations thermiques neuves',['motorisations thermiques voitures neuves'],'%','share','circulation'),c('G2','Hybride rechargeable neuf',['hybride rechargeable voitures neuves'],'%','share','circulation'),c('G2','Voitures particulières d’occasion',['VP occasion'],'millions de véhicules','flow','circulation')]
T['G3']=[c('G3','Consommation de carburants routiers',['consommation carburants routiers'],'TWh','flow','circulation'),c('G3','Gazole routier',['gazole carburants routiers'],'TWh','flow','circulation'),c('G3','Essence routière',['essence carburants routiers'],'TWh','flow','circulation'),c('G3','Biocarburants routiers',['biocarburants transport routier'],'TWh','flow','circulation')]

# Cadrage with explicit macro concepts
T['Cadrage 1a']=[c('Cadrage 1a','PIB français',['PIB France'],'%','rate','cadrage'),c('Cadrage 1a','Inflation',['IPC inflation'],'%','rate','cadrage'),c('Cadrage 1a','Prix des carburants',['prix carburants'],'indice','index','cadrage'),c('Cadrage 1a','Emploi total',['emploi France'],'%','rate','cadrage')]
T['Cadrage 1b']=[c('Cadrage 1b','PIB mondial',['croissance PIB mondial'],'%','rate','cadrage'),c('Cadrage 1b','Commerce mondial',['commerce mondial'],'%','rate','cadrage'),c('Cadrage 1b','Prix du pétrole',['Brent pétrole'],'USD/baril','stock','cadrage')]
T['Cadrage 2']=[c('Cadrage 2','Production industrielle française',['production industrielle'],'indice','index','cadrage'),c('Cadrage 2','Construction',['construction activité'],'indice','index','cadrage'),c('Cadrage 2','Commerce extérieur',['commerce extérieur France'],'milliards d’euros','flow','cadrage')]
T['Cadrage 3']=[c('Cadrage 3','Longueur du réseau routier',['réseau routier longueur'],'km','stock','cadrage'),c('Cadrage 3','Longueur du réseau ferré',['réseau ferré longueur'],'km','stock','cadrage'),c('Cadrage 3','Infrastructures aéroportuaires',['aéroports infrastructures'],'nombre','stock','cadrage')]
T['Cadrage 4']=[c('Cadrage 4','Part de la France dans le transport européen',['France transport Europe'],'%','share','cadrage'),c('Cadrage 4','Réseau ferré France / UE',['réseau ferré France UE'],'%','share','cadrage')]

# D from dedicated contracts
for k,v in D.items():
    fam='environnement'; cells=[]
    # map each contract to cells based on narrative sections / title
    if k=='D1': labels=['Consommation d’énergie des transports','Produits pétroliers','Électricité','Gaz / autres']
    elif k=='D2.1': labels=['Émissions de GES des transports','Voitures particulières','Poids lourds','VUL','Aérien intérieur','Autres transports']
    elif k=='D2.2': labels=['NOx','PM2,5','COVNM','SO2']
    elif k=='D2.3': labels=['NO2','PM10','PM2,5']
    elif k=='D3.1': labels=['Accidents ferroviaires','Accidents aériens','Accidents maritimes']
    elif k=='D3.2': labels=['Tués sur les routes','Blessés sur les routes','Blessés graves']
    elif k=='D3.3': labels=['Tués impliquant VUL/PL','Blessés graves impliquant VUL/PL']
    elif k=='D4': labels=['Emprise des infrastructures de transport','Artificialisation / milieux']
    else: labels=['Population exposée bruit routier','Population exposée bruit ferroviaire','Population exposée bruit aérien']
    for lab in labels:
        unit='Mt CO2e' if k=='D2.1' else ('kt' if k=='D2.2' else ('personnes' if 'Tués' in lab or 'Blessés' in lab or 'Population' in lab else None))
        typ='flow' if k in {'D1','D2.1','D2.2'} else 'stock'
        cells.append(c(k,lab,[lab],unit,typ,fam,PROFILES.get(fam,[])))
    # exact contract metadata retained
    T[k]=cells

# F from dedicated contract -> meaningful cells
for k,v in F.items():
    fam='voyageurs'; cells=[]
    if k=='F1': labels=['Véhicules particuliers','Transports ferrés','Cars, bus et tramways','Transport aérien'] ; units=['Md voyageurs-km']*4
    elif k=='F2': labels=['Transport collectif urbain total','Île-de-France','Province'] ; units=['Md voyageurs-km']*3
    elif k=='F3': labels=['Trafic ferroviaire total','TAGV','Trains interurbains / TER','Île-de-France'] ; units=['Md passagers-km']*4
    elif k=='F4': labels=['Trafic aérien total France','Trafic métropole','Trafic intérieur métropolitain','Trafic international métropole'] ; units=['millions de passagers']*4
    elif k=='F5': labels=['Trafic maritime voyageurs','Passagers hors croisière','Croisière'] ; units=['millions de passagers']*3
    elif k=='F6': labels=['Part des actifs allant travailler à vélo','Fréquentation cyclable','Distance moyenne à vélo'] ; units=['%','indice','km']
    else: labels=['Ponctualité ferroviaire','Annulations ferroviaires','Ponctualité aérienne'] ; units=['%','%','%']
    for lab,u in zip(labels,units): cells.append(c(k,lab,[lab],u,'share' if u=='%' else 'flow',fam,PROFILES[fam]))
    T[k]=cells

# Do not overwrite nuanced existing extra cells if a contract already has more specific definitions: merge exact by label.
OUT={}
for code,(title,pag,fam) in FICHES.items():
    cells=T.get(code)
    if not cells:
        cells=[]
        base=BASE.get(code,{})
        for bc in base.get('cells',[]):
            cc=dict(bc); cc['priority_providers']=[p for p in cc.get('priority_providers',[]) if p not in {'sdes_bat_2024','sdes_ck_2026'}] or PROFILES.get(fam,[])
            cells.append(cc)
    OUT[code]={'fiche':code,'title':title,'family':fam,'page_start':pag,'cells':cells,
               'contract_version':'v28.1','target_evidence_policy':'public non-BAT/non-CK evidence only',
               'reference_template': F.get(code) or D.get(code) or {},
               'providers_priority':PROFILES.get(fam,[]),
               'narrative_sections':(F.get(code,{}).get('narrative_sections',[]) if isinstance(F.get(code),dict) else []) or ['niveau','évolution','composition','contexte']}

(ROOT/'config/registry_v28_upgrade.json').write_text(json.dumps(OUT,ensure_ascii=False,indent=2),encoding='utf8')
print('registry',len(OUT),'cells',sum(len(x['cells']) for x in OUT.values()))
