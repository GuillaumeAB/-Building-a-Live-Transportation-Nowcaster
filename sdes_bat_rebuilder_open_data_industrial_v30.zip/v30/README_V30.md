# Reconstructeur BAT SDES — V30

V30 est une version ciblée « qualité éditoriale + sourcing » du reconstructeur. Elle sépare strictement les valeurs de référence (BAT/CK) des preuves cibles, traite le F4 2025 et D2.1 T1 2026 avec des faits publics vérifiés, et lance ces deux fiches en parallèle pour la validation interne.

## Lancement

Depuis ce dossier :

```powershell
py -3.14 -m venv .venv
.venv\\Scripts\\python.exe -m pip install -r requirements.txt
.venv\\Scripts\\python.exe run_internal_launch.py
```

Puis, pour l'application Streamlit de la version précédente, lancer `run_windows.bat`.

Les deux PDF d'exemple sont générés dans `output/F4/` et `output/D2.1/`.
